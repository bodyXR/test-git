import { Box } from "@mui/material";
import checkboxIcon from "../assets/checkbox_icon.svg";

const CheckBoxActiveImg = () => {
  return (
    <Box
      sx={{ width: "20px", height: "20px" }}
      component={"img"}
      src={checkboxIcon}
    />
  );
};

export default CheckBoxActiveImg;
