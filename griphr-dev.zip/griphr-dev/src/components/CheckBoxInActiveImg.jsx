import { Box } from "@mui/material";
import checkboxInactiveIcon from "../assets/checkbox_inactive.svg";

const CheckBoxInActiveImg = () => {
  return (
    <Box
      sx={{ width: "20px", height: "20px" }}
      component={"img"}
      src={checkboxInactiveIcon}
    />
  );
};

export default CheckBoxInActiveImg;
