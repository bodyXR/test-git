import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { closeSnackbar } from "../redux/slices/snackbar/snackbarSlice";
import { Alert, Box, Snackbar } from "@mui/material";

const Content = ({ children }) => {
  const dispatch = useDispatch();
  const { snackbarOpen, snackbarMsg, severity } = useSelector(
    (state) => state.snackbar
  );
  const handleCloseSnackbar = () => {
    dispatch(closeSnackbar());
  };
  return (
    <Box component={"main"} className="content">
      <Snackbar
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={severity}
          sx={{ width: "100%" }}
        >
          {snackbarMsg}
        </Alert>
      </Snackbar>
      {children}
    </Box>
  );
};

export default Content;
