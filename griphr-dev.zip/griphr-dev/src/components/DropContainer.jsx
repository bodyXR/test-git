import { Box, List, ListItem, Stack, Typography } from "@mui/material";
import React, { useState } from "react";
import { useDropzone } from "react-dropzone";
import file_icon from "../assets/file_icon.svg";
import { useCallback } from "react";
import StyledDarkWrapper from "./styled/StyledDarkWrapper";
import Papa from "papaparse";

const DropContainer = ({ title, fileTypes, formik, name }) => {
  const [path, setPath] = useState(null);

  const onDrop = useCallback(
    async (acceptedFiles) => {
      if (acceptedFiles.length === 0) return;
      const file = acceptedFiles[0];
      formik.setFieldValue(name, file);
      setPath(URL.createObjectURL(file));

      const parsedData = await parseCSV(file);
      console.log("parsedData", parsedData);
      formik.setFieldValue("users", parsedData);
    },
    [name, formik]
  );

  const parseCSV = (file) => {
    return new Promise((resolve, reject) => {
      Papa.parse(file, {
        header: true,
        dynamicTyping: true,
        encoding: "UTF-8",
        transformHeader: (header) => {
          return header.trim();
        },
        complete: (result) => {
          resolve(result.data);
        },
        error: (error) => {
          reject(error);
        },
      });
    });
  };

  const { acceptedFiles, fileRejections, getRootProps, getInputProps } =
    useDropzone({
      onDrop,
      accept: fileTypes,
      maxFiles: 1,
      maxSize: 4 * 10 ** 6,
    });

  const files = acceptedFiles.map((file, index) => (
    <Typography
      key={index}
      variant="span"
      color={"secondary.main"}
      fontWeight={"700"}
    >
      {file.path}
    </Typography>
  ));

  const fileRejectionItems = fileRejections.map(({ file, errors }) => (
    <Box key={file.path}>
      <Typography variant="h5" color={"secondary.main"} fontWeight={"400"}>
        Selected File:{" "}
        <Typography variant="span" color={"secondary.main"} fontWeight={"700"}>
          {file.path}
        </Typography>
      </Typography>
      <List>
        {errors.map((e) => (
          <ListItem key={e.code} sx={{ color: "warning.main" }}>
            {e.message}
          </ListItem>
        ))}
      </List>
    </Box>
  ));

  return (
    <StyledDarkWrapper>
      <Stack>
        <Stack
          {...getRootProps({ className: "dropzone" })}
          sx={{ alignItems: "center", gap: 3, textAlign: "center" }}
        >
          <input {...getInputProps()} />
          <img
            src={file_icon}
            alt="file img"
            style={{ width: "66px", height: "82.5px" }}
          />
          <Stack gap={1}>
            <Typography variant="h3" color="inactive.main" mt={1.25}>
              {title}
            </Typography>
            <Typography
              variant="body1"
              sx={{ fontSize: "12px", opacity: "0.5" }}
              color="inactive.main"
            >
              or, click to browse (4MB max)
            </Typography>
          </Stack>
        </Stack>
        <Box>
          {!!formik.initialValues.files && acceptedFiles.length === 0 && (
            <Typography
              variant="h5"
              color={"secondary.main"}
              fontWeight={"400"}
            >
              Selected File:
              <Typography
                variant="span"
                color={"secondary.main"}
                fontWeight={"700"}
                sx={{ wordBreak: "break-all" }}
              >
                {formik.initialValues.files}
              </Typography>
            </Typography>
          )}
          {!!path && (
            <Typography
              variant="h5"
              color={"secondary.main"}
              fontWeight={"400"}
            >
              Selected File: {files}
            </Typography>
          )}
          {fileRejectionItems}
        </Box>
      </Stack>
    </StyledDarkWrapper>
  );
};

export default DropContainer;
