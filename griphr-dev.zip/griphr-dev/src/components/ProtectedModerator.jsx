import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { MODERATOR_CANDIDATES_PAGE_ROUTE } from "../routes/paths";

const ProtectedModerator = ({ children }) => {
  const { userInfo, isAuth } = useSelector((state) => state.auth);
  const role = userInfo ? userInfo.system_role : null;
  const location = useLocation();
  const navigate = useNavigate();
  const redirectPath = MODERATOR_CANDIDATES_PAGE_ROUTE; // Redirect path for "moderator"

  useEffect(() => {
    // Check the role and perform navigation if needed
    if (isAuth && role === "moderator" && location.pathname === "/moderator") {
      navigate(redirectPath, { replace: true });
    }
  }, [isAuth, role, location, navigate, redirectPath]);

  if (!isAuth) return <Navigate to="/login" replace />;
  return children;
};

export default ProtectedModerator;
