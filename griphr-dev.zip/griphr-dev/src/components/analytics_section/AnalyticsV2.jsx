import { Stack, Typography } from "@mui/material";
import React from "react";
import StyledFilterButton from "../styled/StyledFilterButton";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

const AnalyticsV2 = () => {
  return (
    <Stack sx={{ flexDirection: "row", alignItems: "center", gap: 2 }}>
      <Typography variant="h5" sx={{ fontWeight: 500 }}>
        Filters:{" "}
      </Typography>
      <StyledFilterButton
        // onClick={handleDepartmentsOpen}
        // hasEmployees={hasEmployees}
        disableElevation
        disableRipple
        endIcon={
          <KeyboardArrowDownIcon
            style={{ width: "24px", height: "24px", color: "darkGrey" }}
          />
        }
        variant="outlined"
      >
        <Typography variant="h5" color="darkGrey">
          Department
        </Typography>
      </StyledFilterButton>
      <StyledFilterButton
        // onClick={handleDepartmentsOpen}
        // hasEmployees={hasEmployees}
        disableElevation
        disableRipple
        endIcon={
          <KeyboardArrowDownIcon
            style={{ width: "24px", height: "24px", color: "darkGrey" }}
          />
        }
        variant="outlined"
      >
        <Typography variant="h5" color="darkGrey">
          Skills
        </Typography>
      </StyledFilterButton>
    </Stack>
  );
};

export default AnalyticsV2;
