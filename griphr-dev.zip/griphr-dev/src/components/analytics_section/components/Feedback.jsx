import React, { useCallback, useEffect, useState } from "react";
import StyledWrapper from "../../styled/StyledWrapper";
import {
  Alert,
  Box,
  CircularProgress,
  Snackbar,
  Stack,
  TextareaAutosize,
  Typography,
} from "@mui/material";
import { useFormik } from "formik";
import * as yup from "yup";
import StyledSmallDarkBtn from "../../styled/StyledSmallDarkBtn";
import StyledDisabledSmallBtn from "../../styled/StyledDisabledSmallBtn";
import axiosInstance from "../../../helper/axiosInstance";
import { useSelector } from "react-redux";
import FeedbackRow from "./FeedbackRow";

const validationSchema = yup.object().shape({
  message: yup.string().required(""),
});

const Feedback = ({ goalId }) => {
  const [loading, setLoading] = useState(false);
  const [feedbacks, setFeedbacks] = useState([]);
  const { token, userInfo } = useSelector((state) => state.auth);

  useEffect(() => {
    if (goalId) {
      fetchData(goalId);
    }
  }, [token, goalId]);

  const formik = useFormik({
    initialValues: {
      message: "",
    },
    validationSchema,
    onSubmit: async (values, { resetForm }) => {
      addComment(goalId, values.message);
      resetForm();
    },
  });

  const fetchData = useCallback(
    async (goal_id) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
        params: {
          goal_id,
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.get(`goals/comments`, config);
        console.log(response.data.payload);
        setFeedbacks(response.data.payload);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const addComment = useCallback(
    async (goal_id, text) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `goals/comments`,
          { goal_id, text },
          config
        );
        console.log(response.data.payload);
        handleOpenSnack(true, response.data.message);
      } catch (error) {
        console.log(error);
        handleOpenSnack(false, error?.response.data.message);
      } finally {
        setLoading(false);
        fetchData(goal_id);
      }
    },
    [token]
  );

  const error = formik.touched.message && formik.errors.message;

  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>

      <StyledWrapper sx={{ gap: "20px" }}>
        <Typography variant="h3" color="darkGreenAccent">
          Feedback
        </Typography>

        {feedbacks?.length > 0 ? (
          feedbacks?.map((feedback) => (
            <FeedbackRow
              key={feedback.id}
              data={feedback}
              onFetch={fetchData}
              handleOpenSnack={handleOpenSnack}
              goalId={goalId}
            />
          ))
        ) : (
          <Typography variant="h3" color="primary">
            No feedback found yet
          </Typography>
        )}

        <form onSubmit={formik.handleSubmit}>
          <Stack gap={2}>
            <Stack gap="3px">
              <TextareaAutosize
                id="message"
                name="message"
                placeholder="Message"
                minRows={2}
                maxRows={10}
                aria-label="Textarea"
                value={formik.values.message}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                style={{
                  width: "100%",
                  padding: "8px",
                  fontSize: "16px",
                  border: error ? "1px solid #d32f2f" : "1px solid #ccc",
                  borderRadius: "4px",
                  outline: "none",
                }}
              />

              {error && (
                <Typography
                  sx={{
                    color: "#d32f2f",
                    fontSize: "0.8571428571428571rem",
                  }}
                >
                  {error}
                </Typography>
              )}
            </Stack>

            {!!formik?.values?.message.trim() ? (
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <StyledSmallDarkBtn
                  type="submit"
                  sx={{ width: { xs: "100%", lg: "130px" } }}
                >
                  send message
                </StyledSmallDarkBtn>

                {loading && <CircularProgress size={20} />}
              </Box>
            ) : (
              <StyledDisabledSmallBtn disabled={true}>
                send message
              </StyledDisabledSmallBtn>
            )}
          </Stack>
        </form>
      </StyledWrapper>
    </>
  );
};

export default Feedback;
