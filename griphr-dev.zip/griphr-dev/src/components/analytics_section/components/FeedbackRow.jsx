import React, { useCallback, useEffect, useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  ListItemText,
  Menu,
  MenuItem,
  Stack,
  TextareaAutosize,
  Typography,
} from "@mui/material";
import chatIcon from "../../../assets/chat_icon.svg";
import moreHoriz__icon from "../../../assets/moreHoriz__icon.svg";
import delete_inactive from "../../../assets/delete_inactive.svg";
import editIcon from "../../../assets/edit_inactive.svg";
import { useFormik } from "formik";
import * as yup from "yup";
import axiosInstance from "../../../helper/axiosInstance";
import { useSelector } from "react-redux";
import moment from "moment";

const validationSchema = yup.object().shape({
  message: yup.string().required("Message is required"),
});

const FeedbackRow = ({ data, onFetch, handleOpenSnack, goalId }) => {
  const [selectedComment, setSelectedComment] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const open = Boolean(anchorEl);
  const { token, userInfo } = useSelector((state) => state.auth);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };
  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  useEffect(() => {
    if (selectedComment) {
      formik.setValues({
        message: data?.text || "",
      });
    }
  }, [selectedComment]);

  const formik = useFormik({
    initialValues: {
      message: "",
    },
    validationSchema,
  });

  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      editComment(data.id, formik.values.message, goalId);
      setSelectedComment(null);
    } else if (event.key === "Escape") {
      setSelectedComment(null);
    }
  };

  const editComment = useCallback(
    async (id, text, goal_id) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
      };

      try {
        const response = await axiosInstance.put(
          `goals/comments`,
          { id, text },
          config
        );
        console.log(response.data.payload);
        handleOpenSnack(true, response.data.message);
      } catch (error) {
        console.log(error);
        handleOpenSnack(false, error?.response.data.message);
      } finally {
        onFetch(goal_id);
      }
    },
    [token]
  );

  const removeComment = useCallback(
    async (id, goal_id) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
        params: {
          id,
        },
      };

      try {
        const response = await axiosInstance.delete(`goals/comments`, config);
        console.log(response.data.payload);
        handleOpenSnack(true, response.data.message);
      } catch (error) {
        console.log(error);
        handleOpenSnack(false, error?.response.data.message);
      } finally {
        onFetch(goal_id);
      }
    },
    [token]
  );

  const handleEditComment = (comment) => {
    setSelectedComment(comment);
    handleClose();
    handleCloseDialog();
  };

  const handleRemoveComment = (id) => {
    removeComment(id, goalId);
    handleClose();
    handleCloseDialog();
  };

  const error = formik.touched.message && formik.errors.message;

  return (
    <Box
      key={data.id}
      sx={{
        display: "flex",
        gap: 2,
        flexDirection: data.user_id === userInfo.id ? "row-reverse" : "initial",
      }}
    >
      <img
        src={chatIcon}
        alt="chat icon"
        style={{ width: "24px", height: "24px" }}
      />

      {selectedComment ? (
        <Stack gap="3px" width="100%">
          <TextareaAutosize
            id="message"
            name="message"
            placeholder="Message"
            minRows={2}
            maxRows={10}
            aria-label="Textarea"
            value={formik.values.message}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            onKeyDown={handleKeyDown}
            style={{
              width: "100%",
              padding: "8px",
              fontSize: "16px",
              border: error ? "1px solid #d32f2f" : "1px solid #ccc",
              borderRadius: "4px",
              outline: "none",
            }}
          />
          <Typography variant="body2">
            escape to cancel • enter to save
          </Typography>
          {error && (
            <Typography
              sx={{
                color: "#d32f2f",
                fontSize: "0.8571428571428571rem",
              }}
            >
              {error}
            </Typography>
          )}
        </Stack>
      ) : (
        <Box
          sx={{
            textAlign: data.user_id === userInfo.id ? "right" : "initial",
            flex: 1,
          }}
        >
          <Typography variant="body1" color="inactive.main" sx={{}}>
            <span style={{ textTransform: "capitalize" }}>
              {data.user_id === userInfo.id
                ? `${moment(data?.created_at).fromNow()} . You`
                : `${data.first_name} ${data.last_name} . ${moment(
                    data?.created_at
                  ).fromNow()}`}
            </span>
            <br />
            {data.text}
          </Typography>
        </Box>
      )}

      {data.user_id === userInfo.id && (
        <IconButton onClick={handleClick} sx={{ alignSelf: "flex-start" }}>
          <img
            src={moreHoriz__icon}
            alt="more horizontal icon"
            style={{ width: "24px", height: "24px" }}
          />
        </IconButton>
      )}

      <Menu anchorEl={anchorEl} open={open} onClose={handleClose}>
        <MenuItem
          onClick={() => handleEditComment(data)}
          sx={{
            justifyContent: "flex-end",
            gap: "16px",
            color: "inactive.main",
          }}
        >
          <ListItemText sx={{ opacity: "0.7", textAlign: "right" }}>
            Edit Comment
          </ListItemText>

          <Box component={"img"} src={editIcon} />
        </MenuItem>

        <MenuItem
          onClick={handleOpenDialog}
          sx={{
            justifyContent: "flex-end",
            gap: "16px",
            color: "inactive.main",
          }}
        >
          <ListItemText sx={{ opacity: "0.7", textAlign: "right" }}>
            Remove Comment
          </ListItemText>

          <Box component={"img"} src={delete_inactive} />
        </MenuItem>
      </Menu>

      <Dialog
        open={openDialog}
        onClose={handleCloseDialog}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          {`Confirm Comment Remove`}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {`Are you sure you want to remove this comment?`}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} autoFocus>
            cancel
          </Button>
          <Button onClick={() => handleRemoveComment(data.id)} color="error">
            Remove
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default FeedbackRow;
