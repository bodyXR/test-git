import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import { Box } from "@mui/material";

// Create Folder called createSupplyValueJob sibling with supplyValueJobs and move this component to it
const Editor = ({ onChange, editorLoaded, value }) => {
  return (
    <div>
      {editorLoaded ? (
        <Box
          dir="ltr"
          // Do this to make all the data related to this component inside the same file,
          // Instead of adding global css class in index.css
          sx={{
            "& .ck-editor__editable": {
              height: `150px`,
            },
            width: "99.7%",
          }}
        >
          <CKEditor
            editor={ClassicEditor}
            data={value}
            onChange={(event, editor) => {
              const data = editor.getData();
              onChange(data);
            }}
            config={{ language: "en" }}
            id={"description-text-area"}
          />
        </Box>
      ) : (
        <div>Editor loading</div>
      )}
    </div>
  );
};

export default Editor;
