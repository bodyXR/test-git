import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsers } from "../../redux/slices/admin/users/usersActions";
import Employees from "./Employees";
import { InputAdornment, Stack, TextField } from "@mui/material";
import search from "../../assets/search.svg";

const EmployeeCards = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: fetchedUsersData } = useSelector((state) => state.users);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    if (token) {
      dispatch(fetchUsers({}));
    }
  }, [token, dispatch]);

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const filteredUsersData = fetchedUsersData?.data
    ?.slice()
    ?.sort((a, b) => {
      return a?.first_name?.localeCompare(b?.first_name);
    })
    .filter((user) => {
      // Split the search query into words
      const searchWords = searchQuery.toLowerCase().split(" ");

      // If more than one word, search both first and last names
      if (searchWords.length > 1) {
        return searchWords.every(
          (word) =>
            user.first_name.toLowerCase().includes(word) ||
            user.last_name.toLowerCase().includes(word)
        );
      } else {
        // Otherwise, use the original logic
        return (
          user.first_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.last_name.toLowerCase().includes(searchQuery.toLowerCase())
        );
      }
    });

  return (
    <Stack gap={3}>
      <TextField
        name="search_employee"
        fullWidth
        size="small"
        type="search"
        variant="outlined"
        value={searchQuery}
        onChange={handleSearchChange}
        sx={{
          background: "white",
          "& .MuiInputBase-input": {
            py: "9.45px",
          },
        }}
        placeholder="Search Employee"
        InputProps={{
          endAdornment: (
            <InputAdornment position="start">
              <img src={search} alt="search icon" />
            </InputAdornment>
          ),
        }}
      />
      <Employees data={filteredUsersData} />
    </Stack>
  );
};

export default EmployeeCards;
