import { useLocation, useOutletContext } from "react-router-dom";
import { useEffect } from "react";
import { Alert, CircularProgress, Snackbar } from "@mui/material";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import CardEmployee from "../CardEmployee";
import { useState } from "react";
import CustomModal from "../../ui/CustomModal";
import EmployeeProfile from "../EmployeeProfile";
import { useDispatch, useSelector } from "react-redux";
import { editUser } from "../../redux/slices/admin/users/usersActions";
import { useFormik } from "formik";
import * as yup from "yup";
import EditForm from "../../pages/employee/mySkills/EditForm";
import EmployeesInitialPage from "../../pages/admin/employees/EmployeesInitialPage";

const validationSchema = yup.object().shape({
  firstName: yup.string().required("First name is required"),
  lastName: yup.string().required("Last name is required"),
  systemRole: yup.string().required("Access level is required"),
});

const Employees = ({ data }) => {
  const location = useLocation();
  const [title, setTitle] = useOutletContext();
  const [clickedEmployeeData, setClickedEmployeeData] = useState(null);
  const dispatch = useDispatch();

  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleSnackClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  // Edit functionalities
  const [openEditForm, setOpenEditForm] = useState(false);
  const [editFormLoading, setEditFormLoading] = useState(false);

  const handleOpenEditForm = () => setOpenEditForm(true);
  const handleCloseEditForm = () => setOpenEditForm(false);

  useEffect(() => {
    formik.setValues({
      firstName: clickedEmployeeData?.first_name || "",
      lastName: clickedEmployeeData?.last_name || "",
      phone: clickedEmployeeData?.phone || "",
      location: clickedEmployeeData?.location || "",
      gender: clickedEmployeeData?.gender || "",
      gender: clickedEmployeeData?.gender || "",
      systemRole: clickedEmployeeData?.system_role || "",
    });
  }, [clickedEmployeeData]);

  const formik = useFormik({
    initialValues: {
      firstName: "",
      lastName: "",
      phone: "",
      location: "",
      gender: "",
      systemRole: "",
    },
    validationSchema,
    onSubmit: async (values, { setSubmitting }) => {
      // submit to the server
      // Assuming the editUser function returns a promise
      setEditFormLoading(true);
      dispatch(editUser({ id: clickedEmployeeData.id, ...values }))
        .then(() => {
          handleOpenSnack(true, "User updated successfully");
        })
        .catch(() => {
          handleOpenSnack(false, "Operation failed");
        })
        .finally(() => {
          setEditFormLoading(false);
          setSubmitting(false);
          handleCloseEditForm();
        });
    },
  });

  useEffect(() => {
    setTitle(location.pathname.split("/").at(-1));
  }, [location, setTitle]);

  const { data: fetchedUsersData, loading } = useSelector(
    (state) => state.users
  );

  const [open, setOpen] = useState(false);
  const [dialogData, setDialogData] = useState(null);

  const dialogHandler = (selectedData) => {
    setOpen(true);
    setDialogData(selectedData);
  };
  const handleClose = () => setOpen(false);

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleSnackClose}
      >
        <Alert
          onClose={handleSnackClose}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>

      <CustomModal
        open={openEditForm}
        onClose={handleCloseEditForm}
        title={`edit information`}
      >
        <EditForm
          formik={formik}
          loading={editFormLoading}
          closeModal={handleCloseEditForm}
        />
      </CustomModal>

      <CustomModal open={open} onClose={handleClose} title=" ">
        <EmployeeProfile data={dialogData} />
      </CustomModal>

      {loading ? (
        <>
          <CircularProgress />
        </>
      ) : (
        <Grid2
          container
          rowSpacing={"28px"}
          columnSpacing={"20px"}
          columns={{ xs: 4, sm: 8, md: 12, lg: 12, xl: 20 }}
        >
          {data?.length > 0 ? (
            data.map((employee, index) => (
              <Grid2
                id={index === 0 ? "manager__step__1" : `${employee.id}`}
                xs={4}
                key={index}
              >
                <CardEmployee
                  onOpen={dialogHandler}
                  data={employee}
                  handleOpenEditForm={handleOpenEditForm}
                  setClickedEmployeeData={setClickedEmployeeData}
                />
              </Grid2>
            ))
          ) : (
            <Grid2 xs={20}>
              <EmployeesInitialPage />
            </Grid2>
          )}
        </Grid2>
      )}
    </>
  );
};

export default Employees;
