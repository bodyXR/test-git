import React from "react";
import Jobs from "../jobs/Jobs";

const Projects = () => {
  return <Jobs projects={true} />;
};

export default Projects;
