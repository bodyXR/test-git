import { Typography } from "@mui/material";

const CareerPath = () => {
  return (
    <>
      <Typography variant="h3" component="h2" color={"primary.main"} mb={2.5}>
        Career Path
      </Typography>
    </>
  );
};
export default CareerPath;
