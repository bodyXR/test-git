import { Typography, styled } from "@mui/material";

const StyledCandidatesRowBody1 = styled(Typography)(({ theme }) => ({
  textTransform: "capitalize",
  color: theme.palette.inactive.main,
  textOverflow: "ellipsis",
  overflow: "hidden",
  textAlign: "center",
}));

export default StyledCandidatesRowBody1;
