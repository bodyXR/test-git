import { TextField, styled } from "@mui/material";

const StyledCustomTextField = styled(TextField)(({ theme }) => ({
  "& .MuiInputBase-input": {
    color: theme.palette.darkGreen,
    padding: "9px 12px",
    lineHeight: 1.5,
    fontSize: "16px",
    [theme.breakpoints.up("lg")]: {
      padding: "12.5px 12px",
    },
  },
  "& .MuiOutlinedInput-root": {
    "& fieldset": {
      border: `1px solid`,
      borderColor: `${theme.palette.darkGrey}`,
    },
    "&:hover fieldset": {
      borderColor: theme.palette.darkerGreen,
    },
    "&.Mui-focused fieldset": {
      borderColor: theme.palette.darkerGreen,
    },
    width: "300px",
  },
  "& fieldset": {
    border: `1px solid `,
    borderColor: theme.palette.darkGrey,
    borderRadius: "4px",
  },
}));

export default StyledCustomTextField;
