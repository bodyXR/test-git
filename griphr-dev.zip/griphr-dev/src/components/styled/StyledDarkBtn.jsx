import { Button, styled } from "@mui/material";

const StyledDarkBtn = styled(Button)(({ theme, min_width }) => ({
  color: "#fff",
  backgroundColor: theme.palette.darkGreenAccent,
  padding: "10px",
  border: "1px solid",
  borderColor: theme.palette.darkGreenAccent,
  borderRadius: "5px",
  textTransform: "capitalize",
  "&:hover": {
    backgroundColor: theme.palette.lightGreen,
  },
  fontSize: "14px",
  fontWeight: 600,
  [theme.breakpoints.up("lg")]: {
    minWidth: min_width || "150px",
  },
}));

export default StyledDarkBtn;
