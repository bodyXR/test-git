import { Button, styled } from "@mui/material";

const StyledDarkOutlinedBtn = styled(Button)(({ theme, min_width }) => ({
  color: theme.palette.darkGreen,
  borderColor: theme.palette.darkGreen,
  padding: "10px",
  borderRadius: "5px",
  textTransform: "capitalize",
  border: "1px solid",
  fontSize: "14px",
  fontWeight: 600,
  [theme.breakpoints.up("lg")]: {
    minWidth: min_width || "150px",
  },
}));

export default StyledDarkOutlinedBtn;
