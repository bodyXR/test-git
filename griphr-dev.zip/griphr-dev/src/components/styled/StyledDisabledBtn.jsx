import { Button, styled } from "@mui/material";

const StyledDisabledBtn = styled(Button)(({ theme }) => ({
  color: "darkGrey",
  backgroundColor: theme.palette.background.modal,
  padding: "10px",
  borderRadius: "5px",
  textTransform: "capitalize",
  "&:hover": {
    backgroundColor: theme.palette.background.modal,
  },
  fontSize: "14px",
  fontWeight: 600,
  [theme.breakpoints.up("lg")]: {
    minWidth: "150px",
  },
}));

export default StyledDisabledBtn;
