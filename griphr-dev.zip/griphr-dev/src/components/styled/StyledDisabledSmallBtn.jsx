import { Button, styled } from "@mui/material";

const StyledDisabledSmallBtn = styled(Button)(({ theme }) => ({
  fontSize: "12px",
  fontWeight: 500,
  color: "darkGrey",
  backgroundColor: theme.palette.background.modal,
  padding: 0,
  borderRadius: "3px",
  textTransform: "capitalize",
  "&:hover": {
    backgroundColor: theme.palette.background.modal,
  },
  [theme.breakpoints.up("lg")]: {
    maxWidth: "130px",
  },
}));

export default StyledDisabledSmallBtn;
