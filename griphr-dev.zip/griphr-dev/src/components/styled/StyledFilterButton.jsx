import { Button, styled } from "@mui/material";

const StyledFilterButton = styled(Button)(({ theme, hasEmployees }) => ({
  width: "100%",
  [theme.breakpoints.up("lg")]: {
    width: "initial",
  },
  [theme.breakpoints.up("xl")]: {
    width: hasEmployees ? "180px" : "250px",
  },
  height: "39px",
  textTransform: "none",
  background: "white",
  border: "1px solid #C0C0C0 ",
  borderRadius: "4px",
  px: "12px",
  flexShrink: 0,
  display: "flex",
  justifyContent: "space-between",
}));

export default StyledFilterButton;
