import { Checkbox, styled } from "@mui/material";
import CheckBoxActiveImg from "../CheckBoxActiveImg";
import CheckBoxInActiveImg from "../CheckBoxInActiveImg";

const StyledFilterCheckbox = styled(Checkbox)({});

StyledFilterCheckbox.defaultProps = {
  icon: <CheckBoxInActiveImg />,
  checkedIcon: <CheckBoxActiveImg />,
};

export default StyledFilterCheckbox;
