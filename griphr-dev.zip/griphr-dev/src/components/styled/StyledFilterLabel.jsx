import { FormControlLabel, styled } from "@mui/material";

const StyledFilterLabel = styled(FormControlLabel)(({ theme }) => ({
  marginRight: 0,
  "& .MuiTypography-root": {
    color: theme.palette.inactive.main,
    fontSize: "16px",
    opacity: 0.7,
  },
}));

export default StyledFilterLabel;
