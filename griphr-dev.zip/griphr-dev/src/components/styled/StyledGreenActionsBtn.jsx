import { Button, styled } from "@mui/material";
import { forwardRef } from "react";

const StyledGreenActionsBtn = styled(
  forwardRef((props, ref) => {
    const { expand, ...other } = props;
    return <Button ref={ref} {...other} />;
  })
)(({ theme, expand }) => ({
  width: "100%",
  color: theme.palette.darkGreen,
  textTransform: "capitalize",
  backgroundColor: theme.palette.accent,
  border: "none",
  borderRadius: "4px",
  paddingInline: "12px",
  paddingBlock: "10px",
  fontSize: "14px",
  "&:hover": {
    backgroundColor: theme.palette.accent,
    border: "none",
    outline: `1px solid ${theme.palette.darkGrey}`,
  },
  "& .MuiSvgIcon-root": {
    transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
    transition: theme.transitions.create("transform", {
      duration: theme.transitions.duration.shortest,
    }),
  },
}));

export default StyledGreenActionsBtn;
