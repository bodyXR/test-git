import { IconButton, styled } from "@mui/material";

const StyledGreenIconBtn = styled(IconButton)(({ theme, isclicked = 0 }) => ({
  border: "1px solid",
  borderRadius: "5px",
  borderColor: isclicked ? theme.palette.accent : theme.palette.darkGreen,
  padding: "10px",
  "&:hover": {
    backgroundColor: isclicked ? theme.palette.accent : "transparent",
  },
  backgroundColor: isclicked ? theme.palette.accent : "transparent",
}));

export default StyledGreenIconBtn;
