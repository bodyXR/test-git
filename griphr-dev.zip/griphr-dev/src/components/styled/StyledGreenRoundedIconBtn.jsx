import { IconButton, styled } from "@mui/material";
import React from "react";

const StyledGreenRoundedIconBtn = styled(IconButton)(({ theme }) => ({
  backgroundColor: theme.palette.accent,
  "& .MuiSvgIcon-root": {
    color: theme.palette.background.white,
  },
  boxShadow: ` 0px 2.909px 7.273px 0px rgba(0, 0, 0, 0.10)`,
  "&:hover": {
    backgroundColor: theme.palette.skillGreen,
  },
}));

export default StyledGreenRoundedIconBtn;
