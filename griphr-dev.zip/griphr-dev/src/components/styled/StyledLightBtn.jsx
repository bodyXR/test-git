import { Button, styled } from "@mui/material";

const StyledLightBtn = styled(Button)(({ theme }) => ({
  color: theme.palette.inactive.main,
  backgroundColor: theme.palette.background.modal,
  borderRadius: "5px",
  textTransform: "none",
  "&:hover": {
    backgroundColor: theme.palette.background.modal,
  },
  fontSize: "14px",
  fontWeight: 600,
}));

export default StyledLightBtn;
