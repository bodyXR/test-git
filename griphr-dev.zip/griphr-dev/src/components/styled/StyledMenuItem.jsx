import { MenuItem, styled } from "@mui/material";

const StyledMenuItem = styled(MenuItem)(({ theme }) => ({
  textAlign: "left",
  color: theme.palette.inactive.main,
  gap: "16px",
  [theme.breakpoints.up("sm")]: {
    textAlign: "center",
    justifyContent: "center",
    flexdirection: "row",
  },
}));

export default StyledMenuItem;