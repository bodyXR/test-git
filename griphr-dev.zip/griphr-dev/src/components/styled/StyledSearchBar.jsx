import { TextField, styled } from "@mui/material";

const StyledSearchBar = styled(TextField)(({ theme }) => ({
  background: "white",
  "& .MuiInputBase-input": {
    paddingBlock: "9.45px",
  },
}));

export default StyledSearchBar;
