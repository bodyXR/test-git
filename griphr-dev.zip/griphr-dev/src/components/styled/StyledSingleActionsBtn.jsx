import { Button, styled } from "@mui/material";

const StyledSingleActionsBtn = styled((props) => {
  const { expand, ...other } = props;
  return <Button {...other} />;
})(({ theme, expand }) => ({
  paddingInline: "10px",
  fontSize: "12px",
  fontWeight: 500,
  color: theme.palette.darkGreen,
  border: "1px solid",
  borderColor: "currentcolor",
  paddingBlock: 0,
  textTransform: "capitalize",
  "& .MuiSvgIcon-root": {
    transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
    width: "17px",
    height: "17px",
    transition: theme.transitions.create("transform", {
      duration: theme.transitions.duration.shortest,
    }),
  },
}));

export default StyledSingleActionsBtn;
