import { Slider, styled } from "@mui/material";

const StyledSlider = styled(Slider)(({ theme }) => ({
  "& .MuiSlider-thumb": {
    color: theme.palette.accent,
  },
  "& .MuiSlider-track": {
    color: theme.palette.accent,
  },
}));

export default StyledSlider;
