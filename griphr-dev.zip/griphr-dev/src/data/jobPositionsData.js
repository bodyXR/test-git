export const jobPositions = [
  {
    jobTitle: "Senior UI Developer",
    skills: [
      {
        name: "Critical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Marketing Strategy",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Analytical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Vendor Management",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 2,
      },
      {
        name: "Project Management",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Campaign Structuring",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Innovative Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 2,
      },
      {
        name: "Social Media Marketing",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Critical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Marketing Strategy",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Analytical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
    ],
  },
  {
    jobTitle: "Junior UI Developer",
    skills: [
      {
        name: "Critical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Marketing Strategy",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 2,
      },
      {
        name: "Analytical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Vendor Management",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Project Management",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Campaign Structuring",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 2,
      },
      {
        name: "Innovative Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Social Media Marketing",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 2,
      },
      {
        name: "Critical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Marketing Strategy",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Analytical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
    ],
  },
  {
    jobTitle: "Senior Back End Developer",
    skills: [
      {
        name: "Critical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Marketing Strategy",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Analytical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Vendor Management",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 2,
      },
      {
        name: "Project Management",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Campaign Structuring",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Innovative Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 2,
      },
      {
        name: "Social Media Marketing",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Critical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Marketing Strategy",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Analytical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
    ],
  },
  {
    jobTitle: "Junior Back End Developer",
    skills: [
      {
        name: "Critical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Marketing Strategy",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Analytical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Vendor Management",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 2,
      },
      {
        name: "Project Management",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Campaign Structuring",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Innovative Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 2,
      },
      {
        name: "Social Media Marketing",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
      {
        name: "Critical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 4,
      },
      {
        name: "Marketing Strategy",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 3,
      },
      {
        name: "Analytical Thinking",
        description:
          "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa... Show more",
        status: 1,
      },
    ],
  },
];
