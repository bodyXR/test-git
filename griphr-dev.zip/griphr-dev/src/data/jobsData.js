export const jobs = [
  {
    id: 1,
    title: "marketing manager 1",
    department: "marketing department",
    startDate: "17/07/2023",
    kind: "fulltime",
    salary: "1500",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae qui quisquam maxime impedit voluptas at inventore, eius nulla unde recusandae corrupti magni adipisci natus eveniet fuga. Temporibus laborum eligendi quaerat.",
    status: "declined",
  },
  {
    id: 2,
    title: "marketing manager 2",
    department: "marketing department",
    startDate: "17/07/2023",
    kind: "fulltime",
    salary: "1400",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae qui quisquam maxime impedit voluptas at inventore, eius nulla unde recusandae corrupti magni adipisci natus eveniet fuga. Temporibus laborum eligendi quaerat.",
    status: "approved",
  },
  {
    id: 3,
    title: "marketing manager 3",
    department: "marketing department",
    startDate: "17/07/2023",
    kind: "fulltime",
    salary: "1300",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae qui quisquam maxime impedit voluptas at inventore, eius nulla unde recusandae corrupti magni adipisci natus eveniet fuga. Temporibus laborum eligendi quaerat.",
    status: "approved",
  },
  {
    id: 4,
    title: "marketing manager 4",
    department: "marketing department",
    startDate: "17/07/2023",
    kind: "fulltime",
    salary: "1600",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae qui quisquam maxime impedit voluptas at inventore, eius nulla unde recusandae corrupti magni adipisci natus eveniet fuga. Temporibus laborum eligendi quaerat.",
    status: "approved",
  },
  {
    id: 5,
    title: "marketing manager 5",
    department: "marketing department",
    startDate: "17/07/2023",
    kind: "fulltime",
    salary: "1200",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae qui quisquam maxime impedit voluptas at inventore, eius nulla unde recusandae corrupti magni adipisci natus eveniet fuga. Temporibus laborum eligendi quaerat.",
    status: "approved",
  },
  {
    id: 6,
    title: "marketing manager 6",
    department: "marketing department",
    startDate: "17/07/2023",
    kind: "fulltime",
    salary: "1700",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae qui quisquam maxime impedit voluptas at inventore, eius nulla unde recusandae corrupti magni adipisci natus eveniet fuga. Temporibus laborum eligendi quaerat.",
    status: "approved",
  },
];
