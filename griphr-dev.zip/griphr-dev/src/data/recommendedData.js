export const recommendedData = [
  {
    title: "SAP Manager",
    matchStrength: "Very high",
  },
  {
    title: "Product Manager",
    matchStrength: "Moderate",
  },
  {
    title: "Ops Manager",
    matchStrength: "Low",
  },
];
