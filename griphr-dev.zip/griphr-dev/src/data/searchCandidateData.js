export const searchCandidateHeaders = [
  { title: "Candidate", space: 2.5 },
  { title: "Skill matching", space: 1.5 },
  { title: "Hourly rate", space: 1.5 },
  { title: "Availability", space: 1.5 },
  { title: "Skills", space: 3 },
  { title: "", space: 1.5 },
];
