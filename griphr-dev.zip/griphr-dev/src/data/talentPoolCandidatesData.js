export const talentPoolCandidatesHeaders = [
  { title: "Candidate", space: 5.5 },
  { title: "Hourly rate", space: 2 },
  { title: "Availability", space: 2 },
  { title: "", space: 1.5 },
];
