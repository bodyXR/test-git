const filterFalsyValues = (values) =>
  Object.keys(values).reduce((acc, key) => {
    if (values[key]) {
      acc[key] = values[key];
    }
    return acc;
  }, {});

export default filterFalsyValues;
