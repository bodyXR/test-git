import { useState } from "react";

const useDialog = () => {
  const [openDialog, setIsOpen] = useState(false);

  const handleOpenDialog = () => setIsOpen(true);
  const handleCloseDialog = () => setIsOpen(false);

  return { openDialog, handleOpenDialog, handleCloseDialog };
};

export default useDialog;