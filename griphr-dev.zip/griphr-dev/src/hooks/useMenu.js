import { useState } from "react";

const useMenu = () => {
  const [menuAnchorEl, setMenuAnchorEl] = useState(null);
  const open = Boolean(menuAnchorEl);

  const handleOpen = (event) => {
    setMenuAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setMenuAnchorEl(null);
  };

  return { menuAnchorEl, open, handleOpen, handleClose };
};

export default useMenu;
