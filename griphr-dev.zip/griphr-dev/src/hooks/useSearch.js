import { matchSorter } from "match-sorter";
import { useState } from "react";

const useSearch = (data, keys = []) => {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredData = matchSorter(data, searchQuery, {
    keys: [...keys],
  });

  return { searchQuery, setSearchQuery, filteredData };
};

export default useSearch;
