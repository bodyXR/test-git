import { useEffect } from "react";
import { useOutletContext } from "react-router-dom";

const useTitle = (location, segmentIndex = -1) => {
  const [, setTitle] = useOutletContext();
  useEffect(() => {
    setTitle(location.pathname.split("/").at(segmentIndex));
  }, []);
};

export default useTitle;
