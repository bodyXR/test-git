import {
  Alert,
  Box,
  CircularProgress,
  IconButton,
  Snackbar,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import React, { useCallback, useState } from "react";
import StyledCustomTextField from "../../../components/styled/StyledCustomTextField";
import { useFormik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../helper/axiosInstance";
import { fetchDepartments } from "../../../redux/slices/admin/companyProfile/configSlice";
import * as yup from "yup";

const validationSchema = yup.object().shape({
  department: yup.string().required("Department is required"),
});

const AddDepartmentForm = () => {
  const [loading, setLoading] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  const formik = useFormik({
    initialValues: {
      department: "",
    },
    validationSchema,
    onSubmit: (values, { setSubmitting, resetForm }) => {
      setTimeout(() => {
        // submit to the server
        createDepartment(token, values);
        resetForm();
        setSubmitting(false);
      }, 1000);
    },
  });

  const createDepartment = useCallback(
    async (token, values) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `config`,
          {
            operation: "departments",
            value: values.department,
          },
          config
        );
        console.log(response.data);
        handleOpenSnack(true, response.data.message);
        dispatch(fetchDepartments());
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
        console.log(error?.response.data);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>

      <form onSubmit={formik.handleSubmit}>
        <Box sx={{ display: "flex" }}>
          <StyledCustomTextField
            id="department"
            name="department"
            label="Add new department"
            size="medium"
            type="text"
            value={formik.values.department}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            helperText={
              formik.touched.department ? formik.errors.department : ""
            }
            error={
              formik.touched.department && Boolean(formik.errors.department)
            }
            variant="outlined"
            sx={{
              "& .MuiInputBase-input": { py: "11px" },
              "& fieldset": {
                borderRadius: 0,
                borderTopLeftRadius: "4px",
                borderBottomLeftRadius: "4px",
              },
              "& .MuiOutlinedInput-root": {
                width: { xs: "100%", lg: "300px" },
              },
            }}
            InputLabelProps={{
              style: {
                top: formik.values.department ? "0px" : "-3px", // Adjust based on content
              },
            }}
          />

          <IconButton
            type="submit"
            disabled={formik.isSubmitting}
            sx={{
              width: "45px",
              height: "45px",
              backgroundColor: "accent",
              p: 0,
              borderRadius: 0,
              borderTopRightRadius: "4px",
              borderBottomRightRadius: "4px",
            }}
          >
            <AddIcon
              sx={{ width: "21px", height: "21px", color: "darkGreen" }}
            />
          </IconButton>

          {loading && (
            <CircularProgress size={20} sx={{ alignSelf: "center", ml: 1 }} />
          )}
        </Box>
      </form>
    </>
  );
};

export default AddDepartmentForm;
