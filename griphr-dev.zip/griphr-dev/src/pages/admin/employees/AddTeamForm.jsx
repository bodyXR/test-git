import {
  Alert,
  Box,
  CircularProgress,
  IconButton,
  Snackbar,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import React, { useCallback, useState } from "react";
import StyledCustomTextField from "../../../components/styled/StyledCustomTextField";
import { useFormik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { fetchTeams } from "../../../redux/slices/admin/companyProfile/configSlice";
import axiosInstance from "../../../helper/axiosInstance";
import * as yup from "yup";

const validationSchema = yup.object().shape({
  team: yup.string().required("Team is required"),
});

const AddTeamForm = () => {
  const [loading, setLoading] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  const formik = useFormik({
    initialValues: {
      team: "",
    },
    validationSchema,
    onSubmit: (values, { setSubmitting, resetForm }) => {
      setTimeout(() => {
        // submit to the server
        createTeam(token, values);
        resetForm();
        setSubmitting(false);
      }, 1000);
    },
  });

  const createTeam = useCallback(
    async (token, values) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `config`,
          {
            operation: "teams",
            value: values.team,
          },
          config
        );
        console.log(response.data);
        handleOpenSnack(true, response.data.message);
        dispatch(fetchTeams());
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
        console.log(error?.response.data);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>

      <form onSubmit={formik.handleSubmit}>
        <Box sx={{ display: "flex" }}>
          <StyledCustomTextField
            id="team"
            name="team"
            label="Add new team"
            size="medium"
            type="text"
            value={formik.values.team}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            helperText={formik.touched.team ? formik.errors.team : ""}
            error={formik.touched.team && Boolean(formik.errors.team)}
            variant="outlined"
            sx={{
              "& .MuiInputBase-input": { py: "11px" },
              "& fieldset": {
                borderRadius: 0,
                borderTopLeftRadius: "4px",
                borderBottomLeftRadius: "4px",
              },
              "& .MuiOutlinedInput-root": {
                width: { xs: "100%", lg: "300px" },
              },
            }}
            InputLabelProps={{
              style: {
                top: formik.values.team ? "0px" : "-3px", // Adjust based on content
              },
            }}
          />

          <IconButton
            type="submit"
            disabled={formik.isSubmitting}
            sx={{
              width: "45px",
              height: "45px",
              backgroundColor: "accent",
              p: 0,
              borderRadius: 0,
              borderTopRightRadius: "4px",
              borderBottomRightRadius: "4px",
            }}
          >
            <AddIcon
              sx={{ width: "21px", height: "21px", color: "darkGreen" }}
            />
          </IconButton>

          {loading && (
            <CircularProgress size={20} sx={{ alignSelf: "center", ml: 1 }} />
          )}
        </Box>
      </form>
    </>
  );
};

export default AddTeamForm;
