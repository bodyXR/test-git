import {
  Box,
  Dialog,
  IconButton,
  ListItemText,
  Menu,
  MenuItem,
  Stack,
  Typography,
} from "@mui/material";
import Close from "@mui/icons-material/Close";
import cautionIcon from "../../../assets/caution_icon.svg";
import invitationIcon from "../../../assets/invitation_icon.svg";
import React, { useCallback, useState } from "react";
import axiosInstance from "../../../helper/axiosInstance";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsers } from "../../../redux/slices/admin/users/usersActions";
import StyledDarkBtn from "../../../components/styled/StyledDarkBtn";
import StyledOutlinedBtn from "../../../components/styled/StyledOutlinedBtn";

const BulkActions = ({
  actionsAnchorEl,
  actionsOpen,
  handleActionsMenuClose,
  selectedEmployees,
  setSelectedEmployees,
  handleOpenSnack,
}) => {
  const [openDialog1, setOpenDialog1] = useState(false);
  const [openDialog2, setOpenDialog2] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  const handleOpenDialog1 = () => {
    setOpenDialog1(true);
  };
  const handleCloseDialog1 = () => {
    setOpenDialog1(false);
  };

  const handleOpenDialog2 = () => {
    setOpenDialog2(true);
  };
  const handleCloseDialog2 = () => {
    setOpenDialog2(false);
  };

  const sendInvitations = useCallback(
    async (token, users_ids) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        const response = await axiosInstance.post(
          `bulk-actions`,
          {
            action: "send_invitations",
            users_ids,
          },
          config
        );
        console.log(response.data);
        handleOpenSnack(true, response.data.message);
        dispatch(fetchUsers({}));
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
        console.log(error?.response.data);
      } finally {
        handleActionsMenuClose();
      }
    },
    [token]
  );

  const deleteUsers = useCallback(
    async (token, users_ids) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        params: {
          users_ids,
        },
      };

      try {
        const response = await axiosInstance.delete(`bulk-actions`, config);
        console.log(response.data);
        handleOpenSnack(true, response.data.message);
        dispatch(fetchUsers({}));
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
        console.log(error?.response.data);
      } finally {
        handleActionsMenuClose();
      }
    },
    [token]
  );

  const handleInviteUsers = (users) => {
    sendInvitations(token, users);
    handleCloseDialog1();
    setSelectedEmployees([]);
  };

  const handleDeleteUsers = (users) => {
    deleteUsers(token, users);
    handleCloseDialog2();
    setSelectedEmployees([]);
  };

  return (
    <>
      <Menu
        anchorEl={actionsAnchorEl}
        open={actionsOpen}
        onClose={handleActionsMenuClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
      >
        <MenuItem
          onClick={handleOpenDialog1}
          sx={{
            textAlign: "center",
            color: "inactive.main",
          }}
        >
          <ListItemText>Invite</ListItemText>
        </MenuItem>

        <MenuItem
          onClick={handleOpenDialog2}
          sx={{
            textAlign: "center",
            color: "inactive.main",
          }}
        >
          <ListItemText>Delete</ListItemText>
        </MenuItem>
      </Menu>

      <Dialog
        open={openDialog1}
        onClose={handleCloseDialog1}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <Stack
          sx={{
            justifyContent: "center",
            alignItems: "center",
            textAlign: "center",
            gap: { xs: 3, lg: 5 },
            p: { xs: 2, lg: 5 },
            position: "relative",
            maxWidth: "420px",
          }}
        >
          <IconButton
            onClick={handleCloseDialog1}
            sx={{
              position: "absolute",
              top: 1,
              right: 1,
              p: 0,
              width: "32px",
              height: "32px",
            }}
          >
            <Close />
          </IconButton>
          <Box component="img" src={invitationIcon} />
          <Typography variant="h2" color="secondary.main">
            Invite Employees
          </Typography>
          <Typography variant="body1" color="inactive.main">
            Are you sure you want to send these{" "}
            <span style={{ fontWeight: 600, color: "#0C1716" }}>
              Invitations
            </span>
          </Typography>
          <Stack
            sx={{
              flexDirection: { lg: "row" },
              justifyContent: "space-between",
              alignItems: "center",
              gap: "16px",
              width: "100%",
            }}
          >
            <StyledDarkBtn
              onClick={() => handleInviteUsers(selectedEmployees)}
              sx={{ width: { xs: "100%", lg: "initial" } }}
            >
              invite
            </StyledDarkBtn>

            <StyledOutlinedBtn
              onClick={handleCloseDialog1}
              sx={{
                width: { xs: "100%", lg: "initial" },
                backgroundColor: "softAccent",
                borderColor: "skillGreen",
                color: "skillGreen",
              }}
            >
              cancel
            </StyledOutlinedBtn>
          </Stack>
        </Stack>
      </Dialog>

      <Dialog
        open={openDialog2}
        onClose={handleCloseDialog2}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <Stack
          sx={{
            justifyContent: "center",
            alignItems: "center",
            textAlign: "center",
            gap: { xs: 3, lg: 5 },
            p: { xs: 2, lg: 5 },
            position: "relative",
            maxWidth: "420px",
          }}
        >
          <IconButton
            onClick={handleCloseDialog2}
            sx={{
              position: "absolute",
              top: 1,
              right: 1,
              p: 0,
              width: "32px",
              height: "32px",
            }}
          >
            <Close />
          </IconButton>
          <Box component="img" src={cautionIcon} />
          <Typography variant="h2" color="secondary.main">
            Delete Employees
          </Typography>
          <Typography variant="body1" color="inactive.main">
            Are you sure you want to delete these{" "}
            <span style={{ fontWeight: 600, color: "#0C1716" }}>employees</span>
          </Typography>
          <Stack
            sx={{
              flexDirection: { lg: "row" },
              justifyContent: "space-between",
              alignItems: "center",
              gap: "16px",
              width: "100%",
            }}
          >
            <StyledDarkBtn
              onClick={() => handleDeleteUsers(selectedEmployees)}
              sx={{ width: { xs: "100%", lg: "initial" } }}
            >
              delete
            </StyledDarkBtn>

            <StyledOutlinedBtn
              onClick={handleCloseDialog2}
              sx={{
                width: { xs: "100%", lg: "initial" },
                backgroundColor: "softAccent",
                borderColor: "skillGreen",
                color: "skillGreen",
              }}
            >
              cancel
            </StyledOutlinedBtn>
          </Stack>
        </Stack>
      </Dialog>
    </>
  );
};

export default BulkActions;
