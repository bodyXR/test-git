import React, { useState } from "react";
import {
  Alert,
  Box,
  Button,
  IconButton,
  InputAdornment,
  ListItemText,
  Menu,
  MenuItem,
  Snackbar,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import search from "../../../assets/search.svg";
import StyledDarkBtn from "../../../components/styled/StyledDarkBtn";
import CustomModal from "../../../ui/CustomModal";
import AssignRoleForm from "../../admin/organigram/AssignRoleForm";
import BulkUploadForm from "../../admin/organigram/BulkUploadForm";
import DepartmentsFilter from "./DepartmentsFilter";
import TeamsFilter from "./TeamsFilter";
import RolesFilter from "./RolesFilter";
import BulkActions from "./BulkActions";
import StyledFilterButton from "../../../components/styled/StyledFilterButton";
const ButtonActions = ({
  handleSearchChange,
  searchQuery,
  hasEmployees,
  hasSelectedEmployees,
  selectedEmployees,
  setSelectedEmployees,
  isFetchedUsersData,
}) => {
  const [actionsAnchorEl, setActionsAnchorEl] = useState(null);
  const actionsOpen = Boolean(actionsAnchorEl);
  const [isDepartmentsOpen, setIsDepartmentsOpen] = useState(null);
  const [isTeamsOpen, setIsTeamsOpen] = useState(null);
  const [isRolesOpen, setIsRolesOpen] = useState(null);
  const [isAssignRoleOpen, setIsAssignRoleOpen] = useState(false);
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleActionsMenuOpen = (event) => {
    setActionsAnchorEl(event.currentTarget);
  };
  const handleActionsMenuClose = () => {
    setActionsAnchorEl(null);
  };

  const handleDepartmentsOpen = (event) =>
    setIsDepartmentsOpen(event.currentTarget);
  const handleDepartmentsClose = () => setIsDepartmentsOpen(false);

  const handleTeamsOpen = (event) => setIsTeamsOpen(event.currentTarget);
  const handleTeamsClose = () => setIsTeamsOpen(false);

  const handleRolesOpen = (event) => setIsRolesOpen(event.currentTarget);
  const handleRolesClose = () => setIsRolesOpen(false);

  const handleAssignRoleOpen = () => setIsAssignRoleOpen(true);
  const handleAssignRoleClose = () => setIsAssignRoleOpen(false);

  const handleBulkUploadOpen = () => setIsBulkUploadOpen(true);
  const handleBulkUploadClose = () => setIsBulkUploadOpen(false);

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>

      <CustomModal
        open={isAssignRoleOpen}
        onClose={handleAssignRoleClose}
        title="Add Employee"
        height="95%"
      >
        <AssignRoleForm
          handleOpenSnack={handleOpenSnack}
          closeModal={handleAssignRoleClose}
        />
      </CustomModal>

      <CustomModal
        open={isBulkUploadOpen}
        onClose={handleBulkUploadClose}
        title="Bulk Upload"
      >
        <BulkUploadForm
          handleOpenSnack={handleOpenSnack}
          closeModal={handleBulkUploadClose}
        />
      </CustomModal>

      <Stack
        sx={{
          flexDirection: { lg: "row" },
          alignItems: "center",
          gap: 2,
        }}
      >
        <TextField
          name="search_employee"
          fullWidth
          size="small"
          type="search"
          variant="outlined"
          value={searchQuery}
          onChange={handleSearchChange}
          sx={{
            background: "white",
            "& .MuiInputBase-input": {
              py: "9.45px",
            },
          }}
          placeholder="Search Employee"
          InputProps={{
            endAdornment: (
              <InputAdornment position="start">
                <img src={search} alt="search icon" />
              </InputAdornment>
            ),
          }}
        />

        {hasSelectedEmployees && (
          <Button
            onClick={handleActionsMenuOpen}
            sx={{
              width: {
                xs: "100%",
                lg: "initial",
              },
              height: "39px",
              textTransform: "none",
              backgroundColor: "accent",
              border: "1px solid #C0C0C0 ",
              borderRadius: "4px",
              px: "12px",
              flexShrink: 0,
              display: "flex",
              justifyContent: "space-between",
              "&:hover": {
                backgroundColor: "accent",
              },
            }}
            disableElevation
            disableRipple
            endIcon={
              <KeyboardArrowDownIcon
                sx={{ width: "24px", height: "24px", color: "darkGreen" }}
              />
            }
            variant="outlined"
          >
            <Typography variant="h5" color="darkGreen">
              Actions
            </Typography>
          </Button>
        )}

        <BulkActions
          actionsAnchorEl={actionsAnchorEl}
          actionsOpen={actionsOpen}
          handleActionsMenuClose={handleActionsMenuClose}
          selectedEmployees={selectedEmployees}
          setSelectedEmployees={setSelectedEmployees}
          handleOpenSnack={handleOpenSnack}
        />

        <StyledFilterButton
          onClick={handleDepartmentsOpen}
          hasEmployees={hasEmployees}
          disableElevation
          disableRipple
          endIcon={
            <KeyboardArrowDownIcon
              style={{ width: "24px", height: "24px", color: "darkGrey" }}
            />
          }
          variant="outlined"
        >
          <Typography variant="h5" color="darkGrey">
            Department
          </Typography>
        </StyledFilterButton>

        <DepartmentsFilter
          open={isDepartmentsOpen}
          onClose={handleDepartmentsClose}
          setSelectedEmployees={setSelectedEmployees}
        />

        <StyledFilterButton
          onClick={handleTeamsOpen}
          hasEmployees={hasEmployees}
          disableElevation
          disableRipple
          endIcon={
            <KeyboardArrowDownIcon
              style={{ width: "24px", height: "24px", color: "darkGrey" }}
            />
          }
          variant="outlined"
        >
          <Typography variant="h5" color="darkGrey">
            Team
          </Typography>
        </StyledFilterButton>

        <TeamsFilter
          open={isTeamsOpen}
          onClose={handleTeamsClose}
          setSelectedEmployees={setSelectedEmployees}
        />

        <StyledFilterButton
          onClick={handleRolesOpen}
          hasEmployees={hasEmployees}
          disableElevation
          disableRipple
          endIcon={
            <KeyboardArrowDownIcon
              style={{ width: "24px", height: "24px", color: "darkGrey" }}
            />
          }
          variant="outlined"
        >
          <Typography variant="h5" color="darkGrey">
            Role
          </Typography>
        </StyledFilterButton>

        <RolesFilter
          open={isRolesOpen}
          onClose={handleRolesClose}
          setSelectedEmployees={setSelectedEmployees}
        />

        {isFetchedUsersData && (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              flexShrink: 0,
              width: { xs: "100%", lg: "initial" },
            }}
          >
            <StyledDarkBtn
              onClick={handleAssignRoleOpen}
              min_width="120px"
              sx={{
                borderRadius: 0,
                borderTopLeftRadius: "4px",
                borderBottomLeftRadius: "4px",
                width: { xs: "100%", lg: "initial" },
              }}
            >
              Add Employee
            </StyledDarkBtn>

            <IconButton
              onClick={handleMenuOpen}
              sx={{
                width: "24px",
                height: "44px",
                backgroundColor: "darkGreenAccent",
                p: 0,
                borderRadius: 0,
                borderTopRightRadius: "4px",
                borderBottomRightRadius: "4px",
                borderLeft: "0.5px solid #788894",
              }}
            >
              <KeyboardArrowDownIcon
                sx={{ width: "24px", height: "24px", color: "white" }}
              />
            </IconButton>

            <Menu
              anchorEl={anchorEl}
              open={open}
              onClose={handleMenuClose}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "right",
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "right",
              }}
            >
              <MenuItem
                onClick={handleAssignRoleOpen}
                sx={{
                  textAlign: "center",
                  color: "inactive.main",
                }}
              >
                <ListItemText>Add Employee</ListItemText>
              </MenuItem>

              <MenuItem
                onClick={handleBulkUploadOpen}
                sx={{
                  textAlign: "center",
                  color: "inactive.main",
                }}
              >
                <ListItemText>Bulk Upload</ListItemText>
              </MenuItem>
            </Menu>
          </Box>
        )}
      </Stack>
    </>
  );
};

export default ButtonActions;
