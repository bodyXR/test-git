import { Box, Divider, Stack, Typography } from "@mui/material";
import React, { useEffect } from "react";
import { useLocation, useOutletContext } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { fetchData } from "../../../redux/slices/admin/companyProfile/companyProfileSlice";
import {
  fetchDepartments,
  fetchTeams,
} from "../../../redux/slices/admin/companyProfile/configSlice";
import { fetchJobProfiles } from "../../../redux/slices/admin/jobProfile/jobProfileSlice";
import Department from "./Department";
import Team from "./Team";
import Role from "./Role";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import AddDepartmentForm from "./AddDepartmentForm";
import AddTeamForm from "./AddTeamForm";
import AddRoleForm from "./AddRoleForm";

const Config = () => {
  const location = useLocation();
  const [title, setTitle] = useOutletContext();
  const { fetchedData } = useSelector((state) => state.companyProfile);
  const { departments, teams } = useSelector((state) => state.config);
  const { jobProfile } = useSelector((state) => state.jobProfile);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    setTitle(location.pathname.split("/").at(-1));
  }, [setTitle, location]);

  useEffect(() => {
    dispatch(fetchData(token));
    dispatch(fetchDepartments());
    dispatch(fetchTeams());
    dispatch(fetchJobProfiles(token));
  }, []);

  return (
    <Stack gap={3}>
      <Typography variant="h3" component="h2" color="darkGreen">
        Company Setup -{" "}
        <span style={{ fontWeight: "400" }}>Departments, Teams & Roles</span>
      </Typography>

      <StyledWrapper gap="20px">
        <Typography variant="h3" color="darkGreenAccent">
          Departments
        </Typography>

        <Typography variant="body1" color="inactive.main">
          Create new departments to add to your company profile
        </Typography>

        <AddDepartmentForm />

        <Divider />

        <Typography variant="h3" color="darkGreenAccent">
          Created departments for{" "}
          <span style={{ textTransform: "capitalize" }}>
            {fetchedData?.name}
          </span>
        </Typography>

        {departments?.length > 0 ? (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              flexWrap: "wrap",
              gap: "10px",
            }}
          >
            {departments?.map((department) => (
              <Department key={department} data={department} />
            ))}
          </Box>
        ) : (
          <Typography variant="h3" color="primary">
            No departments found
          </Typography>
        )}
      </StyledWrapper>

      <StyledWrapper gap="20px">
        <Typography variant="h3" color="darkGreenAccent">
          Teams
        </Typography>

        <Typography variant="body1" color="inactive.main">
          Create new teams to add to your company profile
        </Typography>

        <AddTeamForm />

        <Divider />

        <Typography variant="h3" color="darkGreenAccent">
          Created teams for{" "}
          <span style={{ textTransform: "capitalize" }}>
            {fetchedData?.name}
          </span>
        </Typography>

        {teams?.length > 0 ? (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              flexWrap: "wrap",
              gap: "10px",
            }}
          >
            {teams?.map((team) => (
              <Team key={team} data={team} />
            ))}
          </Box>
        ) : (
          <Typography variant="h3" color="primary">
            No teams found
          </Typography>
        )}
      </StyledWrapper>

      <StyledWrapper gap="20px">
        <Typography variant="h3" color="darkGreenAccent">
          Roles
        </Typography>

        <Typography variant="body1" color="inactive.main">
          Create new roles to add to your company profile
        </Typography>

        <AddRoleForm />

        <Divider />

        <Typography variant="h3" color="darkGreenAccent">
          Created roles for{" "}
          <span style={{ textTransform: "capitalize" }}>
            {fetchedData?.name}
          </span>
        </Typography>

        {jobProfile?.length > 0 ? (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              flexWrap: "wrap",
              gap: "10px",
            }}
          >
            {jobProfile?.map((role) => (
              <Role key={role.id} data={role} />
            ))}
          </Box>
        ) : (
          <Typography variant="h3" color="primary">
            No roles found
          </Typography>
        )}
      </StyledWrapper>
    </Stack>
  );
};

export default Config;
