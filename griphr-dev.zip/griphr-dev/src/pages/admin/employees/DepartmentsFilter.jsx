import {
  Box,
  Checkbox,
  InputAdornment,
  MenuItem,
  Popover,
  TextField,
  Typography,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import checkboxIcon from "../../../assets/checkbox_icon.svg";
import search from "../../../assets/search.svg";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchDepartments } from "../../../redux/slices/admin/companyProfile/configSlice";
import { fetchUsers } from "../../../redux/slices/admin/users/usersActions";

const DepartmentsFilter = ({ open, onClose, setSelectedEmployees }) => {
  const [searchfield, setSearchfield] = useState("");
  const [selectedDepartments, setSelectedDepartments] = useState([]);
  const { departments } = useSelector((state) => state.config);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchDepartments());
  }, []);

  const onSearchChange = (event) => {
    setSearchfield(event.target.value);
  };

  const handleCheckboxChange = (department) => {
    const updatedDepartments = [...selectedDepartments];

    if (updatedDepartments.includes(department)) {
      // If department is already selected, remove it
      const index = updatedDepartments.indexOf(department);
      updatedDepartments.splice(index, 1);
    } else {
      // If department is not selected, add it
      updatedDepartments.push(department);
    }

    setSelectedDepartments(updatedDepartments);
    setSelectedEmployees([]);

    // Now you can send the request to fetch users based on the selected departments
    dispatch(fetchUsers({ departments: updatedDepartments }));
  };

  const filteredDepartments = departments
    ?.slice()
    ?.sort((a, b) => {
      return a?.localeCompare(b);
    })
    .filter((department) =>
      department.toLowerCase().includes(searchfield.toLowerCase())
    );

  return (
    <Popover
      anchorEl={open}
      open={Boolean(open)}
      onClose={onClose}
      anchorOrigin={{
        vertical: "bottom", // Adjust the vertical position
        horizontal: "left", // Adjust the horizontal position
      }}
      PaperProps={{
        style: {
          width: "min-content",
          maxHeight: filteredDepartments?.length > 5 ? "250px" : "auto", // set a max height for the menu if there are more than five jobs
          overflow: "auto", // make the menu scrollable
        },
      }}
    >
      <MenuItem
        sx={{
          "&:hover": {
            background: "transparent",
          },
        }}
        disableTouchRipple
      >
        <TextField
          name="search_department"
          fullWidth
          size="small"
          type="search"
          variant="outlined"
          value={searchfield}
          onChange={onSearchChange}
          sx={{
            background: "white",
            "& .MuiInputBase-input": {
              py: "9.45px",
            },
          }}
          placeholder="Search Department"
          InputProps={{
            endAdornment: (
              <InputAdornment position="start">
                <img src={search} alt="search icon" />
              </InputAdornment>
            ),
          }}
        />
      </MenuItem>
      {filteredDepartments?.length > 0 ? (
        filteredDepartments?.map((department) => (
          <MenuItem key={department}>
            <Checkbox
              sx={{ width: "32px", height: "32px", mr: 2 }}
              id={department}
              checked={selectedDepartments.includes(department)}
              onChange={() => handleCheckboxChange(department)}
              color="primary"
              icon={<CheckBoxOutlineBlankIcon sx={{ color: "primary.main" }} />}
              checkedIcon={
                <Box
                  sx={{ width: "24px", height: "24px" }}
                  component={"img"}
                  src={checkboxIcon}
                />
              }
            />
            <Typography variant="h5" color="inactive.main">
              {department}
            </Typography>
          </MenuItem>
        ))
      ) : (
        <MenuItem disabled>No departments found</MenuItem>
      )}
    </Popover>
  );
};

export default DepartmentsFilter;
