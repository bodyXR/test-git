import React, { useEffect, useState } from "react";
import { useLocation, useOutletContext } from "react-router-dom";
import { Stack } from "@mui/material";
import NavigationIcons from "./NavigationIcons";
import ButtonActions from "./ButtonActions";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsers } from "../../../redux/slices/admin/users/usersActions";
import EmployeesTable from "./EmployeesTable";
import Employees from "../../../components/employees_section/Employees";

const EmployeeList = () => {
  const location = useLocation();
  const [title, setTitle] = useOutletContext();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const { token } = useSelector((state) => state.auth);
  const { employeesStyle, data: fetchedUsersData } = useSelector(
    (state) => state.users
  );
  const dispatch = useDispatch();

  useEffect(() => {
    setTitle(location.pathname.split("/").at(-1));
  }, [setTitle, location]);

  useEffect(() => {
    if (token) {
      dispatch(fetchUsers({}));
    }
  }, [token, dispatch]);

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const filteredUsersData = fetchedUsersData?.data
    ?.slice()
    ?.sort((a, b) => {
      return a?.first_name?.localeCompare(b?.first_name);
    })
    .filter((user) => {
      // Split the search query into words
      const searchWords = searchQuery.toLowerCase().split(" ");

      // If more than one word, search both first and last names
      if (searchWords.length > 1) {
        return searchWords.every(
          (word) =>
            user.first_name.toLowerCase().includes(word) ||
            user.last_name.toLowerCase().includes(word)
        );
      } else {
        // Otherwise, use the original logic
        return (
          user.first_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.last_name.toLowerCase().includes(searchQuery.toLowerCase())
        );
      }
    });

  return (
    <Stack gap={3}>
      <NavigationIcons />
      <ButtonActions
        handleSearchChange={handleSearchChange}
        searchQuery={searchQuery}
        isFetchedUsersData={fetchedUsersData?.data?.length > 0}
        hasEmployees={filteredUsersData?.length > 0 ? true : false}
        hasSelectedEmployees={selectedEmployees?.length > 0 ? true : false}
        selectedEmployees={selectedEmployees}
        setSelectedEmployees={setSelectedEmployees}
      />
      {employeesStyle === "table" ? (
        <EmployeesTable
          isFetchedUsersData={fetchedUsersData?.data?.length > 0}
          data={filteredUsersData}
          selectedEmployees={selectedEmployees}
          setSelectedEmployees={setSelectedEmployees}
        />
      ) : (
        <Employees data={filteredUsersData} />
      )}
    </Stack>
  );
};

export default EmployeeList;
