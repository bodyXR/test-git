import {
  Avatar,
  Box,
  Checkbox,
  Dialog,
  Grid,
  IconButton,
  ListItemText,
  Menu,
  MenuItem,
  Stack,
  Typography,
} from "@mui/material";
import Close from "@mui/icons-material/Close";
import checkboxInactiveIcon from "../../../assets/checkbox_inactive.svg";
import checkboxIcon from "../../../assets/checkbox_icon.svg";
import moreHoriz__icon from "../../../assets/moreHoriz__icon.svg";
import cautionIcon from "../../../assets/caution_icon.svg";
import invitationIcon from "../../../assets/invitation_icon.svg";
import React, { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  deleteUser,
  editUser,
  fetchUsers,
} from "../../../redux/slices/admin/users/usersActions";
import StyledDarkBtn from "../../../components/styled/StyledDarkBtn";
import StyledOutlinedBtn from "../../../components/styled/StyledOutlinedBtn";
import CustomModal from "../../../ui/CustomModal";
import EditForm from "../../employee/mySkills/EditForm";
import { useFormik } from "formik";
import * as yup from "yup";
import filterFalsyValues from "../../../helper/filterFalsyValues";
import { unwrapResult } from "@reduxjs/toolkit";
import axiosInstance from "../../../helper/axiosInstance";

const validationSchema = yup.object().shape({
  firstName: yup.string().required("First name is required"),
  lastName: yup.string().required("Last name is required"),
  systemRole: yup.string().required("Access level is required"),
});

const EmployeeRow = ({
  data,
  isLast,
  selectedEmployees,
  onSelectEmployee,
  handleOpenSnack,
}) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [openEditForm, setOpenEditForm] = useState(false);
  const [editFormLoading, setEditFormLoading] = useState(false);
  const [openDialog1, setOpenDialog1] = useState(false);
  const [openDialog2, setOpenDialog2] = useState(false);
  const dispatch = useDispatch();
  const { token } = useSelector((state) => state.auth);
  // {
  //   "id": 1345,
  //   "first_name": "Awad",
  //   "last_name": "Maher",
  //   "email": "vopaj75507@hidelux.com",
  //   "phone": "01101111011",
  //   "location": "Cairo",
  //   "gender": "male",
  //   "is_active": true,
  //   "status": "invitied",
  //   "system_role": "employee",
  //   "profile_picture": null,
  //   "role": {
  //     "id": 1304,
  //     "title": "C++ Developer",
  //     "job_profile_id": 6,
  //     "department": "Marketing",
  //     "team": "software team"
  //   }
  // }
  // console.log("data", data);

  const editRole = useCallback(
    async ({ roleId, manager, team, department, role, user_id }) => {
      console.log("roleId", roleId);
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
        params: roleId ? { id: roleId } : undefined,
      };

      const body = !roleId
        ? {
            user_id,
            manager_id: manager,
            team,
            department,
            job_profile_id: role,
          }
        : {
            manager_id: manager,
            team,
            department,
            job_profile_id: role,
          };

      console.log("before filter", body);
      const filteredBody = filterFalsyValues(body);
      console.log("after filter", filteredBody);
      try {
        let response;
        if (!roleId)
          response = await axiosInstance.post(`role`, filteredBody, config);
        else response = await axiosInstance.put(`role`, filteredBody, config);
        console.log("edit role payload", response?.data?.payload);
      } catch (error) {
        console.log("error", error);
      } finally {
      }
    },
    []
  );

  useEffect(() => {
    formik.setValues({
      firstName: data?.first_name || "",
      lastName: data?.last_name || "",
      phone: data?.phone || "",
      location: data?.location || "",
      gender: data?.gender || "",
      systemRole: data?.system_role || "",
      manager: "",
      department: data?.role?.department || "",
      team: data?.role?.team || "",
      roleId: data?.role?.id || "",
      // role: data?.role?.job_profile_id || "",
      role: "",
    });
  }, [data]);

  const formik = useFormik({
    initialValues: {
      firstName: "",
      lastName: "",
      phone: "",
      location: "",
      gender: "",
      systemRole: "",
      manager: "",
      department: "",
      team: "",
      roleId: +"",
      role: +"",
    },
    validationSchema,
    onSubmit: async (values, { setSubmitting }) => {
      // submit to the server
      // Assuming the editUser function returns a promise
      setEditFormLoading(true);

      // fitler out empty string values
      const filteredValues = filterFalsyValues(values);
      dispatch(editUser({ id: data.id, ...filteredValues }))
        .then(unwrapResult)
        .then(() => {
          return editRole({
            user_id: data?.id,
            roleId: data?.role?.id,
            manager: values?.manager,
            team: values?.team,
            department: values?.department,
            role: values?.role,
          });
        })
        .then(() => {
          return dispatch(fetchUsers({}));
        })
        .then(() => {
          handleOpenSnack(true, "User updated successfully");
        })
        .catch(() => {
          handleOpenSnack(false, "Operation failed");
        })
        .finally(() => {
          setEditFormLoading(false);
          setSubmitting(false);
          handleCloseEditForm();
          handleClose();
        });
    },
  });

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOpenEditForm = () => setOpenEditForm(true);
  const handleCloseEditForm = () => setOpenEditForm(false);

  const handleOpenDialog1 = () => {
    setOpenDialog1(true);
  };
  const handleCloseDialog1 = () => {
    setOpenDialog1(false);
  };

  const handleOpenDialog2 = () => {
    setOpenDialog2(true);
  };
  const handleCloseDialog2 = () => {
    setOpenDialog2(false);
  };

  const handleDeleteUser = async () => {
    dispatch(deleteUser(data.id));
    try {
      const response = await dispatch(deleteUser(data.id));
      if (response) {
        handleOpenSnack(response.payload.success, response.payload.message);
      }
    } catch (error) {
      handleOpenSnack(false, "Failed operation");
    }
    setAnchorEl(null);
  };

  const handleInviteUser = async () => {
    try {
      const response = await dispatch(editUser({ id: data.id, checked: true }));
      if (response) {
        handleOpenSnack(response.payload.success, response.payload.message);
      }
    } catch (error) {
      handleOpenSnack(false, "Failed operation");
    }
    setAnchorEl(null);
    handleCloseDialog2();
  };

  return (
    <>
      <CustomModal
        open={openEditForm}
        onClose={handleCloseEditForm}
        title={`edit information`}
      >
        <EditForm
          employeeId={data?.id}
          formik={formik}
          loading={editFormLoading}
          closeModal={handleCloseEditForm}
        />
      </CustomModal>

      <Grid
        container
        sx={{
          alignItems: "center",
          borderBottom: isLast ? "none" : "2px solid #EEE",
          p: 2,
        }}
      >
        <Grid item xs={0.5}>
          <Checkbox
            checked={selectedEmployees.includes(data.id)}
            onChange={() => onSelectEmployee(data.id)}
            icon={
              <Box
                sx={{ width: "20px", height: "20px" }}
                component={"img"}
                src={checkboxInactiveIcon}
              />
            }
            checkedIcon={
              <Box
                sx={{ width: "20px", height: "20px" }}
                component={"img"}
                src={checkboxIcon}
              />
            }
            sx={{ width: "20px", height: "20px", p: 0 }}
          />
        </Grid>

        <Grid item xs={4}>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <Avatar
                src={data?.profile_picture?.url}
                alt={data?.profile_picture?.name}
                sx={{ width: "30px", height: "30px" }}
              />

              <Typography
                variant="body1"
                sx={{
                  textTransform: "capitalize",
                  color: "inactive.main",
                }}
              >
                {data.first_name + " " + data.last_name}
              </Typography>
            </Box>
          </Box>
        </Grid>

        <Grid item xs={1}>
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              backgroundColor:
                data.status === "active"
                  ? "#DBF0DE"
                  : data.status === "inactive"
                  ? "#EEE"
                  : "#E5F3FC",
              borderRadius: "16px",
              p: "4px 8px",
              maxWidth: "fit-content",
            }}
          >
            <Typography variant="body2" textTransform="capitalize">
              {data.status}
            </Typography>
          </Box>
        </Grid>

        <Grid item xs={2}>
          <Typography
            variant="body1"
            sx={{
              textTransform: "capitalize",
              color: "inactive.main",
            }}
          >
            {data.role?.department}
          </Typography>
        </Grid>

        <Grid item xs={2}>
          <Typography
            variant="body1"
            sx={{
              textTransform: "capitalize",
              color: "inactive.main",
            }}
          >
            {data.role?.team}
          </Typography>
        </Grid>

        <Grid item xs={2}>
          <Typography
            variant="body1"
            sx={{
              textTransform: "capitalize",
              color: "inactive.main",
            }}
          >
            {data.role?.title}
          </Typography>
        </Grid>

        <Grid item xs={0.5} sx={{ textAlign: "right" }}>
          <IconButton onClick={handleClick} sx={{ p: 0 }}>
            <img src={moreHoriz__icon} alt="icon" />
          </IconButton>

          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "right",
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "right",
            }}
          >
            <MenuItem
              onClick={handleOpenEditForm}
              sx={{
                textAlign: "center",
                color: "inactive.main",
              }}
            >
              <ListItemText>Edit</ListItemText>
            </MenuItem>

            <MenuItem
              onClick={handleOpenDialog1}
              sx={{
                textAlign: "center",
                color: "inactive.main",
              }}
            >
              <ListItemText>Delete</ListItemText>
            </MenuItem>

            <MenuItem
              onClick={handleOpenDialog2}
              sx={{
                textAlign: "center",
                color: "inactive.main",
              }}
            >
              <ListItemText>Invite</ListItemText>
            </MenuItem>
          </Menu>

          <Dialog
            open={openDialog1}
            onClose={handleCloseDialog1}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <Stack
              sx={{
                justifyContent: "center",
                alignItems: "center",
                textAlign: "center",
                gap: { xs: 3, lg: 5 },
                p: { xs: 2, lg: 5 },
                position: "relative",
                maxWidth: "420px",
              }}
            >
              <IconButton
                onClick={handleCloseDialog1}
                sx={{
                  position: "absolute",
                  top: 1,
                  right: 1,
                  p: 0,
                  width: "32px",
                  height: "32px",
                }}
              >
                <Close />
              </IconButton>
              <Box component="img" src={cautionIcon} />
              <Typography variant="h2" color="secondary.main">
                Delete Employee
              </Typography>
              <Typography variant="body1" color="inactive.main">
                Are you sure you want to delete{" "}
                <span
                  style={{ fontWeight: 600, color: "#0C1716" }}
                >{`${data.first_name} ${data.last_name}`}</span>
              </Typography>
              <Stack
                sx={{
                  flexDirection: { lg: "row" },
                  justifyContent: "space-between",
                  alignItems: "center",
                  gap: "16px",
                  width: "100%",
                }}
              >
                <StyledDarkBtn
                  onClick={handleDeleteUser}
                  sx={{ width: { xs: "100%", lg: "initial" } }}
                >
                  delete
                </StyledDarkBtn>

                <StyledOutlinedBtn
                  onClick={handleCloseDialog1}
                  sx={{
                    width: { xs: "100%", lg: "initial" },
                    backgroundColor: "softAccent",
                    borderColor: "skillGreen",
                    color: "skillGreen",
                  }}
                >
                  cancel
                </StyledOutlinedBtn>
              </Stack>
            </Stack>
          </Dialog>

          <Dialog
            open={openDialog2}
            onClose={handleCloseDialog2}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <Stack
              sx={{
                justifyContent: "center",
                alignItems: "center",
                textAlign: "center",
                gap: { xs: 3, lg: 5 },
                p: { xs: 2, lg: 5 },
                position: "relative",
                maxWidth: "420px",
              }}
            >
              <IconButton
                onClick={handleCloseDialog2}
                sx={{
                  position: "absolute",
                  top: 1,
                  right: 1,
                  p: 0,
                  width: "32px",
                  height: "32px",
                }}
              >
                <Close />
              </IconButton>
              <Box component="img" src={invitationIcon} />
              <Typography variant="h2" color="secondary.main">
                Invite Employee
              </Typography>
              <Typography variant="body1" color="inactive.main">
                Are you sure you want to send an{" "}
                <span style={{ fontWeight: 600, color: "#0C1716" }}>
                  Invitation
                </span>{" "}
                to{" "}
                <span
                  style={{ fontWeight: 600, color: "#0C1716" }}
                >{`${data.first_name} ${data.last_name}`}</span>
              </Typography>
              <Stack
                sx={{
                  flexDirection: { lg: "row" },
                  justifyContent: "space-between",
                  alignItems: "center",
                  gap: "16px",
                  width: "100%",
                }}
              >
                <StyledDarkBtn
                  onClick={handleInviteUser}
                  sx={{ width: { xs: "100%", lg: "initial" } }}
                >
                  invite
                </StyledDarkBtn>

                <StyledOutlinedBtn
                  onClick={handleCloseDialog2}
                  sx={{
                    width: { xs: "100%", lg: "initial" },
                    backgroundColor: "softAccent",
                    borderColor: "skillGreen",
                    color: "skillGreen",
                  }}
                >
                  cancel
                </StyledOutlinedBtn>
              </Stack>
            </Stack>
          </Dialog>
        </Grid>
      </Grid>
    </>
  );
};

export default EmployeeRow;
