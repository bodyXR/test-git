import { Box, Checkbox, Grid, Typography } from "@mui/material";
import checkboxInactiveIcon from "../../../assets/checkbox_inactive.svg";
import checkboxIcon from "../../../assets/checkbox_icon.svg";

const headerKeys = ["Employee", "Status", "Department", "Team", "Role"];

const xsSpacingMap = [4, 1, 2, 2, 2, 0.5];

const EmployeeTableHeaders = ({
  data,
  selectedEmployees,
  onSelectAllEmployees,
}) => {
  return (
    <Grid container sx={{ alignItems: "center", px: 2, py: 1 }}>
      <Grid item xs={0.5}>
        <Checkbox
          checked={selectedEmployees.length === data.length}
          onChange={onSelectAllEmployees}
          icon={
            <Box
              sx={{ width: "20px", height: "20px" }}
              component={"img"}
              src={checkboxInactiveIcon}
            />
          }
          checkedIcon={
            <Box
              sx={{ width: "20px", height: "20px" }}
              component={"img"}
              src={checkboxIcon}
            />
          }
          sx={{ width: "20px", height: "20px", p: 0 }}
        />
      </Grid>

      {headerKeys.map((header, index) => (
        <Grid item xs={xsSpacingMap[index]} key={header}>
          <Typography
            variant="h5"
            sx={{
              color: "darkGreen",
              fontWeight: "500",
            }}
          >
            {header}
          </Typography>
        </Grid>
      ))}
    </Grid>
  );
};

export default EmployeeTableHeaders;
