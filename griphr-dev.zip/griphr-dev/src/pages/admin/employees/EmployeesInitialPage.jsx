import React, { useState } from "react";
import { Box, Stack, Typography } from "@mui/material";
import fileIcon from "../../../assets/add_file_icon.svg";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import StyledDarkBtn from "../../../components/styled/StyledDarkBtn";
import CustomModal from "../../../ui/CustomModal";
import AssignRoleForm from "../organigram/AssignRoleForm";
import BulkUploadForm from "../organigram/BulkUploadForm";

const EmployeesInitialPage = () => {
  const [isAssignRoleOpen, setIsAssignRoleOpen] = useState(false);
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);

  const handleAssignRoleOpen = () => setIsAssignRoleOpen(true);
  const handleAssignRoleClose = () => setIsAssignRoleOpen(false);

  const handleBulkUploadOpen = () => setIsBulkUploadOpen(true);
  const handleBulkUploadClose = () => setIsBulkUploadOpen(false);

  return (
    <>
      <CustomModal
        open={isAssignRoleOpen}
        onClose={handleAssignRoleClose}
        title="Add Employee"
        height="95%"
      >
        <AssignRoleForm closeModal={handleAssignRoleClose} />
      </CustomModal>

      <CustomModal
        open={isBulkUploadOpen}
        onClose={handleBulkUploadClose}
        title="Bulk Upload"
      >
        <BulkUploadForm />
      </CustomModal>

      <StyledWrapper
        sx={{
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center",
          gap: "12px",
          height: { lg: "calc(100vh - 312px)" },
          py: { xs: 5, lg: "20px" },
        }}
      >
        <Box
          sx={{ width: "40px", height: "50px" }}
          component={"img"}
          src={fileIcon}
        />

        <Typography variant="h4" color="inactive.main">
          The organigram is empty, choose an option to start fill it
        </Typography>

        <Stack
          sx={{
            flexDirection: { lg: "row" },
            justifyContent: "center",
            alignItems: "center",
            gap: { xs: "12px", lg: 3 },
            width: "100%",
          }}
        >
          <StyledDarkBtn
            onClick={handleAssignRoleOpen}
            min_width="120px"
            sx={{ width: { xs: "100%", lg: "150px" } }}
          >
            Add Employee
          </StyledDarkBtn>

          <StyledDarkBtn
            onClick={handleBulkUploadOpen}
            min_width="120px"
            sx={{ width: { xs: "100%", lg: "150px" } }}
          >
            Bulk Upload
          </StyledDarkBtn>
        </Stack>
      </StyledWrapper>
    </>
  );
};

export default EmployeesInitialPage;
