import { Alert, Box, Snackbar, Typography } from "@mui/material";
import React, { useState } from "react";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import EmployeeTableHeaders from "./EmployeeTableHeaders";
import EmployeeRow from "./EmployeeRow";
import EmployeesInitialPage from "./EmployeesInitialPage";

const EmployeesTable = ({
  data,
  selectedEmployees,
  setSelectedEmployees,
  isFetchedUsersData,
}) => {
  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>
      <Box
        className="employees-table"
        sx={{
          overflowX: "auto",
          width: { xs: "95vw", md: "90vw", lg: "100%" },

          // "@media (min-width: 350px)": {
          //   width: "334px",
          // },
          // "@media (min-width: 400px)": {
          //   width: "384px",
          // },
          // "@media (min-width: 600px)": {
          //   width: "568px",
          // },
          // "@media (min-width: 900px)": {
          //   width: "836px",
          // },
          // "@media (min-width: 1200px)": {
          //   width: "initial",
          // },
        }}
      >
        {isFetchedUsersData ? (
          data?.length > 0 ? (
            <StyledWrapper sx={{ width: { xs: "1170px", lg: "initial" } }}>
              <EmployeeTableHeaders
                data={data}
                selectedEmployees={selectedEmployees}
                onSelectAllEmployees={() => {
                  const allEmployeeIds = data.map((employee) => employee.id);

                  // If all employees are already selected, clear the selection
                  if (selectedEmployees.length === allEmployeeIds.length) {
                    setSelectedEmployees([]);
                  } else {
                    setSelectedEmployees(allEmployeeIds);
                  }
                }}
              />
              {data.map((employee, index) => (
                <EmployeeRow
                  key={employee.id}
                  data={employee}
                  isLast={index === data.length - 1}
                  selectedEmployees={selectedEmployees}
                  onSelectEmployee={(employeeId) => {
                    if (selectedEmployees.includes(employeeId)) {
                      setSelectedEmployees(
                        selectedEmployees.filter((id) => id !== employeeId)
                      );
                    } else {
                      setSelectedEmployees([...selectedEmployees, employeeId]);
                    }
                  }}
                  handleOpenSnack={handleOpenSnack}
                />
              ))}
            </StyledWrapper>
          ) : (
            <Box sx={{ textAlign: "center", pt: 3 }}>
              <Typography variant="h3">No Employee Found!</Typography>
            </Box>
          )
        ) : (
          <EmployeesInitialPage />
        )}
      </Box>
    </>
  );
};

export default EmployeesTable;
