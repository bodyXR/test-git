import React from "react";
import { useNavigate } from "react-router-dom";
import { Box } from "@mui/material";
import departmentsInactiveIcon from "../../../assets/menu_icon.svg";
import departmentsIcon from "../../../assets/menu_active.svg";
import employeeListInactiveIcon from "../../../assets/fourSquare_inactive.svg";
import employeeListIcon from "../../../assets/fourSquare_icon.svg";
import organigramInactiveIcon from "../../../assets/organigram_inactive.svg";
import organigramIcon from "../../../assets/organigram_icon.svg";
import {
  ADMIN_EMPLOYEE_LIST_ROUTE,
  ADMIN_ORGANIGRAM_ROUTE,
} from "../../../routes/paths";
import { useDispatch, useSelector } from "react-redux";
import { setOpenSub } from "../../../redux/slices/sideBarSlice";
import { setEmployeesStyle } from "../../../redux/slices/admin/users/usersSlice";

const NavigationIcons = () => {
  const { openSub } = useSelector((state) => state.sideBar);
  const { employeesStyle } = useSelector((state) => state.users);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleNavigation = (page) => {
    if (page === "table") {
      navigate(ADMIN_EMPLOYEE_LIST_ROUTE);
      dispatch(setOpenSub("sub__1"));
      dispatch(setEmployeesStyle("table"));
    } else if (page === "cards") {
      navigate(ADMIN_EMPLOYEE_LIST_ROUTE);
      dispatch(setOpenSub("sub__1"));
      dispatch(setEmployeesStyle("cards"));
    } else {
      navigate(ADMIN_ORGANIGRAM_ROUTE);
      dispatch(setOpenSub("sub__2"));
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "flex-end",
        alignItems: "center",
        gap: 2,
      }}
    >
      <Box
        onClick={() => handleNavigation("table")}
        component={"img"}
        src={
          openSub === "sub__1" && employeesStyle === "table"
            ? departmentsIcon
            : departmentsInactiveIcon
        }
        sx={{ width: "24px", height: "24px", cursor: "pointer" }}
      />

      <Box
        onClick={() => handleNavigation("cards")}
        component={"img"}
        src={
          openSub === "sub__1" && employeesStyle === "cards"
            ? employeeListIcon
            : employeeListInactiveIcon
        }
        sx={{ width: "24px", height: "24px", cursor: "pointer" }}
      />

      <Box
        onClick={() => handleNavigation("organigram")}
        component={"img"}
        src={openSub === "sub__2" ? organigramIcon : organigramInactiveIcon}
        sx={{ width: "24px", height: "24px", cursor: "pointer" }}
      />
    </Box>
  );
};

export default NavigationIcons;
