import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  Snackbar,
  Typography,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import React, { useCallback, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchJobProfiles } from "../../../redux/slices/admin/jobProfile/jobProfileSlice";
import axiosInstance from "../../../helper/axiosInstance";

const Role = ({ data }) => {
  const [openDialog, setOpenDialog] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };
  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const removeRole = useCallback(async () => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        id: data.id,
      },
    };

    try {
      const response = await axiosInstance.delete("job_profile", config);
      console.log(response.data.payload);
      handleOpenSnack(true, response.data.message);
      dispatch(fetchJobProfiles(token));
    } catch (error) {
      console.log(error?.response.data);
      handleOpenSnack(false, error?.response.data.message);
    }
  }, []);

  const handleRemoveRole = () => {
    removeRole();
  };

  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>

      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: "12px",
          backgroundColor: "darkGreenAccent",
          borderRadius: "100px",
          p: "4px 12px",
        }}
      >
        <Typography variant="h6" sx={{ fontWeight: 500, color: "white" }}>
          {data.title}
        </Typography>

        <IconButton onClick={handleOpenDialog} sx={{ p: 0 }}>
          <CloseIcon sx={{ width: "16px", height: "16px", color: "white" }} />
        </IconButton>
      </Box>

      <Dialog
        open={openDialog}
        onClose={handleCloseDialog}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          {`Confirm Role Remove`}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {`Are you sure you want to remove this Role?`}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} autoFocus>
            cancel
          </Button>
          <Button onClick={handleRemoveRole} color="error">
            Remove
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default Role;
