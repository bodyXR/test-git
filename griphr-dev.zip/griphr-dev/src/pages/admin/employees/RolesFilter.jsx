import {
  Box,
  Checkbox,
  InputAdornment,
  MenuItem,
  Popover,
  TextField,
  Typography,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import checkboxIcon from "../../../assets/checkbox_icon.svg";
import search from "../../../assets/search.svg";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchJobProfiles } from "../../../redux/slices/admin/jobProfile/jobProfileSlice";
import { fetchUsers } from "../../../redux/slices/admin/users/usersActions";

const RolesFilter = ({ open, onClose, setSelectedEmployees }) => {
  const [searchfield, setSearchfield] = useState("");
  const [selectedRoles, setSelectedRoles] = useState([]);
  const { jobProfile } = useSelector((state) => state.jobProfile);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchJobProfiles(token));
  }, []);

  const onSearchChange = (event) => {
    setSearchfield(event.target.value);
  };

  const handleCheckboxChange = (role) => {
    const updatedRoles = [...selectedRoles];

    if (updatedRoles.includes(role)) {
      // If role is already selected, remove it
      const index = updatedRoles.indexOf(role);
      updatedRoles.splice(index, 1);
    } else {
      // If role is not selected, add it
      updatedRoles.push(role);
    }

    setSelectedRoles(updatedRoles);
    setSelectedEmployees([]);

    // Now you can send the request to fetch users based on the selected roles
    dispatch(fetchUsers({ role_ids: updatedRoles }));
  };

  const filteredRoles = jobProfile
    ?.slice()
    ?.sort((a, b) => {
      return a?.title?.localeCompare(b?.title);
    })
    .filter((role) =>
      role?.title?.toLowerCase()?.includes(searchfield?.toLowerCase())
    );

  return (
    <Popover
      anchorEl={open}
      open={Boolean(open)}
      onClose={onClose}
      anchorOrigin={{
        vertical: "bottom", // Adjust the vertical position
        horizontal: "left", // Adjust the horizontal position
      }}
      PaperProps={{
        style: {
          width: "min-content",
          maxHeight: filteredRoles?.length > 5 ? "250px" : "auto", // set a max height for the menu if there are more than five jobs
          overflow: "auto", // make the menu scrollable
        },
      }}
    >
      <MenuItem
        sx={{
          "&:hover": {
            background: "transparent",
          },
        }}
        disableTouchRipple
      >
        <TextField
          name="search_role"
          fullWidth
          size="small"
          type="search"
          variant="outlined"
          value={searchfield}
          onChange={onSearchChange}
          sx={{
            background: "white",
            "& .MuiInputBase-input": {
              py: "9.45px",
            },
          }}
          placeholder="Search Role"
          InputProps={{
            endAdornment: (
              <InputAdornment position="start">
                <img src={search} alt="search icon" />
              </InputAdornment>
            ),
          }}
        />
      </MenuItem>
      {filteredRoles?.length > 0 ? (
        filteredRoles?.map((role) => (
          <MenuItem key={role.id}>
            <Checkbox
              sx={{ width: "32px", height: "32px", mr: 2 }}
              id={`${role.id}`}
              checked={selectedRoles.includes(role.id)}
              onChange={() => handleCheckboxChange(role.id)}
              color="primary"
              icon={<CheckBoxOutlineBlankIcon sx={{ color: "primary.main" }} />}
              checkedIcon={
                <Box
                  sx={{ width: "24px", height: "24px" }}
                  component={"img"}
                  src={checkboxIcon}
                />
              }
            />
            <Typography variant="h5" color="inactive.main">
              {role.title}
            </Typography>
          </MenuItem>
        ))
      ) : (
        <MenuItem disabled>No roles found</MenuItem>
      )}
    </Popover>
  );
};

export default RolesFilter;
