import {
  Box,
  Checkbox,
  InputAdornment,
  MenuItem,
  Popover,
  TextField,
  Typography,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import checkboxIcon from "../../../assets/checkbox_icon.svg";
import search from "../../../assets/search.svg";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchTeams } from "../../../redux/slices/admin/companyProfile/configSlice";
import { fetchUsers } from "../../../redux/slices/admin/users/usersActions";

const TeamsFilter = ({ open, onClose, setSelectedEmployees }) => {
  const [searchfield, setSearchfield] = useState("");
  const [selectedTeams, setSelectedTeams] = useState([]);
  const { teams } = useSelector((state) => state.config);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchTeams());
  }, []);

  const onSearchChange = (event) => {
    setSearchfield(event.target.value);
  };

  const handleCheckboxChange = (team) => {
    const updatedTeams = [...selectedTeams];

    if (updatedTeams.includes(team)) {
      // If team is already selected, remove it
      const index = updatedTeams.indexOf(team);
      updatedTeams.splice(index, 1);
    } else {
      // If team is not selected, add it
      updatedTeams.push(team);
    }

    setSelectedTeams(updatedTeams);
    setSelectedEmployees([]);

    // Now you can send the request to fetch users based on the selected teams
    dispatch(fetchUsers({ teams: updatedTeams }));
  };

  const filteredTeams = teams
    ?.slice()
    ?.sort((a, b) => {
      return a?.localeCompare(b);
    })
    .filter((team) => team.toLowerCase().includes(searchfield.toLowerCase()));

  return (
    <Popover
      anchorEl={open}
      open={Boolean(open)}
      onClose={onClose}
      anchorOrigin={{
        vertical: "bottom", // Adjust the vertical position
        horizontal: "left", // Adjust the horizontal position
      }}
      PaperProps={{
        style: {
          width: "min-content",
          maxHeight: filteredTeams?.length > 5 ? "250px" : "auto", // set a max height for the menu if there are more than five jobs
          overflow: "auto", // make the menu scrollable
        },
      }}
    >
      <MenuItem
        sx={{
          "&:hover": {
            background: "transparent",
          },
        }}
        disableTouchRipple
      >
        <TextField
          name="search_team"
          fullWidth
          size="small"
          type="search"
          variant="outlined"
          value={searchfield}
          onChange={onSearchChange}
          sx={{
            background: "white",
            "& .MuiInputBase-input": {
              py: "9.45px",
            },
          }}
          placeholder="Search Team"
          InputProps={{
            endAdornment: (
              <InputAdornment position="start">
                <img src={search} alt="search icon" />
              </InputAdornment>
            ),
          }}
        />
      </MenuItem>
      {filteredTeams?.length > 0 ? (
        filteredTeams?.map((team) => (
          <MenuItem key={team}>
            <Checkbox
              sx={{ width: "32px", height: "32px", mr: 2 }}
              id={team}
              checked={selectedTeams.includes(team)}
              onChange={() => handleCheckboxChange(team)}
              color="primary"
              icon={<CheckBoxOutlineBlankIcon sx={{ color: "primary.main" }} />}
              checkedIcon={
                <Box
                  sx={{ width: "24px", height: "24px" }}
                  component={"img"}
                  src={checkboxIcon}
                />
              }
            />
            <Typography variant="h5" color="inactive.main">
              {team}
            </Typography>
          </MenuItem>
        ))
      ) : (
        <MenuItem disabled>No teams found</MenuItem>
      )}
    </Popover>
  );
};

export default TeamsFilter;
