import {
  Autocomplete,
  Box,
  Button,
  CircularProgress,
  IconButton,
  InputAdornment,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import { useFormik } from "formik";
import { useCallback, useEffect, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import { creatingNewEmployeeFormValidationSchema } from "./validations/validationSchema";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../helper/axiosInstance";
import { fetchData } from "../../../redux/slices/admin/organigram/organigramActions";
import { fetchUsers } from "../../../redux/slices/admin/users/usersActions";
import StyledDarkBtn from "../../../components/styled/StyledDarkBtn";
import StyledOutlinedBtn from "../../../components/styled/StyledOutlinedBtn";
import PersonalInformation from "./PersonalInformation";
import RoleDetails from "./RoleDetails";

const initialValues = {
  firstName: "",
  lastName: "",
  joinDate: null,
  email: "",
  phone: "",
  location: "",
  gender: "",
  systemRole: "",
  manager: "",
  department: "",
  team: "",
  role: "",
  fullRoleObj: null,
  checked: false,
};

const AssignRoleForm = ({ data, handleOpenSnack, closeModal }) => {
  const [value, setValue] = useState("");
  const [currentTab, setCurrentTab] = useState("exist_employee");
  const [existingEmployees, setExistingEmployees] = useState([]);
  const [loading, setLoading] = useState(false);
  const { token, userInfo } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  const toggleTab = (value) => {
    setCurrentTab(value);
  };

  const existingEmployeeForm = useFormik({
    initialValues: {
      employee: "",
    },
    // validationSchema: existingEmployeeFormValidationSchema,
    onSubmit: (values, { setSubmitting }) => {
      setTimeout(() => {
        // submit to the server
        editData(token, values.employee.id);
        setSubmitting(false);
      }, 1000);
    },
  });

  const creatingNewEmployeeForm = useFormik({
    initialValues: initialValues,
    validationSchema: creatingNewEmployeeFormValidationSchema,
    onSubmit: async (values, { setSubmitting, resetForm }) => {
      try {
        // submit to the server
        const userId = await sendUserData(token, values);
        if (!data && userId) {
          await sendRoleData(token, values, userId);
          setSubmitting(false);
          resetForm(); // Reset the form values after successful submission
        }
      } catch (error) {
        console.log(error?.response.data);
        setSubmitting(false);
      }
    },
    enableReinitialize: true,
  });

  const selectValue = (e, value) => {
    existingEmployeeForm.setFieldValue(
      "employee",
      value !== null ? value : null
    );
  };

  const fetchUsersData = useCallback(async (token) => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
    };

    try {
      const response = await axiosInstance.get("user", config);
      setExistingEmployees(response.data.payload.data);
      console.log(response.data.payload.data);
    } catch (error) {
      console.log(error);
    }
  }, []);

  const sendUserData = useCallback(
    async (token, values) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      // Create a function to filter out keys with empty string or null values
      const removeEmptyKeys = (obj) =>
        Object.fromEntries(
          Object.entries(obj).filter(([_, v]) => v !== "" && v !== null)
        );

      const requestBody = removeEmptyKeys({
        first_name: values.firstName,
        last_name: values.lastName,
        email: values.email,
        phone: values.phone,
        // joinDate: values.joinDate,
        location: values.location,
        gender: values.gender,
        system_role: values.systemRole,
        checked: values.checked,
        company_id: userInfo.company_id,
      });

      try {
        setLoading(true);
        const response = await axiosInstance.post(`user`, requestBody, config);
        console.log(response.data);
        if (data) {
          editData(token, response.data.payload.id);
        }
        handleOpenSnack(true, response.data.message);
        // Check if the API call was successful and return the userId
        if (
          response.data &&
          response.data.payload &&
          response.data.payload.id
        ) {
          return response.data.payload.id;
        }
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
        console.log(error?.response.data);
      } finally {
        setLoading(false);
        if (data) {
          dispatch(fetchData(token));
        } else {
          dispatch(fetchUsers({}));
        }
        closeModal();
      }
    },
    [token]
  );

  const sendRoleData = useCallback(
    async (token, values, userId) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      // Create a function to filter out keys with empty string or null values
      const removeEmptyKeys = (obj) =>
        Object.fromEntries(
          Object.entries(obj).filter(([_, v]) => v !== "" && v !== null)
        );

      const requestBody = removeEmptyKeys({
        user_id: userId,
        manager_id: values.manager,
        department: values.department,
        team: values.team,
        job_profile_id: values.role,
      });

      try {
        setLoading(true);
        const response = await axiosInstance.post(`role`, requestBody, config);
        console.log(response.data);
        handleOpenSnack(true, response.data.message);
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
        console.log(error?.response.data);
      } finally {
        setLoading(false);
        if (data) {
          dispatch(fetchData(token));
        } else {
          dispatch(fetchUsers({}));
        }
        closeModal();
      }
    },
    [token]
  );

  const editData = useCallback(async (token, userId) => {
    console.log(userId);
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        id: data.id,
      },
    };
    try {
      const response = await axiosInstance.put(
        "role",
        {
          user_id: userId,
        },
        config
      );
      console.log(response.data.payload);
    } catch (error) {
      console.log(error.response.data);
    } finally {
      dispatch(fetchData(token));
      closeModal();
    }
  }, []);

  useEffect(() => {
    fetchUsersData(token);
  }, [token, fetchUsersData]);

  return (
    <Box sx={{ px: { xs: 2.5, lg: 0 } }}>
      {data && (
        <Stack
          sx={{
            flexDirection: "row",
            justifyContent: { xs: "space-between", md: "initial" },
            gap: { md: 25.25 },
            mb: { xs: 3 },
          }}
        >
          <Button
            onClick={() => toggleTab("exist_employee")}
            mb={2.5}
            sx={{ borderRadius: 1 }}
          >
            <Typography
              variant="h3"
              sx={{
                textTransform: "capitalize",
                fontSize: { xs: "14px", md: "16px" },
                fontWeight: 600,
                color:
                  currentTab === "exist_employee"
                    ? "#1E394C"
                    : "rgba(30, 57, 76, 0.5)",
                borderBottom:
                  currentTab === "exist_employee" && "2px solid #1E394C",
              }}
            >
              existing employee
            </Typography>
          </Button>

          <Button
            onClick={() => toggleTab("new_employee")}
            mb={2.5}
            sx={{ borderRadius: 1 }}
          >
            <Typography
              variant="h3"
              sx={{
                textTransform: "capitalize",
                fontSize: { xs: "14px", md: "16px" },
                fontWeight: 600,
                color:
                  currentTab === "new_employee"
                    ? "#1E394C"
                    : "rgba(30, 57, 76, 0.5)",
                borderBottom:
                  currentTab === "new_employee" && "2px solid #1E394C",
              }}
            >
              create new employee
            </Typography>
          </Button>
        </Stack>
      )}

      {currentTab === "exist_employee" && data ? (
        <form onSubmit={existingEmployeeForm.handleSubmit}>
          <Box>
            <Typography
              variant="h3"
              component="label"
              htmlFor="employee"
              sx={{
                textTransform: "capitalize",
                fontWeight: 400,
                color: "secondary.main",
              }}
            >
              existing employee
            </Typography>
            <Autocomplete
              freeSolo
              // disableClearable --> to disable close icon (second icon)
              disableClearable
              id="employee"
              name="employee"
              value={value}
              getOptionLabel={(option) =>
                option
                  ? option.first_name + " " + option.last_name
                  : data.user
                  ? `${data.user.first_name} ${data.user.last_name}`
                  : ""
              }
              renderOption={(props, option, index) => {
                const key = `listItem-${index}-${option.id}`;
                const displayName = option.first_name + " " + option.last_name;
                return (
                  <li {...props} key={key}>
                    {displayName}
                  </li>
                );
              }}
              options={existingEmployees}
              onBlur={existingEmployeeForm.handleBlur}
              onChange={selectValue}
              label="Search input"
              sx={{ mt: "16px" }}
              renderInput={(params) => (
                <TextField
                  error={
                    existingEmployeeForm.touched.employee &&
                    Boolean(existingEmployeeForm.errors.employee)
                  }
                  helperText={
                    existingEmployeeForm.touched.employee
                      ? existingEmployeeForm.errors.employee
                      : ""
                  }
                  name="employee"
                  placeholder="Search Employee"
                  sx={{ minHeight: "82px" }}
                  {...params}
                  type="search"
                  value={existingEmployeeForm.values.employee}
                  InputProps={{
                    ...params.InputProps,
                    startAdornment: (
                      <InputAdornment position="start">
                        <IconButton>
                          <SearchIcon />
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              )}
            />

            <Stack
              sx={{
                flexDirection: "row",
                alignItems: "center",
                gap: "16px",
              }}
            >
              <Button
                type="submit"
                disabled={existingEmployeeForm.isSubmitting}
                variant="contained"
                color="secondary"
                sx={{
                  width: { xs: "100%", sm: "220px" },
                  background: (theme) => theme.palette.accent,
                  color: "darkGreen",
                  textTransform: "capitalize",
                  "&:hover": {
                    background: "#6AE6A480",
                  },
                }}
              >
                <Typography variant="h6">finish</Typography>
              </Button>
              {existingEmployeeForm.isSubmitting && <CircularProgress />}
            </Stack>
          </Box>
        </form>
      ) : (
        <form onSubmit={creatingNewEmployeeForm.handleSubmit}>
          <Stack gap={3}>
            <PersonalInformation formik={creatingNewEmployeeForm} />
            {!data && <RoleDetails formik={creatingNewEmployeeForm} />}

            <Stack
              sx={{
                flexDirection: { lg: "row" },
                alignItems: "center",
                gap: "16px",
              }}
            >
              <StyledDarkBtn
                type="submit"
                sx={{ width: { xs: "100%", lg: "initial" } }}
              >
                save
              </StyledDarkBtn>

              <StyledOutlinedBtn
                onClick={closeModal}
                sx={{
                  width: { xs: "100%", lg: "initial" },
                  backgroundColor: "softAccent",
                  borderColor: "skillGreen",
                  color: "skillGreen",
                }}
              >
                cancel
              </StyledOutlinedBtn>

              {loading && <CircularProgress size={20} />}
            </Stack>
          </Stack>
        </form>
      )}
    </Box>
  );
};

export default AssignRoleForm;
