import {
  Box,
  Button,
  CircularProgress,
  Stack,
  Typography,
} from "@mui/material";
import { useFormik } from "formik";
import downloadIcon from "../../../assets/Group 19.svg";
import uploadIcon from "../../../assets/updoad_icon.svg";
import DropContainer from "../../../components/DropContainer";
import { bulkUploadValidationSchema } from "./validations/validationSchema";
import { Link } from "react-router-dom";
import { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../helper/axiosInstance";
import { fetchUsers } from "../../../redux/slices/admin/users/usersActions";

const BulkUploadForm = ({ handleOpenSnack, closeModal }) => {
  const [loading, setLoading] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  const formik = useFormik({
    initialValues: {
      files: null,
      users: [],
    },
    validationSchema: bulkUploadValidationSchema,
    onSubmit: (values, { setSubmitting }) => {
      console.log("values", values);
      setTimeout(() => {
        // submit to the server
        sendData(token, values);
        setSubmitting(false);
      }, 1000);
    },
  });

  useEffect(() => {
    console.log("formik values", formik.values);
  }, [formik.values]);

  const sendData = useCallback(
    async (token, values) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `bulk-actions`,
          {
            action: "bulk_users",
            users: values.users,
          },
          config
        );
        console.log(response.data);
        handleOpenSnack(true, response.data.message);
        dispatch(fetchUsers({}));
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
        console.log(error?.response.data);
      } finally {
        setLoading(false);
        closeModal();
      }
    },
    [token]
  );

  const acceptTypes = {
    "text/csv": [".csv"],
  };

  return (
    <form onSubmit={formik.handleSubmit}>
      <Stack sx={{ gap: { xs: 3, lg: 5 }, px: { xs: 2.5, lg: 0 } }}>
        <a
          href="/adepti_template.csv"
          download="adepti_template.csv"
          style={{ alignSelf: "flex-end" }}
        >
          <Button
            variant="contained"
            color="secondary"
            sx={{
              textTransform: "capitalize",
              p: "10px",
            }}
            endIcon={
              <img
                src={downloadIcon}
                alt="download adepti template"
                style={{ width: "24px", height: "24px" }}
              />
            }
          >
            <Typography variant="h6">download adepti template</Typography>
          </Button>
        </a>

        <DropContainer
          title={"Drag CSV Here"}
          fileTypes={acceptTypes}
          formik={formik}
          name="files"
        />
        {console.log("error", formik?.errors?.users)}
        {formik.errors.users && formik.errors.users.length > 0 ? (
          <div>
            {Object.values(formik.errors.users[0]).map((error, index) => (
              <Typography variant="body2" color="red" key={index}>
                {error}
              </Typography>
            ))}
          </div>
        ) : null}

        <Typography
          variant="h5"
          sx={{
            textTransform: "capitalize",
            width: { sm: "544px" },
            color: "secondary.main",
          }}
        >
          Upload your filled out organigram template to automatically set your
          company’s workforce in their respective departments, levels, and
          positions
        </Typography>

        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Button
            type="submit"
            disabled={formik.isSubmitting}
            variant="contained"
            color="secondary"
            sx={{
              alignSelf: "flex-start",
              textTransform: "capitalize",
              p: "10px",
            }}
            endIcon={
              <img
                src={uploadIcon}
                alt="upload adepti template"
                style={{ width: "24px", height: "24px" }}
              />
            }
          >
            <Typography variant="h6">upload adepti template</Typography>
          </Button>

          {loading && <CircularProgress size={20} />}
        </Box>
      </Stack>
    </form>
  );
};

export default BulkUploadForm;
