import React, { useEffect } from "react";
import ChartTreeFlow from "./ChartTreeFlow";
import { useLocation, useOutletContext } from "react-router-dom";
import NavigationIcons from "../employees/NavigationIcons";
import { Stack } from "@mui/material";

const ChartTree = () => {
  const location = useLocation();
  const [title, setTitle] = useOutletContext();

  useEffect(() => {
    setTitle(location.pathname.split("/").at(-1));
  }, [setTitle, location]);

  return (
    <Stack gap={3} height="100%">
      <NavigationIcons />
      <ChartTreeFlow />
    </Stack>
  );
};

export default ChartTree;
