import { Grid, MenuItem, Stack, TextField, Typography } from "@mui/material";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import StyledCustomTextField from "../../../components/styled/StyledCustomTextField";
import StyledDatePicker from "../../../components/styled/StyledDatePicker";

const PersonalInformation = ({ formik, onEdit = false }) => {
  return (
    <StyledWrapper sx={{ gap: "20px", p: { xs: "12px", lg: "20px" } }}>
      <Typography variant="h3" color="darkGreenAccent">
        Personal Information
      </Typography>

      <Grid container spacing="20px">
        <Grid item xs={12} lg={6}>
          <Stack>
            <StyledCustomTextField
              id="firstName"
              name="firstName"
              label="First Name"
              size="medium"
              type="text"
              value={formik.values.firstName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.firstName ? formik.errors.firstName : ""
              }
              error={
                formik.touched.firstName && Boolean(formik.errors.firstName)
              }
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.firstName ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
            />
          </Stack>
        </Grid>

        <Grid item xs={12} lg={6}>
          <Stack>
            <StyledCustomTextField
              id="lastName"
              name="lastName"
              label="Last Name"
              size="medium"
              type="text"
              value={formik.values.lastName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.lastName ? formik.errors.lastName : ""}
              error={formik.touched.lastName && Boolean(formik.errors.lastName)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.lastName ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
            />
          </Stack>
        </Grid>

        {!onEdit && (
          <Grid item xs={12} lg={6}>
            <Stack>
              <StyledDatePicker
                label="Join Date"
                value={formik.values.joinDate}
                onChange={(value) => {
                  formik.setFieldValue("joinDate", value);
                }}
                slot={(params) => (
                  <TextField
                    {...params}
                    error={Boolean(
                      formik.touched.joinDate && formik.errors.joinDate
                    )}
                    helperText={
                      formik.touched.joinDate && formik.errors.joinDate
                    }
                    id="joinDate"
                    name="joinDate"
                  />
                )}
                sx={{
                  flex: 1,
                  "& .MuiInputBase-input": { pt: "13.9px", pb: "14px" },
                }}
              />
            </Stack>
          </Grid>
        )}

        {!onEdit && (
          <Grid item xs={12} lg={6}>
            <Stack>
              <StyledCustomTextField
                id="email"
                name="email"
                label="Email"
                size="medium"
                type="email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                helperText={formik.touched.email ? formik.errors.email : ""}
                error={formik.touched.email && Boolean(formik.errors.email)}
                variant="outlined"
                InputLabelProps={{
                  style: {
                    top: formik.values.email ? "0px" : "-2.5px", // Adjust based on content
                  },
                }}
                sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
              />
            </Stack>
          </Grid>
        )}

        <Grid item xs={12} lg={6}>
          <Stack>
            <StyledCustomTextField
              id="phone"
              name="phone"
              label="Phone"
              size="medium"
              type="text"
              value={formik.values.phone}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.phone ? formik.errors.phone : ""}
              error={formik.touched.phone && Boolean(formik.errors.phone)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.phone ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
            />
          </Stack>
        </Grid>

        <Grid item xs={12} lg={6}>
          <Stack>
            <StyledCustomTextField
              id="location"
              name="location"
              label="Location"
              size="medium"
              type="text"
              value={formik.values.location}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.location ? formik.errors.location : ""}
              error={formik.touched.location && Boolean(formik.errors.location)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.location ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
            />
          </Stack>
        </Grid>

        <Grid item xs={12} lg={6}>
          <Stack>
            <StyledCustomTextField
              id="gender"
              name="gender"
              label="Gender"
              size="medium"
              select
              value={formik.values.gender}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.gender ? formik.errors.gender : ""}
              error={formik.touched.gender && Boolean(formik.errors.gender)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.location ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
            >
              <MenuItem value="male">Male</MenuItem>
              <MenuItem value="female">Female</MenuItem>
              <MenuItem value="diverse">Diverse</MenuItem>
              <MenuItem value="undifined">Undifined</MenuItem>
            </StyledCustomTextField>
          </Stack>
        </Grid>

        <Grid item xs={12} lg={6}>
          <Stack>
            <StyledCustomTextField
              id="systemRole"
              name="systemRole"
              label="Select Access Level"
              size="medium"
              select
              value={formik.values.systemRole}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.systemRole ? formik.errors.systemRole : ""
              }
              error={
                formik.touched.systemRole && Boolean(formik.errors.systemRole)
              }
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.location ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
            >
              <MenuItem value="employee">Employee</MenuItem>
              <MenuItem value="manager">Manager</MenuItem>
              <MenuItem value="admin">Admin</MenuItem>
            </StyledCustomTextField>
          </Stack>
        </Grid>
      </Grid>
    </StyledWrapper>
  );
};

export default PersonalInformation;
