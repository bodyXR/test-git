import {
  Box,
  Checkbox,
  Grid,
  MenuItem,
  Stack,
  Typography,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import checkboxIcon from "../../../assets/checkbox_icon.svg";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import StyledCustomTextField from "../../../components/styled/StyledCustomTextField";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import {
  fetchDepartments,
  fetchTeams,
} from "../../../redux/slices/admin/companyProfile/configSlice";
import SelectRole from "./SelectRole";
import SelectManager from "./SelectManager";
import SelectManager_V2 from "./SelectManager_V2";

const RoleDetails = ({ formik, employeeId }) => {
  const { departments, teams } = useSelector((state) => state.config);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchDepartments());
    dispatch(fetchTeams());
  }, []);

  return (
    <StyledWrapper sx={{ gap: "20px", p: { xs: "12px", lg: "20px" } }}>
      <Typography variant="h3" color="darkGreenAccent">
        Role Details
      </Typography>

      <Grid container spacing="20px">
        <Grid item xs={12} lg={6}>
          <Stack>
            <SelectManager employeeId={employeeId} formik={formik} />
            {/* <SelectManager_V2 formik={formik} /> */}
          </Stack>
        </Grid>

        <Grid item xs={12} lg={6}>
          <Stack>
            <StyledCustomTextField
              id="department"
              name="department"
              label="Select Department"
              size="medium"
              select
              value={formik.values.department}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.department ? formik.errors.department : ""
              }
              error={
                formik.touched.department && Boolean(formik.errors.department)
              }
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.location ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
              SelectProps={{
                MenuProps: {
                  anchorOrigin: {
                    vertical: "bottom",
                    horizontal: "center",
                  },
                  PaperProps: {
                    style: {
                      maxHeight: "150px",
                    },
                  },
                  getContentAnchorEl: null,
                },
              }}
            >
              {departments?.map((department) => (
                <MenuItem key={department} value={department}>
                  {department}
                </MenuItem>
              ))}
            </StyledCustomTextField>

            {formik.touched.department && formik.errors.department ? (
              <Typography
                sx={{
                  color: "#d32f2f",
                  mx: "14px",
                  mt: "3px",
                  fontSize: "0.8571428571428571rem",
                }}
              >
                {formik.errors.department}
              </Typography>
            ) : null}
          </Stack>
        </Grid>

        <Grid item xs={12} lg={6}>
          <Stack>
            <StyledCustomTextField
              id="team"
              name="team"
              label="Select Team"
              size="medium"
              select
              value={formik.values.team}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.team ? formik.errors.team : ""}
              error={formik.touched.team && Boolean(formik.errors.team)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.location ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
              SelectProps={{
                MenuProps: {
                  anchorOrigin: {
                    vertical: "bottom",
                    horizontal: "center",
                  },
                  PaperProps: {
                    style: {
                      maxHeight: "150px",
                    },
                  },
                  getContentAnchorEl: null,
                },
              }}
            >
              {teams?.map((team) => (
                <MenuItem key={team} value={team}>
                  {team}
                </MenuItem>
              ))}
            </StyledCustomTextField>

            {formik.touched.team && formik.errors.team ? (
              <Typography
                sx={{
                  color: "#d32f2f",
                  mx: "14px",
                  mt: "3px",
                  fontSize: "0.8571428571428571rem",
                }}
              >
                {formik.errors.team}
              </Typography>
            ) : null}
          </Stack>
        </Grid>

        <Grid item xs={12} lg={6}>
          <Stack>
            <SelectRole formik={formik} />
          </Stack>
        </Grid>

        <Grid item xs={12} lg={6}>
          <Stack
            sx={{
              flexDirection: "row",
              gap: 2,
              alignItems: "center",
            }}
          >
            <Checkbox
              sx={{ width: "32px", height: "32px" }}
              id="checked"
              checked={formik.values.checked}
              onChange={formik.handleChange}
              color="primary"
              icon={<CheckBoxOutlineBlankIcon sx={{ color: "primary.main" }} />}
              checkedIcon={
                <Box
                  sx={{ width: "24px", height: "24px" }}
                  component={"img"}
                  src={checkboxIcon}
                />
              }
            />

            <Typography
              variant="h5"
              component="label"
              htmlFor="invitation"
              sx={{
                color: "inactive.main",
                cursor: "pointer",
              }}
            >
              Send invitation to employee
            </Typography>
          </Stack>
        </Grid>
      </Grid>
    </StyledWrapper>
  );
};

export default RoleDetails;
