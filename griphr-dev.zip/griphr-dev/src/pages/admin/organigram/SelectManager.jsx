import React, { useCallback, useEffect, useState } from "react";
import {
  Alert,
  Autocomplete,
  Box,
  CircularProgress,
  InputAdornment,
  MenuItem,
  Snackbar,
  Stack,
  TextField,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { useSelector } from "react-redux";
import axiosInstance from "../../../helper/axiosInstance";

const SelectManager = ({ formik, employeeId }) => {
  const [fetchedManagersData, setFetchedManagersData] = useState([]);
  const [searchUserQuery, setSearchUserQuery] = useState("");
  const [selectedManager, setSelectedManager] = useState(
    formik.values.manager || ""
  );
  const [isLoading, setIsLoading] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const [openSnack, setOpenSnack] = useState(false);

  const fetchManagers = useCallback(
    async (token) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: {
          role_only: true,
        },
      };

      try {
        setIsLoading(true);
        const response = await axiosInstance.get(`user`, config);
        setFetchedManagersData(response.data.payload.data);
      } catch (error) {
        setIsLoading(false);
        handleOpenSnack();

        console.log(error);
      } finally {
        setIsLoading(false);
      }
    },
    [token]
  );

  useEffect(() => {
    fetchManagers(token);
  }, [token]);

  const fetchUserById = useCallback(async (id) => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        id,
      },
    };
    try {
      const response = await axiosInstance.get(`user`, config);
      // console.log(
      //   "fetch manager",
      //   response?.data?.payload?.data[0]?.role?.manager
      // );
      const user = response.data.payload.data[0]?.role?.manager;
      if (user)
        setSelectedManager({
          label: `${user?.first_name} ${user?.last_name}`,
          value: user?.id,
          key: user?.id,
        });
    } catch (error) {
      console.log("error", error);
    } finally {
    }
  }, []);

  useEffect(() => {
    if (fetchedManagersData?.length > 0) {
      fetchUserById(employeeId);
    }
  }, [fetchedManagersData, employeeId, fetchUserById]);

  const handleSearchChange = (event, value) => {
    setSearchUserQuery(value);
  };

  const filteredUsers = fetchedManagersData
    ?.slice()
    ?.sort((a, b) => a?.first_name?.localeCompare(b?.first_name))
    .filter(
      (user) =>
        user.first_name.toLowerCase().includes(searchUserQuery.toLowerCase()) ||
        user.last_name.toLowerCase().includes(searchUserQuery.toLowerCase())
    );

  const handleOpenSnack = () => {
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={"error"}
          sx={{ width: "100%" }}
        >
          Error Fetching Managers Data !
        </Alert>
      </Snackbar>
      <Stack sx={{ flexDirection: "row", gap: 1 }}>
        <Autocomplete
          freeSolo
          // disableClearable --> to disable close icon (second icon)
          disableClearable
          disabled={isLoading}
          id="manager"
          name="manager"
          options={filteredUsers?.map((user) => ({
            label: `${user.first_name} ${user.last_name}`,
            value: user.id,
            key: user.id,
          }))}
          getOptionLabel={(option) => option.label || ""}
          value={selectedManager}
          onChange={(_, value) => {
            setSelectedManager(value);
            formik.setFieldValue("manager", value ? value.value : "");
          }}
          onBlur={formik.handleBlur}
          inputValue={searchUserQuery}
          onInputChange={handleSearchChange}
          sx={{ "& .MuiOutlinedInput-root": { py: "7px" }, flex: 1 }}
          renderInput={(params) => (
            <TextField
              error={formik.touched.manager && Boolean(formik.errors.manager)}
              helperText={formik.touched.manager ? formik.errors.manager : ""}
              name="manager"
              fullWidth
              label="Select Manager"
              placeholder="Select Manager"
              {...params}
              type="search"
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <InputAdornment position="end">
                    <div style={{ display: "flex", alignItems: "center" }}>
                      {params.InputProps.endAdornment}
                    </div>
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          )}
        />
        {isLoading && (
          <CircularProgress size={15} sx={{ mb: 1, alignSelf: "flex-end" }} />
        )}
      </Stack>
    </>
  );
};

export default SelectManager;
