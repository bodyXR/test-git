import React, { useCallback, useEffect, useState } from "react";
import {
  Alert,
  Autocomplete,
  Box,
  Button,
  CircularProgress,
  InputAdornment,
  MenuItem,
  Popover,
  Snackbar,
  Stack,
  TextField,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { useSelector } from "react-redux";
import axiosInstance from "../../../helper/axiosInstance";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import StyledCustomTextField from "../../../components/styled/StyledCustomTextField";

const SelectManager_V2 = ({ formik }) => {
  const [fetchedUsersData, setFetchedUsersData] = useState([]);
  const [searchfield, setSearchfield] = useState("");
  const [selectedManager, setSelectedManager] = useState(
    formik.values.manager || ""
  );
  const [isLoading, setIsLoading] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const { data: usersData } = useSelector((state) => state.users);
  const [openSnack, setOpenSnack] = useState(false);
  const [isSelectManager, setIsSelectManager] = useState(null);

  // console.log("usersData", usersData);
  //  TODO: ASk about param role_only
  const fetchManagers = useCallback(
    async (token) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: {
          role_only: true,
        },
      };

      try {
        setIsLoading(true);
        const response = await axiosInstance.get(`user`, config);
        setFetchedUsersData(response.data.payload.data);
      } catch (error) {
        setIsLoading(false);
        handleOpenSnack();

        console.log(error);
      } finally {
        setIsLoading(false);
      }
    },
    [token]
  );
  // console.log("fetchedUsersData", fetchedUsersData);

  useEffect(() => {
    fetchManagers(token);
  }, [token]);

  const onSearchChange = (event) => {
    setSearchfield(event.target.value);
  };

  const filteredUsers = fetchedUsersData
    ?.slice()
    ?.sort((a, b) => a?.first_name?.localeCompare(b?.first_name))
    .filter(
      (user) =>
        user.first_name.toLowerCase().includes(searchfield.toLowerCase()) ||
        user.last_name.toLowerCase().includes(searchfield.toLowerCase())
    );

  const handleOpenSnack = () => {
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setOpenSnack(false);
  };

  return (
    <>
      <StyledCustomTextField
        id="manager"
        name="manager"
        label="Select Manager"
        size="medium"
        select
        value={formik.values.manager}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        helperText={formik.touched.manager ? formik.errors.manager : ""}
        error={formik.touched.manager && Boolean(formik.errors.manager)}
        variant="outlined"
        InputLabelProps={{
          style: {
            top: formik.values.location ? "0px" : "-2.5px", // Adjust based on content
          },
        }}
        sx={{ "& .MuiOutlinedInput-root": { width: "100%" } }}
        SelectProps={{
          MenuProps: {
            anchorOrigin: {
              vertical: "bottom",
              horizontal: "center",
            },
            PaperProps: {
              style: {
                maxHeight: "150px",
              },
            },
            getContentAnchorEl: null,
          },
        }}
      >
        (
        <MenuItem
          sx={{ pointerEvents: "none" }}
          value="none"
          disableTouchRipple
        >
          <StyledCustomTextField
            onClick={(e) => e.stopPropagation()}
            sx={{ pointerEvents: "initial" }}
            type="search"
            InputProps={{
              //   ...params.InputProps,
              endAdornment: (
                <InputAdornment position="end">
                  {/* <div style={{ display: "flex", alignItems: "center" }}>
                    {params.InputProps.endAdornment}
                  </div> */}
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
        </MenuItem>
        )
        {filteredUsers?.map((user) => (
          <MenuItem key={user?.id} value={user?.id}>
            {user?.first_name} {user?.last_name}
          </MenuItem>
        ))}
      </StyledCustomTextField>
    </>
  );
};

export default SelectManager_V2;
