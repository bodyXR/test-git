import * as yup from "yup";

export const addRoleFormValidationSchema = yup.object().shape({
  roleName: yup.string().required("Role name is required"),
  department: yup.string().required("Department is required"),
});

export const existingEmployeeFormValidationSchema = yup.object().shape({
  employee: yup.string().required("Employee name is required"),
});

export const creatingNewEmployeeFormValidationSchema = yup.object().shape({
  firstName: yup.string().required("First name is required"),
  lastName: yup.string().required("Last name is required"),
  email: yup
    .string()
    .email("Invalid email format")
    .required("Email is required"),
  systemRole: yup.string().required("Access level is required"),
});

export const bulkUploadValidationSchema = yup.object().shape({
  files: yup.mixed().required("You need to provide a file"),
  users: yup.array().of(
    yup.object().shape({
      first_name: yup.string().required("first_name is not exist"),
      last_name: yup.string().required("last_name is not exist"),
      email: yup
        .string()
        .email("Invalid email format")
        .required("email is not exist"),
      system_role: yup.string().required("system_role is not exist"),
      phone: yup.string().optional(),
      location: yup.string().optional(),
      gender: yup.string().optional(),
    })
  ),
});
