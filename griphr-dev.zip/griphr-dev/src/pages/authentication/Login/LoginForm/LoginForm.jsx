import {
  Alert,
  Box,
  Button,
  Divider,
  Snackbar,
  Stack,
  Typography,
} from "@mui/material";
import googleIcon from "../../../../assets/google-icon.svg";
import microsoftIcon from "../../../../assets/microsoft-icon.svg";
import { useFormik } from "formik";
import { Link, useLocation, useNavigate } from "react-router-dom";
import * as yup from "yup";
import {
  ADMIN_PAGE_ROUTE,
  EMPLOYEE_PAGE_ROUTE,
  MANAGER_PAGE_ROUTE,
  MODERATOR_PAGE_ROUTE,
  STAFF_PAGE_ROUTE,
} from "../../../../routes/paths";
import validationsForm from "../validations/validationSchema";
import { useDispatch, useSelector } from "react-redux";
import {
  userLogin,
  userLoginWithGoogleOrMicrosoft,
} from "../../../../redux/slices/auth/authActions";
import { useState } from "react";
import { useEffect } from "react";
import Turnstile from "react-turnstile";
import StyledCustomTextField from "../../../../components/styled/StyledCustomTextField";

const socialLoginBtnStyles = {
  width: "300px",
  height: "40px",
  background: "white",
  color: "secondary.main",
  textTransform: "none",
  boxShadow: "none",
  border: "1px solid #EEE",
  borderRadius: "4px",
  "&:hover": {
    background: "white",
    boxShadow: "none",
    border: "1px solid #353C44",
  },
};

const LoginForm = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { loading, userInfo, error, isAuth } = useSelector(
    (state) => state.auth
  );
  const role = userInfo ? userInfo.system_role : null;
  const [open, setOpen] = useState(false);
  const [errorPayload, setErrorPayload] = useState(null);
  const [cloudFlareToken, setCloudFlareToken] = useState("");
  const queryParams = new URLSearchParams(location.search);
  const errorParam = queryParams.get("error");

  const handleClick = (payload) => {
    setOpen(true);
    setErrorPayload(payload);
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  useEffect(() => {
    if (errorParam) {
      setOpen(true);
    }
  }, [errorParam]);

  const formik = useFormik({
    initialValues: { email: "", password: "" },
    validationSchema: yup.object().shape(validationsForm),
    onSubmit: (values, { setSubmitting }) => {
      setTimeout(() => {
        // submit to the server
        dispatch(
          userLogin({
            email: values.email,
            password: values.password,
            token: cloudFlareToken,
          })
        );
        setSubmitting(false);
      }, 1000);
    },
  });

  useEffect(() => {
    if (error && !isAuth) {
      handleClick({ message: "Failed to log in" });
    }

    return () => {
      setErrorPayload(null);
    };
  }, [error, isAuth]);

  const handleGoogleSignUp = (api) => {
    dispatch(
      userLoginWithGoogleOrMicrosoft({
        api,
        token: cloudFlareToken,
        operation: "login",
      })
    );
  };

  // Redirection
  useEffect(() => {
    if (isAuth) {
      if (role === "admin") {
        navigate(ADMIN_PAGE_ROUTE);
      } else if (role === "manager") {
        navigate(MANAGER_PAGE_ROUTE);
      } else if (role === "employee") {
        navigate(EMPLOYEE_PAGE_ROUTE);
      } else if (role === "staff") {
        navigate(STAFF_PAGE_ROUTE);
      } else if (role === "moderator") {
        navigate(MODERATOR_PAGE_ROUTE);
      }
    }
  }, [navigate, role, isAuth]);

  return (
    <>
      <Snackbar
        open={open}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleClose}
      >
        <Alert onClose={handleClose} severity={"error"} sx={{ width: "100%" }}>
          {errorParam ? errorParam : errorPayload?.message}
        </Alert>
      </Snackbar>

      <form onSubmit={formik.handleSubmit}>
        <Stack
          sx={{
            width: "100%",
            alignItems: "center",
            gap: { xs: 3, lg: 5 },
          }}
        >
          <Stack>
            <Box mb={1}>
              <StyledCustomTextField
                id="email"
                name="email"
                label="Email"
                size="medium"
                type="email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                helperText={formik.touched.email ? formik.errors.email : ""}
                error={formik.touched.email && Boolean(formik.errors.email)}
                variant="outlined"
                InputLabelProps={{
                  style: {
                    top: formik.values.email ? "0px" : "-2.5px", // Adjust based on content
                  },
                }}
              />
            </Box>

            <StyledCustomTextField
              id="password"
              name="password"
              label="Password"
              size="medium"
              type="password"
              value={formik.values.password}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.password ? formik.errors.password : ""}
              error={formik.touched.password && Boolean(formik.errors.password)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.password ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
            />

            <Link to="/recover" style={{ color: "#66C1FF" }}>
              <Typography variant="body1">Forgot your Password?</Typography>
            </Link>
          </Stack>

          <Stack>
            <Turnstile
              className="dave"
              sitekey={process.env.REACT_APP_TURNSTILE_SITE_KEY}
              onVerify={(token) => setCloudFlareToken(token)}
            />

            <Button
              type="submit"
              variant="contained"
              color="secondary"
              size="large"
              disabled={formik.isSubmitting}
              sx={{
                width: "300px",
                height: "40px",
                backgroundColor: "darkGreenAccent",
                borderRadius: "4px",
                textTransform: "capitalize",
              }}
            >
              <Typography variant="h6">log in</Typography>
            </Button>
          </Stack>

          <Box sx={{ display: "flex", alignItems: "center", width: "100%" }}>
            <Divider sx={{ flex: 1, height: "1px", color: "darkGrey" }} />

            <Typography
              variant="body2"
              sx={{ color: "inactive.main", px: "12px" }}
            >
              Or
            </Typography>

            <Divider sx={{ flex: 1, height: "1px", color: "darkGrey" }} />
          </Box>

          <Stack gap="10px">
            <Button
              onClick={() => handleGoogleSignUp("auth/google/login/")}
              variant="contained"
              startIcon={
                <img
                  src={googleIcon}
                  alt="google icon"
                  style={{ width: "20px", height: "20px" }}
                />
              }
              size="large"
              sx={socialLoginBtnStyles}
            >
              <Typography variant="h5">Login with Google</Typography>
            </Button>

            <Button
              onClick={() => handleGoogleSignUp("auth/azure/login/")}
              variant="contained"
              startIcon={
                <img
                  src={microsoftIcon}
                  alt="microsoft icon"
                  style={{ width: "20px", height: "20px" }}
                />
              }
              size="large"
              sx={socialLoginBtnStyles}
            >
              <Typography variant="h5">Login with Microsoft</Typography>
            </Button>
          </Stack>

          {/* <Typography variant="body1" color="darkGrey">
            Don't have an account?{" "}
            <Link to="/signup" style={{ color: "#66C1FF" }}>
              Sign Up
            </Link>
          </Typography> */}
        </Stack>
      </form>
    </>
  );
};

export default LoginForm;
