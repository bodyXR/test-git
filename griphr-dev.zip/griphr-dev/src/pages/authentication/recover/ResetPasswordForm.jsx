import { Alert, Button, Snackbar, Stack, Typography } from "@mui/material";
import { useFormik } from "formik";
import { Link } from "react-router-dom";
import * as yup from "yup";
import { resetPasswordValidationsForm } from "./validations/validationSchema";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { userRecover } from "../../../redux/slices/auth/authActions";
import { setResponse } from "../../../redux/slices/auth/authSlice";
import StyledCustomTextField from "../../../components/styled/StyledCustomTextField";

const ResetPasswordForm = () => {
  const dispatch = useDispatch();
  const { response, loading } = useSelector((state) => state.auth);
  const [open, setOpen] = useState(false);

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  const formik = useFormik({
    initialValues: {
      email: "",
      token: "",
      password: "",
      confirmPassword: "",
    },
    validationSchema: yup.object().shape(resetPasswordValidationsForm),
    onSubmit: (values, { setSubmitting, resetForm }) => {
      setTimeout(() => {
        // submit to the server
        // Assuming the userReset function returns a promise
        dispatch(
          userRecover({
            email: values.email,
            email_confirmation: values.token,
            new_password1: values.password,
            new_password2: values.confirmPassword,
          })
        )
          .then((response) => {
            // Password recovery request is successful, show the ResetPasswordForm
            dispatch(setResponse(response.payload));
            handleClick();
          })
          .finally(() => {
            setSubmitting(false);
            resetForm(); // Reset the form values after successful submission
          });
      }, 1000);
    },
  });

  return (
    <>
      <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
        <Alert
          onClose={handleClose}
          severity={!response?.success ? "error" : "success"}
          sx={{ width: "100%" }}
        >
          {response?.message}
        </Alert>
      </Snackbar>

      <form onSubmit={formik.handleSubmit}>
        <Stack
          className="reset"
          sx={{
            width: "100%",
            alignItems: "center",
            gap: { xs: 3, lg: 5 },
          }}
        >
          <Stack gap={1}>
            <StyledCustomTextField
              id="email"
              name="email"
              label="Email"
              size="medium"
              type="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.email ? formik.errors.email : ""}
              error={formik.touched.email && Boolean(formik.errors.email)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.email ? "0px" : "-5px", // Adjust based on content
                },
              }}
            />

            <StyledCustomTextField
              id="token"
              name="token"
              label="Token"
              size="medium"
              type="token"
              value={formik.values.token}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.token ? formik.errors.token : ""}
              error={formik.touched.token && Boolean(formik.errors.token)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.token ? "0px" : "-5px", // Adjust based on content
                },
              }}
            />

            <StyledCustomTextField
              id="password"
              name="password"
              label="Password"
              size="medium"
              type="password"
              value={formik.values.password}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.password ? formik.errors.password : ""}
              error={formik.touched.password && Boolean(formik.errors.password)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.password ? "0px" : "-5px", // Adjust based on content
                },
              }}
            />

            <StyledCustomTextField
              id="confirmPassword"
              name="confirmPassword"
              label="Confirm Password"
              size="medium"
              type="password"
              value={formik.values.confirmPassword}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.confirmPassword
                  ? formik.errors.confirmPassword
                  : ""
              }
              error={
                formik.touched.confirmPassword &&
                Boolean(formik.errors.confirmPassword)
              }
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.confirmPassword ? "0px" : "-5px", // Adjust based on content
                },
              }}
            />
          </Stack>

          <Button
            type="submit"
            variant="contained"
            color="secondary"
            size="large"
            disabled={formik.isSubmitting}
            sx={{
              width: "300px",
              height: "40px",
              backgroundColor: "darkGreenAccent",
              borderRadius: "4px",
              textTransform: "capitalize",
            }}
          >
            <Typography variant="h6">Send</Typography>
          </Button>

          <Stack alignItems="center" gap="10px">
            <Typography variant="body1" color="darkGrey">
              Have an account?{" "}
              <Link to="/login" style={{ color: "#66C1FF" }}>
                Log In
              </Link>
            </Typography>

            <Typography variant="body1" color="darkGrey">
              Don't have an account?{" "}
              <Link to="/signup" style={{ color: "#66C1FF" }}>
                Sign Up
              </Link>
            </Typography>
          </Stack>
        </Stack>
      </form>
    </>
  );
};

export default ResetPasswordForm;
