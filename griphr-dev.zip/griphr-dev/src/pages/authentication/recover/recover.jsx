import { Box, Stack, Typography, useMediaQuery, useTheme } from "@mui/material";
import RecoverForm from "./recoverForm/recoverForm";
import logo from "../../../assets/Logo/Logo - Export/Adepti - Horizontal Logo 1.png";
import xsMockup from "../../../assets/login_mockup_xs.png";
import lgMockup from "../../../assets/login_mockup_lg.png";

const Recover = () => {
  const theme = useTheme();
  const lgMatches = useMediaQuery(theme.breakpoints.up("lg"));

  return (
    <Box
      className="login"
      sx={{
        display: "flex",
        flexDirection: { xs: "column", lg: "row-reverse" },
        justifyContent: "center",
        alignItems: "center",
        gap: { xs: 3, lg: 4 },
        width: "100%",
        mt: 4,
      }}
    >
      {!lgMatches && <Box component="img" src={logo} width={230} />}

      <Box component="img" src={lgMatches ? lgMockup : xsMockup} />

      <Stack sx={{ gap: "10px", ml: { lg: "80px" } }}>
        <Stack sx={{ alignItems: "center", gap: "60px" }}>
          {lgMatches && <Box component="img" src={logo} width={230} />}

          <RecoverForm />
        </Stack>

        <Typography
          variant="body1"
          sx={{
            color: "darkGrey",
            textAlign: "center",
          }}
        >
          Adepti® All Rights Reserved
        </Typography>
      </Stack>
    </Box>
  );
};

export default Recover;
