import {
  Alert,
  Box,
  Button,
  Divider,
  Snackbar,
  Stack,
  Typography,
} from "@mui/material";
import googleIcon from "../../../../assets/google-icon.svg";
import microsoftIcon from "../../../../assets/microsoft-icon.svg";
import { useFormik } from "formik";
import { Link, useLocation } from "react-router-dom";
import * as yup from "yup";
import validationsForm from "../validations/validationSchema";
import { useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import { userLoginWithGoogleOrMicrosoft } from "../../../../redux/slices/auth/authActions";
import Turnstile from "react-turnstile";
import StyledCustomTextField from "../../../../components/styled/StyledCustomTextField";

const socialLoginBtnStyles = {
  width: "300px",
  height: "40px",
  background: "white",
  color: "secondary.main",
  textTransform: "none",
  boxShadow: "none",
  border: "1px solid #EEE",
  borderRadius: "4px",
  "&:hover": {
    background: "white",
    boxShadow: "none",
    border: "1px solid #353C44",
  },
};

const SignupForm = () => {
  const dispatch = useDispatch();
  const [open, setOpen] = useState(false);
  const [payload, setPayload] = useState(null);
  const [errorPayload, setErrorPayload] = useState(null);
  const [cloudFlareToken, setCloudFlareToken] = useState("");
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const errorParam = queryParams.get("error");

  const handleGoogleSignUp = (api) => {
    dispatch(
      userLoginWithGoogleOrMicrosoft({
        api,
        token: cloudFlareToken,
        operation: "signup",
      })
    );
  };

  const handleClick = (payload, isError = false) => {
    setOpen(true);
    if (isError) {
      setErrorPayload(payload);
    } else {
      setPayload(payload);
    }
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  useEffect(() => {
    if (errorParam) {
      setOpen(true);
    }
  }, [errorParam]);

  const formik = useFormik({
    initialValues: {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
    validationSchema: yup.object().shape(validationsForm),
    onSubmit: (values, { setSubmitting }) => {
      setTimeout(() => {
        // submit to the server
        console.log(values);
        setSubmitting(false);
      }, 1000);
    },
  });

  return (
    <>
      {errorParam && (
        <Snackbar
          open={open}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
          autoHideDuration={3000}
          onClose={handleClose}
        >
          <Alert
            onClose={handleClose}
            severity={"error"}
            sx={{ width: "100%" }}
          >
            {errorParam}
          </Alert>
        </Snackbar>
      )}

      <form onSubmit={formik.handleSubmit}>
        <Stack
          sx={{
            width: "100%",
            alignItems: "center",
            gap: { xs: 3, lg: 5 },
          }}
        >
          <Stack gap={1}>
            <StyledCustomTextField
              id="firstName"
              name="firstName"
              label="First Name"
              size="medium"
              type="text"
              value={formik.values.firstName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.firstName ? formik.errors.firstName : ""
              }
              error={
                formik.touched.firstName && Boolean(formik.errors.firstName)
              }
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.firstName ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
            />

            <StyledCustomTextField
              id="lastName"
              name="lastName"
              label="Last Name"
              size="medium"
              type="text"
              value={formik.values.lastName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.lastName ? formik.errors.lastName : ""}
              error={formik.touched.lastName && Boolean(formik.errors.lastName)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.lastName ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
            />

            <StyledCustomTextField
              id="email"
              name="email"
              label="Email"
              size="medium"
              type="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.email ? formik.errors.email : ""}
              error={formik.touched.email && Boolean(formik.errors.email)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.email ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
            />

            <StyledCustomTextField
              id="password"
              name="password"
              label="Password"
              size="medium"
              type="password"
              value={formik.values.password}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.password ? formik.errors.password : ""}
              error={formik.touched.password && Boolean(formik.errors.password)}
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.password ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
            />

            <StyledCustomTextField
              id="confirmPassword"
              name="confirmPassword"
              label="Confirm Password"
              size="medium"
              type="password"
              value={formik.values.confirmPassword}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.confirmPassword
                  ? formik.errors.confirmPassword
                  : ""
              }
              error={
                formik.touched.confirmPassword &&
                Boolean(formik.errors.confirmPassword)
              }
              variant="outlined"
              InputLabelProps={{
                style: {
                  top: formik.values.confirmPassword ? "0px" : "-2.5px", // Adjust based on content
                },
              }}
            />
          </Stack>

          <Stack>
            <Turnstile
              className="dave"
              sitekey={process.env.REACT_APP_TURNSTILE_SITE_KEY}
              onVerify={(token) => setCloudFlareToken(token)}
            />

            <Button
              type="submit"
              variant="contained"
              color="secondary"
              size="large"
              disabled={formik.isSubmitting}
              onClick={() => handleClick({ message: "Signup successful" })}
              sx={{
                width: "300px",
                height: "40px",
                backgroundColor: "darkGreenAccent",
                borderRadius: "4px",
                textTransform: "capitalize",
              }}
            >
              <Typography variant="h6">Sign Up</Typography>
            </Button>
          </Stack>

          <Box sx={{ display: "flex", alignItems: "center", width: "100%" }}>
            <Divider sx={{ flex: 1, height: "1px", color: "darkGrey" }} />

            <Typography
              variant="body2"
              sx={{ color: "inactive.main", px: "12px" }}
            >
              Or
            </Typography>

            <Divider sx={{ flex: 1, height: "1px", color: "darkGrey" }} />
          </Box>

          <Stack gap="10px">
            <Button
              onClick={() => handleGoogleSignUp("auth/google/login/")}
              variant="contained"
              startIcon={
                <img
                  src={googleIcon}
                  alt="google icon"
                  style={{ width: "20px", height: "20px" }}
                />
              }
              size="large"
              sx={socialLoginBtnStyles}
            >
              <Typography variant="h5">Sign up with Google</Typography>
            </Button>

            <Button
              onClick={() => handleGoogleSignUp("auth/azure/login/")}
              variant="contained"
              startIcon={
                <img
                  src={microsoftIcon}
                  alt="microsoft icon"
                  style={{ width: "20px", height: "20px" }}
                />
              }
              size="large"
              sx={socialLoginBtnStyles}
            >
              <Typography variant="h5">Sign up with Microsoft</Typography>
            </Button>
          </Stack>

          <Typography variant="body1" color="darkGrey">
            Have an account?{" "}
            <Link to="/login" style={{ color: "#66C1FF" }}>
              Log In
            </Link>
          </Typography>
        </Stack>
      </form>
    </>
  );
};

export default SignupForm;
