import React, { useCallback, useEffect } from "react";
import {
  Box,
  CircularProgress,
  Divider,
  IconButton,
  Stack,
  TextField,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import delete_inactive from "../../../assets/delete_inactive.svg";
import axiosInstance from "../../../helper/axiosInstance";
import { fetchGoalsDataById } from "../../../redux/slices/Employee/goals/goalsActions";
import { useDispatch, useSelector } from "react-redux";
import { useFormik } from "formik";

const ActionDetails = ({ goal, handleOpenSnack, data, type, isManager }) => {
  const theme = useTheme();
  const lgMatches = useMediaQuery(theme.breakpoints.up("lg"));
  const { token } = useSelector((state) => state.auth);
  const { loading } = useSelector((state) => state.goals);
  const dispatch = useDispatch();

  useEffect(() => {
    formik.setValues({ percentage: data?.percentage });
  }, [data]);

  const formik = useFormik({
    initialValues: {
      percentage: "",
    },
  });

  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      handleUpdatePercentage(data.id, formik.values.percentage);
    }
  };

  const handleUpdatePercentage = useCallback(async (id, percentage) => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
    };

    try {
      const response = await axiosInstance.put(
        "goals/actions",
        {
          id: id,
          percentage,
        },
        config
      );
      console.log(response.data.payload);
      handleOpenSnack(true, response.data.message);
    } catch (error) {
      console.log(error?.response.data);
      handleOpenSnack(false, error?.response.data.message);
    } finally {
      dispatch(fetchGoalsDataById(goal.id));
    }
  }, []);

  const handleRemoveAction = useCallback(async (id) => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        id,
      },
    };

    try {
      const response = await axiosInstance.delete("goals/actions", config);
      console.log(response.data.payload);
      handleOpenSnack(true, response.data.message);
    } catch (error) {
      console.log(error?.response.data);
      handleOpenSnack(false, error?.response.data.message);
    } finally {
      dispatch(fetchGoalsDataById(goal.id));
    }
  }, []);

  return (
    <Stack gap={2}>
      <Grid container spacing={2} alignItems="center">
        <Grid xs={12} lg={9}>
          <Typography
            title={data.details.name || data.details.title}
            variant="body1"
            color="inactive.main"
          >
            {data.details.name || data.details.title}
          </Typography>
        </Grid>

        {goal.status !== "completed" && (
          <>
            <Grid xs={6} lg={2}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <TextField
                  variant="outlined"
                  size="small"
                  type="text"
                  id="percentage"
                  name="percentage"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.percentage}
                  onKeyDown={handleKeyDown}
                  disabled={
                    goal.status === "not started" || isManager ? true : false
                  }
                  sx={{
                    "& input": {
                      width: "40px",
                      height: "43px",
                      background: "white",
                      borderRadius: "4px",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      textAlign: "center",
                      color: "darkGrey",
                      p: 0,
                    },
                  }}
                />

                <Typography variant="body1" color="inactive.main">
                  / 100%
                </Typography>

                {loading && <CircularProgress size={20} />}
              </Box>
            </Grid>

            <Grid xs={6} lg={1} textAlign="right">
              <IconButton
                onClick={() => handleRemoveAction(data.id)}
                disabled={isManager ? true : false}
                sx={{ p: 0 }}
              >
                <Box component={"img"} src={delete_inactive} />
              </IconButton>
            </Grid>
          </>
        )}
      </Grid>

      {goal?.actions?.courses?.length > 1 &&
        goal?.actions?.courses[goal?.actions?.courses?.length - 1].id !==
          data.id &&
        type === "courses" &&
        !lgMatches && <Divider variant="middle" />}

      {goal?.actions?.projects?.length > 1 &&
        goal?.actions?.projects[goal?.actions?.projects?.length - 1].id !==
          data.id &&
        type === "projects" &&
        !lgMatches && <Divider variant="middle" />}

      {goal?.actions?.activities?.length > 1 &&
        goal?.actions?.activities[goal?.actions?.activities?.length - 1].id !==
          data.id &&
        type === "activities" &&
        !lgMatches && <Divider variant="middle" />}
    </Stack>
  );
};

export default ActionDetails;
