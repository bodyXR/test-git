import React, { useCallback } from "react";
import StyledTextField from "../../../components/styled/StyledTextField";
import StyledTextarea from "../../../components/styled/StyledTextarea";
import { Stack } from "@mui/material";
import StyledSmallDarkBtn from "../../../components/styled/StyledSmallDarkBtn";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../helper/axiosInstance";
import { fetchActionsDataByGoalId } from "../../../redux/slices/Employee/goals/goalsActions";
import { setSelectedActivities } from "../../../redux/slices/Employee/goals/goalsSlice";

const ActivitiesActionModule = ({
  formik,
  handleOpenSnack,
  onEdit,
  goalId,
}) => {
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const { selectedActivities } = useSelector((state) => state.goals);

  const addActivity = () => {
    // Create a function to filter out keys with empty string or null values
    const removeEmptyKeys = (obj) =>
      Object.fromEntries(
        Object.entries(obj).filter(([_, v]) => v !== "" && v !== null)
      );

    const details = removeEmptyKeys({
      title: formik.values.activityName,
      description: formik.values.activityDescription,
    });

    dispatch(
      setSelectedActivities([
        ...selectedActivities,
        {
          type: "activities",
          details,
        },
      ])
    );
  };

  const addActivityRequest = useCallback(
    async (title, description) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      // Create a function to filter out keys with empty string or null values
      const removeEmptyKeys = (obj) =>
        Object.fromEntries(
          Object.entries(obj).filter(([_, v]) => v !== "" && v !== null)
        );

      const details = removeEmptyKeys({
        title,
        description,
      });

      try {
        const response = await axiosInstance.post(
          `goals/actions`,
          {
            goal_id: goalId,
            actions: [
              {
                type: "activities",
                details,
              },
            ],
          },
          config
        );
        console.log(response.data.message);
        handleOpenSnack(true, response.data.message);
      } catch (error) {
        console.log(error?.response.data);
        handleOpenSnack(false, error?.response.data.message);
      } finally {
        dispatch(fetchActionsDataByGoalId(goalId));
      }
    },
    [token]
  );

  const handleAddActivity = () => {
    if (onEdit) {
      addActivityRequest(
        formik.values.activityName,
        formik.values.activityDescription
      );
    } else {
      addActivity();
    }

    formik.setFieldValue("activityName", "");
    formik.setFieldValue("activityDescription", "");
  };

  return (
    <Stack className="activities__wrapper" sx={{ mt: 2, gap: "16px" }}>
      <StyledTextField
        id="activityName"
        name="activityName"
        placeholder="Activity name"
        label="Activity name"
        type="text"
        value={formik.values.activityName}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        helperText={
          formik.touched.activityName ? formik.errors.activityName : ""
        }
        error={
          formik.touched.activityName && Boolean(formik.errors.activityName)
        }
      />

      <StyledTextarea
        id="activityDescription"
        name="activityDescription"
        placeholder="Description"
        label="Description"
        multiline
        rows={4}
        value={formik.values.activityDescription}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        helperText={
          formik.touched.activityDescription
            ? formik.errors.activityDescription
            : ""
        }
        error={
          formik.touched.activityDescription &&
          Boolean(formik.errors.activityDescription)
        }
      />

      <StyledSmallDarkBtn onClick={handleAddActivity}>
        add activity
      </StyledSmallDarkBtn>
    </Stack>
  );
};

export default ActivitiesActionModule;
