import { Alert, CircularProgress, Snackbar, Stack } from "@mui/material";
import React, { useCallback, useEffect, useState } from "react";
import StyledDarkBtn from "../../../components/styled/StyledDarkBtn";
import { useFormik } from "formik";
import StyledOutlinedBtn from "../../../components/styled/StyledOutlinedBtn";
import Step1AddGoal from "./Step1AddGoal";
import Step2AddGoal from "./Step2AddGoal";
import Step3AddGoal from "./Step3AddGoal";
import Step4AddGoal from "./Step4AddGoal";
import CustomModal from "../../../ui/CustomModal";
import AddSkillForm from "./AddSkillForm";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../helper/axiosInstance";
import {
  fetchActionsDataByGoalId,
  fetchGoalsData,
} from "../../../redux/slices/Employee/goals/goalsActions";
import { useLocation, useNavigate } from "react-router-dom";
import {
  EMPLOYEE_GOALS_ROUTE,
  EMPLOYEE_GOAL_DETAILS_ROUTE,
} from "../../../routes/paths";
import validationSchema from "./validations/validationSchema";
import { setSelectedSkills } from "../../../redux/slices/Employee/goals/goalsSlice";

function formatDate(date) {
  if (date) {
    const options = { year: "numeric", month: "2-digit", day: "2-digit" };
    const parts = date.toLocaleString("en-US", options).split("/");
    return `${parts[2]}-${parts[0]}-${parts[1]}`;
  }
}

const AddGoal = () => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const {
    actions,
    selectedCourses,
    selectedProjects,
    selectedActivities,
    selectedSkills,
  } = useSelector((state) => state.goals);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const onEdit = location.state?.onEdit || false;
  const data = location.state?.data || null;

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  // On Edit
  useEffect(() => {
    if (onEdit) {
      formik.setValues({
        name: data?.name || "",
        description: data?.description || "",
        skills: data?.skills || [],
        startDate: data?.start_date ? new Date(data?.start_date) : null,
        dueDate: data?.due_date ? new Date(data?.due_date) : null,
      });

      dispatch(setSelectedSkills(data?.skills));
      dispatch(fetchActionsDataByGoalId(data?.id));
    }
  }, [data]);

  const formik = useFormik({
    initialValues: {
      name: "",
      description: "",
      skills: [],
      activityName: "",
      activityDescription: "",
      startDate: null,
      dueDate: null,
    },
    validationSchema,
    onSubmit: (values) => {
      if (onEdit) {
        if (
          [...actions?.courses, ...actions?.projects, ...actions?.activities]
            .length === 0
        ) {
          // Handle "No one action at least validation
          return;
        }

        editGoal(token, values);
      } else {
        if (
          [...selectedCourses, ...selectedProjects, ...selectedActivities]
            .length === 0
        ) {
          // Handle "No one action at least validation
          return;
        }

        addGoal(token, values, [
          ...selectedCourses,
          ...selectedProjects,
          ...selectedActivities,
        ]);
      }
    },
  });

  useEffect(() => {
    formik.setFieldValue("skills", selectedSkills);
    if (selectedSkills.length > 0) {
      dispatch(setSelectedSkills(selectedSkills));
    }
  }, [selectedSkills]);

  const addGoal = useCallback(
    async (token, values, actions) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      const formatStartDate = formatDate(values.startDate);
      const formatDueDate = formatDate(values.dueDate);

      // Create a function to filter out keys with empty string or null values
      const removeEmptyKeys = (obj) =>
        Object.fromEntries(
          Object.entries(obj).filter(([_, v]) => v !== "" && v !== null)
        );

      const requestBody = removeEmptyKeys({
        name: values.name,
        description: values.description,
        skills: values.skills?.map((skill) => +skill.id),
        actions,
        start_date: formatStartDate,
        due_date: formatDueDate,
      });

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `goals/`,
          requestBody,
          config
        );
        handleOpenSnack(true, response.data.message);
        navigate(EMPLOYEE_GOALS_ROUTE);
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
      } finally {
        setLoading(false);
        dispatch(fetchGoalsData());
      }
    },
    [token]
  );

  const editGoal = useCallback(
    async (token, values) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      const formatStartDate = formatDate(values.startDate);
      const formatDueDate = formatDate(values.dueDate);

      // Create a function to filter out keys with empty string or null values
      const removeEmptyKeys = (obj) =>
        Object.fromEntries(
          Object.entries(obj).filter(([_, v]) => v !== "" && v !== null)
        );

      const requestBody = removeEmptyKeys({
        id: data.id,
        name: values.name,
        description: values.description,
        skills: values.skills?.map((skill) => +skill.id || skill.skill_id),
        start_date: formatStartDate,
        due_date: formatDueDate,
      });

      try {
        setLoading(true);
        const response = await axiosInstance.put(`goals/`, requestBody, config);
        handleOpenSnack(true, response.data.message);
        navigate(`${EMPLOYEE_GOAL_DETAILS_ROUTE}/${data.id}`);
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
      } finally {
        setLoading(false);
        dispatch(fetchGoalsData());
      }
    },
    [token]
  );

  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>

      <form onSubmit={formik.handleSubmit}>
        <CustomModal open={open} onClose={handleClose} title="Add Skill">
          <AddSkillForm closeModal={handleClose} />
        </CustomModal>

        <Stack sx={{ gap: 3 }}>
          {/* <Typography variant="body1" sx={{ color: "inactive.main" }}>
        Select where you want to create a goal type
      </Typography> */}

          {/* <Stack sx={{ gap: "12px" }}>
        <StyledGoalLocationBtn sx={{ borderColor: "accent" }}>
          Current role
        </StyledGoalLocationBtn>
      </Stack> */}

          <Step1AddGoal formik={formik} />

          <Step2AddGoal formik={formik} handleOpen={handleOpen} />

          <Step3AddGoal
            formik={formik}
            onEdit={onEdit}
            handleOpenSnack={handleOpenSnack}
            goalId={data?.id}
          />

          <Step4AddGoal formik={formik} />

          <Stack
            sx={{
              flexDirection: { lg: "row" },
              alignItems: "center",
              gap: "16px",
            }}
          >
            <StyledDarkBtn
              type="submit"
              sx={{ width: { xs: "100%", lg: "initial" } }}
            >
              confirm goal
            </StyledDarkBtn>

            <StyledOutlinedBtn
              onClick={() => navigate(EMPLOYEE_GOALS_ROUTE)}
              sx={{ width: { xs: "100%", lg: "initial" } }}
            >
              Cancel
            </StyledOutlinedBtn>

            {loading && <CircularProgress size={20} />}
          </Stack>
        </Stack>
      </form>
    </>
  );
};

export default AddGoal;
