import {
  Autocomplete,
  Box,
  Button,
  CircularProgress,
  IconButton,
  InputAdornment,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import { useFormik } from "formik";
import { useCallback, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../helper/axiosInstance";
import { useEffect } from "react";
import { debounce } from "lodash";
import * as yup from "yup";
import { setSelectedSkills } from "../../../redux/slices/Employee/goals/goalsSlice";

const validationsForm = yup.object().shape({
  skill: yup.string().required("Skill is required"),
});

const formControlWrapperStyle = {
  minHeight: "140px",
};

const AddSkillForm = ({ closeModal }) => {
  const [inputValue, setInputValue] = useState("");
  const [options, setOptions] = useState("");
  const { token } = useSelector((state) => state.auth);
  const noSkillsMatch = "No skills match";
  const dispatch = useDispatch();
  const { selectedSkills } = useSelector((state) => state.goals);

  // Loading State
  const [loading, setLoading] = useState(false);

  const formik = useFormik({
    initialValues: {
      skill: "",
      fullSkillObj: null,
    },
    validationSchema: validationsForm,
    onSubmit: (values, { setSubmitting }) => {
      if (values.skill === null || values.skill === noSkillsMatch) {
        // Handle "No skills match" validation
        formik.setFieldError("skill", "Please select a valid skill");
        setSubmitting(false);
        return;
      }

      try {
        // Submit to the server
        // setSelectedSkills((prevState) => [...prevState, values.fullSkillObj]);
        // closeModal();
        setSubmitting(false);
      } catch (error) {
        // Handle error
        console.log(error);
        setSubmitting(false);
      }
    },
  });

  const handleAddSkill = () => {
    dispatch(
      setSelectedSkills([...selectedSkills, formik.values.fullSkillObj])
    );
    closeModal();
  };

  const searchSkills = useCallback(
    async (token, value) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `search`,
          {
            key: "skill",
            value: value,
          },
          config
        );
        console.log(response.data);
        setOptions(response.data.payload);
      } catch (error) {
        console.log(error.response.data);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const debouncedSearchSkills = useCallback(
    debounce((token, inputValue) => {
      if (inputValue !== "") {
        searchSkills(token, inputValue);
      } else {
        setOptions([]);
      }
    }, 1000),
    []
  );

  useEffect(() => {
    debouncedSearchSkills(token, inputValue);
  }, [debouncedSearchSkills, token, inputValue]);

  const selectValue = useCallback(
    (e, optionName) => {
      const selectedOption = options.find(
        (option) => option.name === optionName
      );

      if (selectedOption) {
        formik.setFieldValue("fullSkillObj", selectedOption);
        formik.setFieldValue("skill", selectedOption.id);
      } else {
        formik.setFieldValue("fullSkillObj", null);
        formik.setFieldValue("skill", "");
      }
    },
    [formik, options]
  );

  // const handleSearch = useCallback(
  //   async (event) => {
  //     event.preventDefault();
  //     formik.handleSubmit(); // Submit the form

  //     if (formik.values.skill === noSkillsMatch) {
  //       return;
  //     }

  //     // Call the searchSkills function here
  //     await searchSkills(token, formik.values.skill);
  //   },
  //   [searchSkills, token, formik]
  // );

  const handleInputChange = (event, newValue) => {
    setInputValue(newValue);
  };

  return (
    <form>
      <Stack sx={{ px: { xs: 2.5, lg: 0 } }}>
        <Box sx={formControlWrapperStyle}>
          <Typography
            variant="h3"
            component="label"
            htmlFor="search_skill"
            sx={{
              textTransform: "capitalize",
              fontWeight: 400,
              color: "secondary.main",
            }}
          >
            search skills
            <span style={{ color: "red" }}>*</span>
          </Typography>

          <Autocomplete
            freeSolo
            id="search_skill"
            name="search_skill"
            options={
              options.length < 1
                ? [noSkillsMatch].map((option) => option)
                : options.map((option) => option.name)
            }
            inputValue={inputValue}
            onInputChange={handleInputChange}
            onBlur={formik.handleBlur}
            onChange={(e, value) => selectValue(e, value)}
            label="Search input"
            sx={{ mt: "16px" }}
            renderInput={(params) => (
              <TextField
                error={formik.touched.skill && Boolean(formik.errors.skill)}
                helperText={formik.touched.skill ? formik.errors.skill : ""}
                name="search_skill"
                fullWidth
                placeholder="Search Skill"
                {...params}
                type="search"
                InputProps={{
                  ...params.InputProps,
                  startAdornment: (
                    <InputAdornment position="start">
                      <IconButton>
                        <SearchIcon />
                      </IconButton>
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <div style={{ display: "flex", alignItems: "center" }}>
                        {params.InputProps.endAdornment}
                        {loading && <CircularProgress size={20} />}
                      </div>
                    </InputAdornment>
                  ),
                }}
              />
            )}
          />
        </Box>

        <Box sx={{ pb: 1 }}>
          <Button
            onClick={handleAddSkill}
            // type="submit"
            disabled={
              options?.length === 0 ||
              !formik.values?.skill ||
              !formik.values?.fullSkillObj
            }
            variant="contained"
            color="secondary"
            sx={{
              width: { xs: "100%", sm: "220px" },
              background: (theme) => theme.palette.accent,
              color: "darkGreen",
              textTransform: "capitalize",
              "&:hover": {
                background: "#6AE6A480",
              },
            }}
          >
            <Typography variant="h6">add skill</Typography>
          </Button>
        </Box>
      </Stack>
    </form>
  );
};

export default AddSkillForm;
