import { Box, IconButton, Typography } from "@mui/material";
import StyledDarkWrapper from "../../../components/styled/StyledDarkWrapper";
import LinesEllipsis from "react-lines-ellipsis";
import viewIcon from "../../../assets/view_icon.svg";

const CourseAction = ({
  course,
  handleOpen,
  selectedCourseId,
  handleCourseCardClick,
}) => {
  return (
    <StyledDarkWrapper
      onClick={() => handleCourseCardClick(course)}
      sx={{
        flexDirection: "row",
        gap: "12px",
        alignItems: "center",
        cursor: "pointer",
        borderColor: selectedCourseId === course.id ? "accent" : "lightGrey",
      }}
    >
      <Box
        component={"img"}
        src={course?.image_240x135}
        sx={{
          flex: 1,
          objectFit: "cover",
          objectPosition: "center",
          width: "50px",
          height: "50px",
        }}
      />

      <Typography
        variant="h5"
        sx={{ flex: 4, color: "darkGreenAccent", fontWeight: 600 }}
      >
        <LinesEllipsis
          text={course?.title}
          maxLine="2"
          ellipsis="..."
          trimRight
          basedOn="letters"
        />
      </Typography>

      <IconButton onClick={handleOpen}>
        <Box
          component={"img"}
          src={viewIcon}
          sx={{
            flex: 1,
            width: "24px",
            height: "24px",
          }}
        />
      </IconButton>
    </StyledDarkWrapper>
  );
};

export default CourseAction;
