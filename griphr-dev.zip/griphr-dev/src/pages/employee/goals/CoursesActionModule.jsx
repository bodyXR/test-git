import {
  Box,
  CircularProgress,
  Pagination,
  Stack,
  Typography,
} from "@mui/material";
import CourseAction from "./CourseAction";
import Grid from "@mui/material/Unstable_Grid2"; // Grid version 2
import StyledSmallDarkBtn from "../../../components/styled/StyledSmallDarkBtn";
import DarkBtn from "../../../components/styled/StyledDarkBtn";
import AddIcon from "@mui/icons-material/Add";
import { useCallback, useEffect, useState } from "react";
import CustomModal from "../../../ui/CustomModal";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import menuIcon from "../../../assets/description_menu_icon.svg";
import GoalSkillsWrapper from "./GoalSkillsWrapper";
import LevelFilter from "./LevelFilter";
import { useDispatch, useSelector } from "react-redux";
import {
  setCourseSkillId,
  setSelectedCourses,
} from "../../../redux/slices/Employee/goals/goalsSlice";
import {
  fetchActionsDataByGoalId,
  fetchMatchedCourses,
} from "../../../redux/slices/Employee/goals/goalsActions";
import axiosInstance from "../../../helper/axiosInstance";
import PriceFilter from "./PriceFilter";

const CoursesActionModule = ({ onEdit, handleOpenSnack, goalId }) => {
  const dispatch = useDispatch();
  const { token } = useSelector((state) => state.auth);
  const {
    selectedSkills,
    courseLevel,
    coursePrice,
    courseSkillId,
    coursesCount,
    matchedCourses,
    isLoadingMatchedCourses,
    isSuccessMatchedCourses,
    isErrorMatchedCourses,
    selectedCourses,
  } = useSelector((state) => state.goals);

  // Modal Handlers
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(null);

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleCourseCardClick = (course) => {
    setSelected(course);
  };
  // const [coursesOpenModal, setCoursesOpenModal] = useState(false);
  // const handleCoursesOpenModal = () => setCoursesOpenModal(true);
  // const handleCoursesCloseModal = () => setCoursesOpenModal(false);

  // Pagination
  const [pagination, setPagination] = useState(1);

  const handlePagination = (event, value) => {
    setPagination(value);
  };

  useEffect(() => {
    if (selectedSkills?.length > 0) {
      if (courseSkillId) {
        if (
          selectedSkills?.some(
            (skill) => skill?.id || skill?.skill_id === courseSkillId
          )
        ) {
          dispatch(
            fetchMatchedCourses({
              skill_id: courseSkillId,
              level: courseLevel,
              page: pagination,
              price: coursePrice,
            })
          );
        } else {
          dispatch(setCourseSkillId(selectedSkills[0]?.id));
        }
      }
    } else {
      dispatch(setCourseSkillId(null));
    }
  }, [selectedSkills, courseSkillId, courseLevel, coursePrice, pagination]);

  const addCourse = (course) => {
    const details = {
      title: course?.title,
      description: course?.description,
    };

    const isCourseExist = selectedCourses?.find(
      (item) => item?.reference === course?.id
    );

    if (isCourseExist?.reference) {
      handleOpenSnack(false, "Project already added or exist");
    } else {
      dispatch(
        setSelectedCourses([
          ...selectedCourses,
          {
            type: "courses",
            reference: course?.id,
            details,
          },
        ])
      );
    }
  };

  const addCourseRequest = useCallback(
    async (course) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        const response = await axiosInstance.post(
          `goals/actions`,
          {
            goal_id: goalId,
            actions: [
              {
                type: "courses",
                reference: course.id,
                details: {
                  title: course?.title,
                  description: course?.description,
                },
              },
            ],
          },
          config
        );
        handleOpenSnack(true, response.data.message);
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
      } finally {
        dispatch(fetchActionsDataByGoalId(goalId));
      }
    },
    [token]
  );

  const handleAddCourse = (course) => {
    if (onEdit) {
      addCourseRequest(course);
    } else {
      addCourse(course);
    }

    handleClose();
  };
  return (
    <>
      {/* <CustomModal
        open={coursesOpenModal}
        onClose={handleCoursesCloseModal}
        title={" "}
      >
        <Stack sx={{ gap: 3, pl: { xs: 2, lg: 0 } }}>
          <Grid
            container
            spacing={2}
            sx={{ maxHeight: "500px", overflowY: "auto" }}
          >
            {courses.map((course) => (
              <Grid xs={12} lg={6} key={course.id}>
                <CourseAction
                  course={course}
                  handleOpen={handleOpen}
                  selectedCourseId={selected?.id}
                  handleCourseCardClick={handleCourseCardClick}
                />
              </Grid>
            ))}
          </Grid>

          <DarkBtn endIcon={<AddIcon />}>add course</DarkBtn>
        </Stack>
      </CustomModal> */}

      <CustomModal open={open} onClose={handleClose} title={" "}>
        <Stack sx={{ gap: 3, pl: { xs: 2, lg: 0 } }}>
          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", lg: "row" },
              justifyContent: "space-between",
              alignItems: "center",
              gap: 2,
            }}
          >
            <Box
              sx={{
                display: "flex",
                flexDirection: { xs: "column", lg: "row" },
                alignItems: "center",
                gap: 2,
              }}
            >
              <Box
                className="course-card-title"
                component="img"
                src={selected?.image_240x135}
                alt="course name"
                sx={{
                  borderRadius: "10px",
                  width: { xs: "100%", lg: "240px" },
                  height: "135px",
                  objectFit: "cover",
                  display: "block",
                }}
              />

              <Typography
                variant="h4"
                sx={{
                  fontWeight: 600,
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  color: "darkGreenAccent",
                }}
              >
                {selected?.title}
              </Typography>
            </Box>

            <DarkBtn
              onClick={() => handleAddCourse(selected)}
              endIcon={<AddIcon />}
              sx={{ width: { xs: "100%", lg: "initial" } }}
            >
              add course
            </DarkBtn>
          </Box>

          <Typography variant="h3" sx={{ color: "darkGreenAccent" }}>
            {`${selected?.price}`}
          </Typography>

          <StyledWrapper
            sx={{
              gap: "20px",
              p: { xs: "12px", lg: "20px" },
            }}
          >
            <Typography variant="h3" color="darkGreenAccent">
              Description
            </Typography>

            <Box sx={{ display: "flex", alignItems: "flex-start", gap: 2 }}>
              <img src={menuIcon} alt="Description Menu icon" />

              <Typography variant="body1" color="inactive.main">
                Description:
                <br />
                {selected?.description}
              </Typography>
            </Box>
          </StyledWrapper>
        </Stack>
      </CustomModal>

      <Stack
        sx={{
          mt: 1.5,
          flexDirection: { xs: "column" },
          gap: { xs: 2 },
        }}
      >
        <GoalSkillsWrapper onEdit={onEdit} />

        <Stack
          sx={{
            flexDirection: "row",
            gap: 2,
            alignSelf: { xs: "center", md: "flex-end" },
          }}
        >
          <PriceFilter />
          <LevelFilter />
        </Stack>
      </Stack>
      {isErrorMatchedCourses && (
        <Typography variant="h3" sx={{ alignSelf: "center" }}>
          Error Fetching Courses!
        </Typography>
      )}
      {isLoadingMatchedCourses && (
        <CircularProgress sx={{ alignSelf: "center" }} />
      )}
      {isSuccessMatchedCourses &&
        (matchedCourses.length > 0 ? (
          <Stack className="matchedCourses__wrapper" sx={{ mt: 2, gap: 2 }}>
            <Grid container spacing={2}>
              {matchedCourses?.map((course) => (
                <Grid xs={12} lg={6} key={course.id}>
                  <CourseAction
                    course={course}
                    handleOpen={handleOpen}
                    selectedCourseId={selected?.id}
                    handleCourseCardClick={handleCourseCardClick}
                  />
                </Grid>
              ))}
            </Grid>

            <Stack sx={{ alignItems: "center", mt: 3 }}>
              {coursesCount && (
                <Pagination
                  page={pagination}
                  count={Math.ceil(coursesCount / 8)}
                  shape="rounded"
                  size="large"
                  onChange={handlePagination}
                />
              )}
            </Stack>

            {/* {matchedCourses?.length > 4 && (
            <Button
              onClick={handleCoursesOpenModal}
              sx={{ alignSelf: "flex-start" }}
            >
              <Typography
                variant="body1"
                sx={{
                  textTransform: "capitalize",
                  color: "#66C1FF",
                  textDecoration: "underline",
                }}
              >
                Show more
              </Typography>
            </Button>
          )} */}

            <StyledSmallDarkBtn onClick={() => handleAddCourse(selected)}>
              add course
            </StyledSmallDarkBtn>
          </Stack>
        ) : (
          <Typography
            variant="h4"
            sx={{
              textAlign: "center",
              color: "darkAccent",
              fontWeight: 600,
              textDecoration: "underline",
            }}
          >
            No Courses Founded!
          </Typography>
        ))}
      {!isErrorMatchedCourses &&
        !isLoadingMatchedCourses &&
        !isSuccessMatchedCourses && (
          <Typography
            variant="h4"
            sx={{
              mt: 1.5,
              textAlign: "center",
              color: "darkAccent",
              fontWeight: 600,
              textDecoration: "underline",
            }}
          >
            Select Skill First
          </Typography>
        )}
    </>
  );
};

export default CoursesActionModule;
