import { Stack, Typography } from "@mui/material";
import React, { useState } from "react";
import CoursesActionModule from "./CoursesActionModule";
import ProjectsActionModule from "./ProjectsActionModule";
import ActivitiesActionModule from "./ActivitiesActionModule";
import { useSelector } from "react-redux";

const DevelopActions = ({ formik, onEdit, handleOpenSnack, goalId }) => {
  const [developAction, setDevelopAction] = useState(null);
  const { actions, selectedCourses, selectedProjects, selectedActivities } =
    useSelector((state) => state.goals);

  return (
    <>
      <Stack
        className="develop__actions"
        sx={{
          flexDirection: { xs: "column", lg: "row" },
          justifyContent: { lg: "center" },
          alignItems: "center",
          color: "darkGreen",
        }}
      >
        {["Courses", "Projects", "Activities"].map((item, i) => (
          <Typography
            variant="h4"
            key={item}
            onClick={() =>
              setDevelopAction((prev) => {
                if (prev === item) {
                  return null;
                }
                return item;
              })
            }
            sx={{
              color: "inherit",
              borderBottom: developAction === item ? "2px solid" : "none",
              borderColor: developAction === item ? "accent" : "none",
              padding: "9px 16px",
              fontWeight: 600,
              lineHeight: 1.5,
              cursor: "pointer",
            }}
          >
            {item}
          </Typography>
        ))}
      </Stack>

      {developAction === "Courses" && (
        <CoursesActionModule
          onEdit={onEdit}
          handleOpenSnack={handleOpenSnack}
          goalId={goalId}
        />
      )}

      {developAction === "Projects" && (
        <ProjectsActionModule
          onEdit={onEdit}
          handleOpenSnack={handleOpenSnack}
          goalId={goalId}
        />
      )}

      {developAction === "Activities" && (
        <ActivitiesActionModule
          formik={formik}
          handleOpenSnack={handleOpenSnack}
          onEdit={onEdit}
          goalId={goalId}
        />
      )}

      {!onEdit &&
        [...selectedCourses, ...selectedProjects, ...selectedActivities]
          ?.length === 0 && (
          <Typography
            sx={{
              color: "#d32f2f",
              mx: "14px",
              mt: "3px",
              fontSize: "0.8571428571428571rem",
            }}
          >
            Action is required, Must set at least one action
          </Typography>
        )}

      {onEdit &&
        [
          ...(actions?.selectedCourses || []),
          ...(actions?.projects || []),
          ...(actions?.activities || []),
        ]?.length === 0 && (
          <Typography
            sx={{
              color: "#d32f2f",
              mx: "14px",
              mt: "3px",
              fontSize: "0.8571428571428571rem",
            }}
          >
            Action is required, Must set at least one action
          </Typography>
        )}
    </>
  );
};

export default DevelopActions;
