import React, { useEffect, useState } from "react";
import { Box, Collapse, IconButton, Stack, Typography } from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import DarkBtn from "../../../components/styled/StyledDarkBtn";
import { useNavigate } from "react-router-dom";
import { EMPLOYEE_ADD_GOAL_ROUTE } from "../../../routes/paths";
import StyledDarkWrapper from "../../../components/styled/StyledDarkWrapper";
import ActionDetails from "./ActionDetails";

const DevelopActionsDetails = ({
  data,
  handleOpenSnack,
  isManager = false,
}) => {
  const [progress, setProgress] = useState(null);
  const [isRowOpen1, setIsRowOpen1] = useState(false);
  const [isRowOpen2, setIsRowOpen2] = useState(false);
  const [isRowOpen3, setIsRowOpen3] = useState(false);
  const navigate = useNavigate();

  const progressCalculation = (actions) => {
    const totalPercentage = actions?.reduce((sum, action) => {
      return sum + action.percentage;
    }, 0);
    const numberOfActions = actions.length;

    const progress = totalPercentage / numberOfActions;
    return progress;
  };

  useEffect(() => {
    if (data?.id) {
      const coursesProgress = progressCalculation(data?.actions?.courses);
      const projectsProgress = progressCalculation(data?.actions?.projects);
      const activitiesProgress = progressCalculation(data?.actions?.activities);
      setProgress({ coursesProgress, projectsProgress, activitiesProgress });
    }
  }, [data]);

  return (
    <StyledWrapper
      sx={{
        gap: "20px",
        p: { xs: "12px", lg: "20px" },
      }}
    >
      <Stack>
        <Typography variant="h3" color="darkGreenAccent">
          Develop Actions
        </Typography>

        <Typography variant="body1" color="inactive.main">
          Here you can add concrete actions and sign them off
        </Typography>
      </Stack>

      {data?.actions?.courses?.length > 0 && (
        <Stack>
          <StyledDarkWrapper
            sx={{
              borderBottomLeftRadius: isRowOpen1 ? "0px" : "10px",
              borderBottomRightRadius: isRowOpen1 ? "0px" : "10px",
              borderBottom: isRowOpen1 ? "none" : "2px solid #EEE",
            }}
          >
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Typography variant="h3" color="inactive.main">
                Courses (
                {progress?.coursesProgress
                  ? progress?.coursesProgress.toFixed(2)
                  : 0}
                %)
              </Typography>

              <IconButton
                aria-label="expand row"
                size="small"
                onClick={() => setIsRowOpen1(!isRowOpen1)}
                sx={{ p: 0 }}
              >
                {isRowOpen1 ? (
                  <KeyboardArrowUpIcon />
                ) : (
                  <KeyboardArrowDownIcon />
                )}
              </IconButton>
            </Box>
          </StyledDarkWrapper>

          <Collapse in={isRowOpen1} timeout="auto" unmountOnExit>
            <StyledDarkWrapper
              sx={{
                borderTopLeftRadius: isRowOpen1 ? "0px" : "10px",
                borderTopRightRadius: isRowOpen1 ? "0px" : "10px",
                borderTop: isRowOpen1 ? "none" : "2px solid #EEE",
                gap: 1,
              }}
            >
              {data?.actions?.courses?.length > 0 &&
                data?.actions?.courses?.map((course) => (
                  <ActionDetails
                    key={course.id}
                    goal={data}
                    handleOpenSnack={handleOpenSnack}
                    data={course}
                    type={course.type}
                    isManager={isManager}
                  />
                ))}
            </StyledDarkWrapper>
          </Collapse>
        </Stack>
      )}

      {data?.actions?.projects?.length > 0 && (
        <Stack>
          <StyledDarkWrapper
            sx={{
              borderBottomLeftRadius: isRowOpen2 ? "0px" : "10px",
              borderBottomRightRadius: isRowOpen2 ? "0px" : "10px",
              borderBottom: isRowOpen2 ? "none" : "2px solid #EEE",
            }}
          >
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Typography variant="h3" color="inactive.main">
                Projects (
                {progress?.projectsProgress
                  ? progress?.projectsProgress.toFixed(2)
                  : 0}
                %)
              </Typography>

              <IconButton
                aria-label="expand row"
                size="small"
                onClick={() => setIsRowOpen2(!isRowOpen2)}
                sx={{ p: 0 }}
              >
                {isRowOpen2 ? (
                  <KeyboardArrowUpIcon />
                ) : (
                  <KeyboardArrowDownIcon />
                )}
              </IconButton>
            </Box>
          </StyledDarkWrapper>

          <Collapse in={isRowOpen2} timeout="auto" unmountOnExit>
            <StyledDarkWrapper
              sx={{
                borderTopLeftRadius: isRowOpen2 ? "0px" : "10px",
                borderTopRightRadius: isRowOpen2 ? "0px" : "10px",
                borderTop: isRowOpen2 ? "none" : "2px solid #EEE",
                gap: 1,
              }}
            >
              {data?.actions?.projects?.length > 0 &&
                data?.actions?.projects?.map((project) => (
                  <ActionDetails
                    key={project.id}
                    goal={data}
                    handleOpenSnack={handleOpenSnack}
                    data={project}
                    type={project.type}
                    isManager={isManager}
                  />
                ))}
            </StyledDarkWrapper>
          </Collapse>
        </Stack>
      )}

      {data?.actions?.activities?.length > 0 && (
        <Stack>
          <StyledDarkWrapper
            sx={{
              borderBottomLeftRadius: isRowOpen3 ? "0px" : "10px",
              borderBottomRightRadius: isRowOpen3 ? "0px" : "10px",
              borderBottom: isRowOpen3 ? "none" : "2px solid #EEE",
            }}
          >
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Typography variant="h3" color="inactive.main">
                Activities (
                {progress?.activitiesProgress
                  ? progress?.activitiesProgress.toFixed(2)
                  : 0}
                %)
              </Typography>

              <IconButton
                aria-label="expand row"
                size="small"
                onClick={() => setIsRowOpen3(!isRowOpen3)}
                sx={{ p: 0 }}
              >
                {isRowOpen3 ? (
                  <KeyboardArrowUpIcon />
                ) : (
                  <KeyboardArrowDownIcon />
                )}
              </IconButton>
            </Box>
          </StyledDarkWrapper>

          <Collapse in={isRowOpen3} timeout="auto" unmountOnExit>
            <StyledDarkWrapper
              sx={{
                borderTopLeftRadius: isRowOpen3 ? "0px" : "10px",
                borderTopRightRadius: isRowOpen3 ? "0px" : "10px",
                borderTop: isRowOpen3 ? "none" : "2px solid #EEE",
                gap: 1,
              }}
            >
              {data?.actions?.activities?.length > 0 &&
                data?.actions?.activities?.map((activity) => (
                  <ActionDetails
                    key={activity.id}
                    goal={data}
                    handleOpenSnack={handleOpenSnack}
                    data={activity}
                    type={activity.type}
                    isManager={isManager}
                  />
                ))}
            </StyledDarkWrapper>
          </Collapse>
        </Stack>
      )}

      {data?.status !== "completed" && !isManager && (
        <DarkBtn
          onClick={() =>
            navigate(EMPLOYEE_ADD_GOAL_ROUTE, {
              state: { onEdit: true, data },
            })
          }
          sx={{ alignSelf: { lg: "flex-start" } }}
        >
          Add new action
        </DarkBtn>
      )}
    </StyledWrapper>
  );
};

export default DevelopActionsDetails;
