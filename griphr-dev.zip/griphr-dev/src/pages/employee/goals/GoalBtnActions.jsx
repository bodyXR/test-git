import React, { useCallback, useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Stack,
  Typography,
} from "@mui/material";
import correctIcon from "../../../assets/correct_white.svg";
import correctInactiveIcon from "../../../assets/correct_grey.svg";
import deleteIcon from "../../../assets/delete_green.svg";
import StyledDisabledBtn from "../../../components/styled/StyledDisabledBtn";
import DarkBtn from "../../../components/styled/StyledDarkBtn";
import { useDispatch, useSelector } from "react-redux";
import { fetchGoalsDataById } from "../../../redux/slices/Employee/goals/goalsActions";
import axiosInstance from "../../../helper/axiosInstance";
import StyledOutlinedBtn from "../../../components/styled/StyledOutlinedBtn";
import { useNavigate } from "react-router-dom";
import { EMPLOYEE_GOALS_ROUTE } from "../../../routes/paths";

const GoalBtnActions = ({ data, progress, handleOpenSnack }) => {
  const [openDialog, setOpenDialog] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };
  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const startGoal = useCallback(async (id) => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
    };

    try {
      const response = await axiosInstance.put(
        "goals/",
        { id, status: "in progress" },
        config
      );
      console.log(response.data.payload);
      handleOpenSnack(true, response.data.message);
    } catch (error) {
      console.log(error?.response.data);
      handleOpenSnack(false, error?.response.data.message);
    } finally {
      dispatch(fetchGoalsDataById(id));
    }
  }, []);

  const completeGoal = useCallback(async (id) => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
    };

    try {
      const response = await axiosInstance.put(
        "goals/",
        { id, status: "completed" },
        config
      );
      console.log(response.data.payload);
      handleOpenSnack(true, response.data.message);
    } catch (error) {
      console.log(error?.response.data);
      handleOpenSnack(false, error?.response.data.message);
    } finally {
      dispatch(fetchGoalsDataById(id));
    }
  }, []);

  const removeGoal = useCallback(async (id) => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        id,
      },
    };

    try {
      const response = await axiosInstance.delete("goals/", config);
      console.log(response.data.payload);
      handleOpenSnack(true, response.data.message);
      navigate(EMPLOYEE_GOALS_ROUTE);
    } catch (error) {
      console.log(error?.response.data);
      handleOpenSnack(false, error?.response.data.message);
    }
  }, []);

  const handleRemoveGoal = (id) => {
    removeGoal(id);
    handleCloseDialog();
  };

  return (
    <Stack gap={{ xs: 2 }}>
      {data?.status === "not started" && (
        <DarkBtn onClick={() => startGoal(data.id)}>start goal</DarkBtn>
      )}

      {data?.status === "in progress" && (
        <>
          {progress < 100 ? (
            <StyledDisabledBtn
              disabled={true}
              endIcon={
                <Box
                  component={"img"}
                  src={correctInactiveIcon}
                  sx={{ width: "24px", height: "24px", color: "accent" }}
                />
              }
              sx={{
                width: { xs: "100%", lg: "192px" },
                height: "41px",
                textTransform: "none",
              }}
            >
              Mark as Completed
            </StyledDisabledBtn>
          ) : (
            <DarkBtn
              onClick={() => completeGoal(data.id)}
              endIcon={
                <Box
                  component={"img"}
                  src={correctIcon}
                  sx={{ width: "24px", height: "24px", color: "accent" }}
                />
              }
              sx={{
                width: { xs: "100%", lg: "192px" },
                height: "41px",
                textTransform: "none",
              }}
            >
              Mark as Completed
            </DarkBtn>
          )}

          <StyledOutlinedBtn
            onClick={handleOpenDialog}
            endIcon={
              <Box
                component={"img"}
                src={deleteIcon}
                sx={{ width: "24px", height: "24px" }}
              />
            }
            sx={{
              width: { xs: "100%", lg: "192px" },
              height: "41px",
              backgroundColor: "softAccent",
              borderColor: "skillGreen",
              textTransform: "none",
            }}
          >
            <Typography variant="h6" color="skillGreen">
              Remove Goal
            </Typography>
          </StyledOutlinedBtn>
        </>
      )}

      <Dialog
        open={openDialog}
        onClose={handleCloseDialog}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          {`Confirm Goal Remove`}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {`Are you sure you want to remove this goal?`}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} autoFocus>
            cancel
          </Button>
          <Button onClick={() => handleRemoveGoal(data.id)} color="error">
            Remove
          </Button>
        </DialogActions>
      </Dialog>

      {data?.status === "completed" && (
        <Box
          sx={{
            width: "115px",
            height: "35px",
            backgroundColor: "rgba(192, 192, 192, 0.2)",
            borderRadius: "40px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Typography
            variant="body1"
            sx={{
              textTransform: "capitalize",
              color: "inactive.main",
            }}
          >
            {data?.status}
          </Typography>
        </Box>
      )}
    </Stack>
  );
};

export default GoalBtnActions;
