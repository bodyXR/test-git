import React, { useCallback, useState } from "react";
import StyledDarkWrapper from "../../../components/styled/StyledDarkWrapper";
import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  ListItemText,
  Menu,
  MenuItem,
  Snackbar,
  Stack,
  Typography,
} from "@mui/material";
import LinesEllipsis from "react-lines-ellipsis";
import goalIcon from "../../../assets/goals_active.svg";
import circleDotsIcon from "../../../assets/moreHoriz__icon.svg";
import startIcon from "../../../assets/start_inactive.svg";
import correctIcon from "../../../assets/correct_inactive.svg";
import delete_inactive from "../../../assets/delete_inactive.svg";
import editIcon from "../../../assets/edit_inactive.svg";
import greenCorrectIcon from "../../../assets/green_correct_icon.svg";
import axiosInstance from "../../../helper/axiosInstance";
import { fetchGoalsData } from "../../../redux/slices/Employee/goals/goalsActions";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import {
  EMPLOYEE_ADD_GOAL_ROUTE,
  EMPLOYEE_GOAL_DETAILS_ROUTE,
} from "../../../routes/paths";

const GoalCard = ({ data, isCompleted = false }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const open = Boolean(anchorEl);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };
  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const startGoal = useCallback(async () => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
    };

    try {
      const response = await axiosInstance.put(
        "goals/",
        { id: data.id, status: "in progress" },
        config
      );
      console.log(response.data.payload);
      handleOpenSnack(true, response.data.message);
      navigate(`${EMPLOYEE_GOAL_DETAILS_ROUTE}/${data.id}`);
    } catch (error) {
      console.log(error?.response.data);
      handleOpenSnack(false, error?.response.data.message);
    } finally {
      dispatch(fetchGoalsData());
    }
  }, []);

  const completeGoal = useCallback(async () => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
    };

    try {
      const response = await axiosInstance.put(
        "goals/",
        { id: data.id, status: "completed" },
        config
      );
      console.log(response.data.payload);
      handleOpenSnack(true, response.data.message);
    } catch (error) {
      console.log(error?.response.data);
      handleOpenSnack(false, error?.response.data.message);
    } finally {
      dispatch(fetchGoalsData());
    }
  }, []);

  const removeGoal = useCallback(async () => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        id: data.id,
      },
    };

    try {
      const response = await axiosInstance.delete("goals/", config);
      console.log(response.data.payload);
      handleOpenSnack(true, response.data.message);
    } catch (error) {
      console.log(error?.response.data);
      handleOpenSnack(false, error?.response.data.message);
    } finally {
      dispatch(fetchGoalsData());
    }
  }, []);

  const handleStartGoal = () => {
    startGoal();
    setAnchorEl(null);
  };

  const handleCompleteGoal = () => {
    completeGoal();
    setAnchorEl(null);
  };

  const handleRemoveGoal = () => {
    removeGoal();
    setAnchorEl(null);
  };

  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>

      <StyledDarkWrapper
        sx={{
          flexDirection: "row",
          gap: "12px",
          alignItems: "center",
          flex: 1,
        }}
      >
        <Box
          component={"img"}
          src={goalIcon}
          sx={{ width: "24px", height: "24px" }}
        />

        <Stack>
          <Link to={`${EMPLOYEE_GOAL_DETAILS_ROUTE}/${data.id}`}>
            <Typography
              variant="h5"
              title={data.name}
              sx={{
                fontWeight: 600,
                textTransform: "capitalize",
                color: "darkGreenAccent",
              }}
            >
              <LinesEllipsis
                text={data.name}
                maxLine="1"
                ellipsis="..."
                trimRight
                basedOn="words"
              />
            </Typography>
          </Link>

          <Typography
            variant="body2"
            sx={{
              textTransform: "capitalize",
              color: "inactive.main",
            }}
          >
            {isCompleted ? "current" : "new"} role{" "}
            {isCompleted && (
              <>
                <span
                  style={{
                    fontSize: "20px",
                    verticalAlign: "super",
                    color: "#6AE6A4",
                  }}
                >
                  .
                </span>{" "}
                courses
              </>
            )}{" "}
            <span
              style={{
                fontSize: "20px",
                verticalAlign: "super",
                color: "#6AE6A4",
              }}
            >
              .
            </span>{" "}
            due date: {data.due_date}
          </Typography>
        </Stack>

        {isCompleted ? (
          <Box
            component={"img"}
            src={greenCorrectIcon}
            sx={{ width: "26px", height: "26px", ml: "auto" }}
          />
        ) : (
          <IconButton
            onClick={handleClick}
            sx={{ width: "24px", height: "24px", ml: "auto" }}
          >
            <Box component={"img"} src={circleDotsIcon} />
          </IconButton>
        )}

        <Menu anchorEl={anchorEl} open={open} onClose={handleClose}>
          {data?.status === "not started" && (
            <MenuItem
              onClick={handleStartGoal}
              sx={{
                justifyContent: "flex-end",
                gap: "16px",
                color: "inactive.main",
              }}
            >
              <ListItemText sx={{ opacity: "0.7", textAlign: "right" }}>
                Start Goal
              </ListItemText>

              <Box component={"img"} src={startIcon} />
            </MenuItem>
          )}

          {data?.status === "in progress" && (
            <MenuItem
              onClick={handleCompleteGoal}
              sx={{
                justifyContent: "flex-end",
                gap: "16px",
                color: "inactive.main",
              }}
            >
              <ListItemText sx={{ opacity: "0.7", textAlign: "right" }}>
                Mark as Completed
              </ListItemText>

              <Box component={"img"} src={correctIcon} />
            </MenuItem>
          )}

          <MenuItem
            onClick={handleOpenDialog}
            sx={{
              justifyContent: "flex-end",
              gap: "16px",
              color: "inactive.main",
            }}
          >
            <ListItemText sx={{ opacity: "0.7", textAlign: "right" }}>
              Remove Goal
            </ListItemText>

            <Box component={"img"} src={delete_inactive} />
          </MenuItem>

          <MenuItem
            onClick={() =>
              navigate(EMPLOYEE_ADD_GOAL_ROUTE, {
                state: { onEdit: true, data },
              })
            }
            sx={{
              justifyContent: "flex-end",
              gap: "16px",
              color: "inactive.main",
            }}
          >
            <ListItemText sx={{ opacity: "0.7", textAlign: "right" }}>
              Edit Goal
            </ListItemText>

            <Box component={"img"} src={editIcon} />
          </MenuItem>
        </Menu>

        <Dialog
          open={openDialog}
          onClose={handleCloseDialog}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">
            {`Confirm Goal Remove`}
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              {`Are you sure you want to remove this goal?`}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog} autoFocus>
              cancel
            </Button>
            <Button onClick={handleRemoveGoal} color="error">
              Remove
            </Button>
          </DialogActions>
        </Dialog>
      </StyledDarkWrapper>
    </>
  );
};

export default GoalCard;
