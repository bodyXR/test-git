import React, { useEffect, useState } from "react";
import {
  Alert,
  Avatar,
  Box,
  Grid,
  IconButton,
  Snackbar,
  Stack,
  Typography,
} from "@mui/material";
import infoIcon from "../../../assets/info_icon.svg";
import dateIcon from "../../../assets/date_icon.svg";
import menuIcon from "../../../assets/description_menu_icon.svg";
import leftArrow from "../../../assets/arrow_left_icon.svg";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { fetchGoalsDataById } from "../../../redux/slices/Employee/goals/goalsActions";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import DevelopActionsDetails from "./DevelopActionsDetails";
import DescriptionTooltip from "../../../ui/DescriptionTooltip";
import GoalStatusDetails from "./GoalStatusDetails";
import GoalBtnActions from "./GoalBtnActions";
import { MANAGER_GOALS_ROUTE } from "../../../routes/paths";
import Feedback from "../../../components/analytics_section/components/Feedback";

const boxStyles = {
  display: "flex",
  alignItems: "center",
  gap: 2,
};

const GoalDetails = () => {
  const [progress, setProgress] = useState(0);
  const { id } = useParams();
  const { goal } = useSelector((state) => state.goals);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const data = location.state?.data || null;

  const goBackToPreviousPage = () => {
    navigate(MANAGER_GOALS_ROUTE);
  };

  const progressCalculation = (actions) => {
    const totalPercentage = actions?.reduce((sum, action) => {
      return sum + action.percentage;
    }, 0);
    const numberOfActions = actions.length;

    const progress = totalPercentage / numberOfActions;
    return progress;
  };

  useEffect(() => {
    dispatch(fetchGoalsDataById(id));
  }, [dispatch]);

  useEffect(() => {
    if (goal?.id) {
      const progress = progressCalculation([
        ...goal?.actions?.projects,
        ...goal?.actions?.activities,
        ...goal?.actions?.courses,
      ]);
      setProgress(progress);
    }
  }, [goal]);

  const [openSnack, setOpenSnack] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState(null);

  const handleOpenSnack = (status, message) => {
    setRequestSuccess({ status, message });
    setOpenSnack(true);
  };

  const handleCloseSnack = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnack(false);
  };

  return (
    <>
      <Snackbar
        open={openSnack}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        autoHideDuration={3000}
        onClose={handleCloseSnack}
      >
        <Alert
          onClose={handleCloseSnack}
          severity={requestSuccess?.status ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {requestSuccess?.message}
        </Alert>
      </Snackbar>

      <Stack gap="20px">
        {data && (
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <IconButton onClick={goBackToPreviousPage}>
              <img src={leftArrow} alt="Return back icon" />
            </IconButton>

            <Avatar
              src={data?.userImg}
              alt={data?.userName}
              sx={{ width: "30px", height: "30px" }}
            />

            <Typography
              variant="h2"
              color="darkGreen"
              textTransform="capitalize"
            >
              {data?.userName}
            </Typography>
          </Box>
        )}

        <Stack
          sx={{
            flexDirection: { lg: "row" },
            justifyContent: { lg: "space-between" },
            gap: "12px",
          }}
        >
          <GoalStatusDetails
            data={goal}
            progress={progress}
            isManager={data ? true : false}
          />

          {!data && (
            <GoalBtnActions
              data={goal}
              progress={progress}
              handleOpenSnack={handleOpenSnack}
            />
          )}
        </Stack>

        {goal?.skills?.length >= 1 && (
          <Stack
            sx={{
              flexDirection: "row",
              alignItems: "center",
              gap: "12px",
              flexWrap: "wrap",
            }}
          >
            {goal?.skills?.map((skill) => (
              <Box
                key={skill.skill_id}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                  backgroundColor: "softGreen",
                  borderRadius: "100px",
                  py: "4px",
                  px: "12px",
                }}
              >
                <Typography
                  variant="h6"
                  textTransform="none"
                  color="#FFFFFF"
                  fontWeight="500"
                >
                  {skill?.title}
                </Typography>

                <DescriptionTooltip
                  title={skill?.description}
                  placement="bottom-start"
                >
                  <Box
                    component={"img"}
                    src={infoIcon}
                    sx={{ width: "16px", height: "16px", color: "white" }}
                  />
                </DescriptionTooltip>
              </Box>
            ))}
          </Stack>
        )}

        <StyledWrapper
          sx={{
            gap: "20px",
            p: { xs: "12px", lg: "20px" },
          }}
        >
          <Typography variant="h3" color="darkGreenAccent">
            Details
          </Typography>

          <Grid container spacing="20px" columns={12}>
            <Grid item xs={12} md={6}>
              <Box sx={boxStyles}>
                <img
                  style={{ width: "24px", height: "24px" }}
                  src={dateIcon}
                  alt="Date icon"
                />

                <Typography
                  variant="body1"
                  color="inactive.main"
                  textTransform="capitalize"
                >
                  Start Date: {goal?.start_date}
                </Typography>
              </Box>
            </Grid>

            <Grid item xs={12} md={6}>
              <Box sx={boxStyles}>
                <img
                  style={{ width: "24px", height: "24px" }}
                  src={dateIcon}
                  alt="Date icon"
                />

                <Typography
                  variant="body1"
                  color="inactive.main"
                  textTransform="capitalize"
                >
                  Due Date: {goal?.due_date}
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </StyledWrapper>

        <StyledWrapper
          sx={{
            gap: "20px",
            p: { xs: "12px", lg: "20px" },
          }}
        >
          <Typography variant="h3" color="darkGreenAccent">
            Description
          </Typography>

          <Box sx={{ display: "flex", alignItems: "flex-start", gap: 2 }}>
            <img src={menuIcon} alt="Description Menu icon" />

            <Typography variant="body1" color="inactive.main">
              Description:
              <br />
              {goal?.description}
            </Typography>
          </Box>
        </StyledWrapper>

        <DevelopActionsDetails
          data={goal}
          handleOpenSnack={handleOpenSnack}
          isManager={data ? true : false}
        />

        <Feedback goalId={goal?.id} />
      </Stack>
    </>
  );
};

export default GoalDetails;
