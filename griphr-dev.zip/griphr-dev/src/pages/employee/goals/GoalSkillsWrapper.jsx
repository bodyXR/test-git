import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { setCourseSkillId } from "../../../redux/slices/Employee/goals/goalsSlice";
import CustomChip from "../learningMatching/CustomChip";
import { Stack } from "@mui/material";

const GoalSkillsWrapper = ({ onEdit }) => {
  const dispatch = useDispatch();
  const { courseSkillId, selectedSkills } = useSelector((state) => state.goals);
  return (
    <Stack
      sx={{
        justifyContent: "center",
        alignItems: "center",
        alignContent: "center",
        flexDirection: "row",
        flexWrap: "wrap",
        gap: "10px",
      }}
    >
      {selectedSkills.map((tag, index) => (
        <CustomChip
          onClick={() => {
            dispatch(setCourseSkillId(tag?.id || tag?.skill_id));
          }}
          key={index}
          id={tag?.id || tag?.skill_id}
          label={tag?.name || tag?.title}
          selectedskillid={courseSkillId}
        />
      ))}
    </Stack>
  );
};

export default GoalSkillsWrapper;
