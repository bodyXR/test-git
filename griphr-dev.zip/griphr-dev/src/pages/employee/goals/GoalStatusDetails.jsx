import React from "react";
import { Box, IconButton, Stack, Typography } from "@mui/material";
import editIcon from "../../../assets/edit_inactive.svg";
import { useNavigate } from "react-router-dom";
import { EMPLOYEE_ADD_GOAL_ROUTE } from "../../../routes/paths";

const GoalStatusDetails = ({ data, progress, isManager = false }) => {
  const navigate = useNavigate();

  return (
    <Stack gap={1}>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
        <Typography variant="h2" color="darkGreen" textTransform="capitalize">
          {data?.name}
        </Typography>

        {data?.status !== "completed" && !isManager && (
          <IconButton
            onClick={() =>
              navigate(EMPLOYEE_ADD_GOAL_ROUTE, {
                state: { onEdit: true, data },
              })
            }
          >
            <Box component={"img"} src={editIcon} />
          </IconButton>
        )}
      </Box>

      {data?.status === "not started" && (
        <Box
          sx={{
            width: "115px",
            height: "35px",
            backgroundColor: "rgba(192, 192, 192, 0.2)",
            borderRadius: "40px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Typography
            variant="body1"
            sx={{ textTransform: "capitalize", color: "inactive.main" }}
          >
            {data?.status}
          </Typography>
        </Box>
      )}

      {data?.status === "in progress" && (
        <Stack gap="4px">
          <Box
            sx={{
              width: { xs: "100%", lg: "395px" },
              height: "8px",
              border: "transparent",
              borderRadius: "10px",
              backgroundColor: "softAccent",
              position: "relative",
            }}
          >
            <Box
              sx={{
                backgroundColor: "accent",
                position: "absolute",
                left: 0,
                top: 0,
                height: "100%",
                width: `${progress}%`,
                border: "transparent",
                borderRadius: "10px",
              }}
            />
          </Box>

          <Typography variant="h6" color="inactive.main">
            {progress.toFixed(2)}% progress
          </Typography>
        </Stack>
      )}
    </Stack>
  );
};

export default GoalStatusDetails;
