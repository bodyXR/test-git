import {
  Box,
  CircularProgress,
  IconButton,
  Stack,
  Typography,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import DarkBtn from "../../../components/styled/StyledDarkBtn";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import addFileIcon from "../../../assets/plus_paper.svg";
import finishedGoalsIcon from "../../../assets/finished_goals.svg";
import { useLocation, useNavigate, useOutletContext } from "react-router-dom";
import { EMPLOYEE_ADD_GOAL_ROUTE } from "../../../routes/paths";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchGoalsData } from "../../../redux/slices/Employee/goals/goalsActions";
import Grid from "@mui/material/Unstable_Grid2";
import GoalCard from "./GoalCard";
import { resetGoalsSlice } from "../../../redux/slices/Employee/goals/goalsSlice";

const GoalsPreview = () => {
  const location = useLocation();
  const [title, setTitle] = useOutletContext();
  const navigate = useNavigate();
  const { data: goals, loading } = useSelector((state) => state.goals);
  const dispatch = useDispatch();
  const currentGoals = goals?.filter((goal) => goal.status !== "completed");
  const completedGoals = goals?.filter((goal) => goal.status === "completed");

  useEffect(() => {
    setTitle(location.pathname.split("/").at(-1));
  }, [setTitle, location]);

  useEffect(() => {
    dispatch(resetGoalsSlice());
    dispatch(fetchGoalsData());
  }, [dispatch]);

  return (
    <Stack sx={{ gap: 3 }}>
      <Stack
        sx={{
          flexDirection: {
            xs: "column",
            lg: "row",
          },
          justifyContent: { lg: "space-between" },
          gap: 2,
        }}
      >
        <Stack sx={{ flexDirection: { xs: "column", lg: "row" } }}>
          <Typography
            sx={{
              px: 2,
              py: 1,
              borderBottom: `3px solid`,
              borderColor: "accent",
              alignSelf: "center",
              fontWeight: 600,
            }}
            variant="h4"
          >
            Development Goals
          </Typography>
        </Stack>

        <DarkBtn
          onClick={() => navigate(EMPLOYEE_ADD_GOAL_ROUTE)}
          endIcon={<AddIcon />}
        >
          add new goal
        </DarkBtn>
      </Stack>

      <StyledWrapper sx={{ gap: 2 }}>
        <Typography sx={{ fontWeight: 600 }} variant="h4">
          My Goals
        </Typography>

        {loading && <CircularProgress size={20} />}
        {!loading && (
          <>
            {currentGoals?.length > 0 ? (
              <Grid container spacing={2}>
                {currentGoals.map((goal) => (
                  <Grid xs={12} md={6} lg={4} key={goal.id}>
                    <GoalCard data={goal} />
                  </Grid>
                ))}
              </Grid>
            ) : (
              <>
                <Box
                  component={"img"}
                  src={addFileIcon}
                  sx={{ alignSelf: "center", width: "36px", height: "44.5px" }}
                />

                <Typography
                  variant="body1"
                  sx={{ textAlign: "center", color: "inactive.main" }}
                >
                  Nothing here yet!
                  <br />
                  Add a new goal for your career development
                </Typography>

                <IconButton
                  onClick={() => navigate(EMPLOYEE_ADD_GOAL_ROUTE)}
                  sx={{
                    alignSelf: "center",
                    backgroundColor: "accent",
                    width: "32px",
                    height: "32px",
                    "&:hover": {
                      backgroundColor: "darkAccent",
                    },
                    boxShadow: "0px 2.909px 7.273px 0px rgba(0, 0, 0, 0.10)",
                  }}
                >
                  <AddIcon
                    sx={{ width: "17.5px", height: "17.5px", color: "#fff" }}
                  />
                </IconButton>
              </>
            )}
          </>
        )}
      </StyledWrapper>

      <StyledWrapper sx={{ gap: 2 }}>
        <Typography sx={{ fontWeight: 600 }} variant="h4">
          Completed Goals{" "}
        </Typography>

        {loading && <CircularProgress size={20} />}
        {!loading && (
          <>
            {completedGoals?.length > 0 ? (
              <Grid container spacing={2}>
                {completedGoals.map((goal) => (
                  <Grid xs={12} md={6} lg={4} key={goal.id}>
                    <GoalCard data={goal} isCompleted={true} />
                  </Grid>
                ))}
              </Grid>
            ) : (
              <>
                <Box
                  component={"img"}
                  src={finishedGoalsIcon}
                  sx={{ alignSelf: "center", width: "36px", height: "44.5px" }}
                />

                <Typography
                  variant="body1"
                  sx={{ textAlign: "center", color: "inactive.main" }}
                >
                  Nothing here yet!
                  <br />
                  Here you can find your completed goals{" "}
                </Typography>
              </>
            )}
          </>
        )}
      </StyledWrapper>

      {/* <StyledWrapper sx={{ gap: 2 }}>
        <Typography sx={{ fontWeight: 600 }} variant="h4">
          Suggested goals
        </Typography>

        <Stack
          sx={{
            flexDirection: {
              xs: "column",
              lg: "row",
            },
            gap: 2,
          }}
        >
          {[
            "Ultimate Web Designer & Web Developer Course",
            "Complete Web Designing Course | Web-Development BootCamp",
          ].map((card) => (
            <SuggestedGoalCard key={card} title={card} />
          ))}
        </Stack>
      </StyledWrapper> */}
    </Stack>
    // <div>goals preview</div>
  );
};

export default GoalsPreview;
