import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  FormGroup,
  Menu,
  MenuItem,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import filter from "../../../assets/filter.svg";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setCourseLevel } from "../../../redux/slices/Employee/goals/goalsSlice";

const LevelFilter = () => {
  const theme = useTheme();
  const mdMatch = useMediaQuery(theme.breakpoints.up("md"));
  const lgMatch = useMediaQuery(theme.breakpoints.up("lg"));
  const [search, setSearch] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  const { courseLevel } = useSelector((state) => state.goals);
  const dispatch = useDispatch();

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLevelChange = (event) => {
    dispatch(setCourseLevel(event.target.name));
    handleMenuClose();
  };

  return (
    <Box sx={{ alignSelf: { xs: "flex-end" } }}>
      <Button
        onClick={handleMenuOpen}
        sx={{
          alignSelf: "center",
          textTransform: "none",
          border: "2px solid #e9e9e9 ",
          borderRadius: "4px",
          color: "primary.main",
          fontWeight: "400",
          px: 3,
          "&: hover": {
            border: "2px solid #e9e9e9 ",
          },
        }}
        disableElevation
        disableRipple
        startIcon={<img src={filter} alt="Filter icon" />}
        variant="outlined"
        aria-controls="filter-menu"
        aria-haspopup="true"
      >
        {courseLevel}
      </Button>

      <Menu
        id="filter-menu"
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        PaperProps={{
          style: {
            width: "210px",
          },
        }}
      >
        <FormGroup>
          <MenuItem sx={{ fontSize: "16px", color: "#788894" }}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={courseLevel === "Beginner"}
                  onChange={handleLevelChange}
                  name="Beginner"
                />
              }
              label="Beginner"
            />
          </MenuItem>
          <MenuItem sx={{ fontSize: "16px", color: "#788894" }}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={courseLevel === "Intermediate"}
                  onChange={handleLevelChange}
                  name="Intermediate"
                />
              }
              label="Intermediate"
            />
          </MenuItem>
          <MenuItem sx={{ fontSize: "16px", color: "#788894" }}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={courseLevel === "Advanced"}
                  onChange={handleLevelChange}
                  name="Advanced"
                />
              }
              label="Advanced"
            />
          </MenuItem>
        </FormGroup>
      </Menu>
    </Box>
  );
};

export default LevelFilter;
