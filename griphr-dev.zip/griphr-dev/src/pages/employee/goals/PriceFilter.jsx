import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  FormGroup,
  Menu,
  MenuItem,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import filter from "../../../assets/filter.svg";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setCoursePrice } from "../../../redux/slices/Employee/goals/goalsSlice";

const PriceFilter = () => {
  const theme = useTheme();
  const mdMatch = useMediaQuery(theme.breakpoints.up("md"));
  const lgMatch = useMediaQuery(theme.breakpoints.up("lg"));
  const [search, setSearch] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  const { coursePrice } = useSelector((state) => state.goals);
  const dispatch = useDispatch();

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLevelChange = (event) => {
    dispatch(setCoursePrice(event.target.name));
    handleMenuClose();
  };

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 3 }}>
      <Button
        onClick={handleMenuOpen}
        sx={{
          alignSelf: "center",
          textTransform: "none",
          border: "2px solid #e9e9e9 ",
          borderRadius: "4px",
          color: "primary.main",
          fontWeight: "400",
          px: 3,
          "&: hover": {
            border: "2px solid #e9e9e9 ",
          },
        }}
        disableElevation
        disableRipple
        startIcon={<img src={filter} alt="Filter icon" />}
        variant="outlined"
        aria-controls="filter-menu"
        aria-haspopup="true"
      >
        {coursePrice}
      </Button>

      <Menu
        id="filter-menu"
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        PaperProps={{
          style: {
            width: "210px",
          },
        }}
      >
        <FormGroup>
          <MenuItem sx={{ fontSize: "16px", color: "#788894" }}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={coursePrice === "free"}
                  onChange={handleLevelChange}
                  name="free"
                />
              }
              label="free"
            />
          </MenuItem>
          <MenuItem sx={{ fontSize: "16px", color: "#788894" }}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={coursePrice === "paid"}
                  onChange={handleLevelChange}
                  name="paid"
                />
              }
              label="paid"
            />
          </MenuItem>
        </FormGroup>
      </Menu>
    </Box>
  );
};

export default PriceFilter;
