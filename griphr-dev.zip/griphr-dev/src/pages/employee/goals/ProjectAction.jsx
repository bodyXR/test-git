import React from "react";
import StyledDarkWrapper from "../../../components/styled/StyledDarkWrapper";
import { Box, IconButton, Stack, Typography } from "@mui/material";
import viewIcon from "../../../assets/view_icon.svg";

const ProjectAction = ({
  project,
  handleOpen,
  selectedProjectId,
  handleProjectCardClick,
}) => {
  return (
    <StyledDarkWrapper
      onClick={() => handleProjectCardClick(project)}
      sx={{
        flexDirection: "row",
        justifyContent: "space-between",
        gap: "12px",
        alignItems: "center",
        cursor: "pointer",
        borderColor: selectedProjectId === project.id ? "accent" : "lightGrey",
      }}
    >
      <Stack>
        <Typography
          title={project?.name}
          variant="h5"
          sx={{ flex: 4, color: "darkGreenAccent", fontWeight: 600 }}
        >
          {project?.name}
        </Typography>

        <Typography variant="h5" sx={{ flex: 4, color: "inactive.main" }}>
          Start Date: {project?.start_date}
        </Typography>
      </Stack>

      <IconButton onClick={handleOpen}>
        <Box
          component={"img"}
          src={viewIcon}
          sx={{
            flex: 1,
            width: "24px",
            height: "24px",
          }}
        />
      </IconButton>
    </StyledDarkWrapper>
  );
};

export default ProjectAction;
