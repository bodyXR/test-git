import React, { useCallback, useEffect, useState } from "react";
import ProjectAction from "./ProjectAction";
import { Box, CircularProgress, Stack, Typography } from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2"; // Grid version 2
import { useDispatch, useSelector } from "react-redux";
import { fetchProjects } from "../../../redux/slices/internalMobility/addProjectFormActions";
import StyledSmallDarkBtn from "../../../components/styled/StyledSmallDarkBtn";
import axiosInstance from "../../../helper/axiosInstance";
import {
  fetchActionsDataByGoalId,
  fetchProjectsMatches,
} from "../../../redux/slices/Employee/goals/goalsActions";
import CustomModal from "../../../ui/CustomModal";
import { Link } from "react-router-dom";
import { EMPLOYEE_PROJECT_DETAILS_ROUTE } from "../../../routes/paths";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import DarkBtn from "../../../components/styled/StyledDarkBtn";
import AddIcon from "@mui/icons-material/Add";
import mailIcon from "../../../assets/mail_icon.svg";
import dateIcon from "../../../assets/date_icon.svg";
import menuIcon from "../../../assets/description_menu_icon.svg";
import { setSelectedProjects } from "../../../redux/slices/Employee/goals/goalsSlice";

const boxStyles = {
  display: "flex",
  alignItems: "center",
  gap: 2,
};

const ProjectsActionModule = ({ onEdit, handleOpenSnack, goalId }) => {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(null);
  const { token } = useSelector((state) => state.auth);
  const {
    projects,
    isLoadingProjects,
    isSuccessProjects,
    isErrorProjects,
    selectedSkills,
    selectedProjects,
  } = useSelector((state) => state.goals);
  const dispatch = useDispatch();
  const skillsId = selectedSkills.map((skill) => skill?.id || skill?.skill_id);

  useEffect(() => {
    // if (skillsId.length < 1 || skillsId === undefined) return;
    dispatch(fetchProjectsMatches(skillsId));
  }, [selectedSkills]);

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleProjectCardClick = (project) => {
    setSelected(project);
  };

  const addProject = (project) => {
    // Create a function to filter out keys with empty string or null values

    const details = {
      title: project.name,
      description: project.description,
    };

    const isProjectExist = selectedProjects?.find(
      (item) => item.reference === project.id
    );

    if (isProjectExist?.reference) {
      handleOpenSnack(false, "Project already added or exist");
    } else {
      dispatch(
        setSelectedProjects([
          ...selectedProjects,
          {
            type: "projects",
            reference: project?.id,
            details,
          },
        ])
      );
    }
  };

  const addProjectRequest = useCallback(
    async (project) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        const response = await axiosInstance.post(
          `goals/actions`,
          {
            goal_id: goalId,
            actions: [
              {
                type: "projects",
                reference: project.id,
                details: {},
              },
            ],
          },
          config
        );
        handleOpenSnack(true, response.data.message);
      } catch (error) {
        handleOpenSnack(false, error?.response.data.message);
      } finally {
        dispatch(fetchActionsDataByGoalId(goalId));
      }
    },
    [token]
  );

  const handleAddProject = (project) => {
    if (onEdit) {
      addProjectRequest(project);
    } else {
      addProject(project);
    }

    handleClose();
  };

  return (
    <>
      <CustomModal open={open} onClose={handleClose} title={selected?.name}>
        <Stack sx={{ gap: 3, pl: { xs: 2, lg: 0 } }}>
          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", lg: "row" },
              justifyContent: "space-between",
              alignItems: { lg: "center" },
              gap: 2,
            }}
          >
            <Link
              to={`${EMPLOYEE_PROJECT_DETAILS_ROUTE}/${selected?.id}`}
              target="_blank"
            >
              <Typography
                variant="h5"
                sx={{
                  fontWeight: 600,
                  textTransform: "capitalize",
                  color: "darkGreenAccent",
                  textDecoration: "underline",
                }}
              >
                project details
              </Typography>
            </Link>

            <DarkBtn
              onClick={() => handleAddProject(selected)}
              endIcon={<AddIcon />}
              sx={{ alignSelf: { lg: "flex-end" } }}
            >
              add project
            </DarkBtn>
          </Box>

          <StyledWrapper
            sx={{
              gap: "20px",
              p: { xs: "12px", lg: "20px" },
            }}
          >
            <Typography variant="h3" color="darkGreenAccent">
              Details
            </Typography>

            <Grid container spacing="20px" columns={12}>
              <Grid item xs={12} md={12}>
                <Box sx={boxStyles}>
                  <img
                    style={{ width: "24px", height: "24px" }}
                    src={mailIcon}
                    alt="Mail icon"
                  />

                  <Typography
                    variant="body1"
                    color="inactive.main"
                    textTransform="capitalize"
                  >
                    {selected?.department}
                  </Typography>
                </Box>
              </Grid>

              <Grid item xs={12} md={6}>
                <Box sx={boxStyles}>
                  <img
                    style={{ width: "24px", height: "24px" }}
                    src={dateIcon}
                    alt="Date icon"
                  />

                  <Typography
                    variant="body1"
                    color="inactive.main"
                    textTransform="capitalize"
                  >
                    Start Date: {selected?.start_date}
                  </Typography>
                </Box>
              </Grid>

              <Grid item xs={12} md={6}>
                <Box sx={boxStyles}>
                  <img
                    style={{ width: "24px", height: "24px" }}
                    src={dateIcon}
                    alt="Date icon"
                  />

                  <Typography
                    variant="body1"
                    color="inactive.main"
                    textTransform="capitalize"
                  >
                    End Date: {selected?.end_date}
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </StyledWrapper>

          <StyledWrapper
            sx={{
              gap: "20px",
              p: { xs: "12px", lg: "20px" },
            }}
          >
            <Typography variant="h3" color="darkGreenAccent">
              Description
            </Typography>

            <Box sx={{ display: "flex", alignItems: "flex-start", gap: 2 }}>
              <img src={menuIcon} alt="Description Menu icon" />

              <Typography variant="body1" color="inactive.main">
                Description:
                <br />
                {selected?.description}
              </Typography>
            </Box>
          </StyledWrapper>
        </Stack>
      </CustomModal>

      {isErrorProjects && (
        <Typography variant="h3" sx={{ alignSelf: "center" }}>
          Error Fetching Courses!
        </Typography>
      )}
      {isLoadingProjects && (
        <CircularProgress sx={{ mt: 2, alignSelf: "center" }} />
      )}
      {isSuccessProjects && (
        <>
          {projects?.goal_projects && projects?.goal_projects?.length > 0 ? (
            <Stack className="projects__wrapper" sx={{ mt: 2, gap: "16px" }}>
              <Grid container spacing={2}>
                {projects.goal_projects.map((project) => (
                  <Grid xs={12} lg={6} key={project.id}>
                    <ProjectAction
                      project={project}
                      handleOpen={handleOpen}
                      selectedProjectId={selected?.id}
                      handleProjectCardClick={handleProjectCardClick}
                    />
                  </Grid>
                ))}
              </Grid>

              <StyledSmallDarkBtn onClick={() => handleAddProject(selected)}>
                add project
              </StyledSmallDarkBtn>
            </Stack>
          ) : (
            <Typography
              variant="h4"
              sx={{
                textAlign: "center",
                color: "darkAccent",
                fontWeight: 600,
                textDecoration: "underline",
                mt: 2,
              }}
            >
              No projects found yet
            </Typography>
          )}
        </>
      )}
    </>
  );
};

export default ProjectsActionModule;
