import { Stack, Typography } from "@mui/material";
import React from "react";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import StyledTextField from "../../../components/styled/StyledTextField";
import StyledTextarea from "../../../components/styled/StyledTextarea";

const Step1AddGoal = ({ formik }) => {
  return (
    <StyledWrapper className="step1__addGoal" sx={{ gap: "16px" }}>
      <Stack sx={{ color: "darkGreenAccent", gap: "2px" }}>
        <Typography variant="h4">Step 1 of 4</Typography>

        <Typography variant="h3">Determine Your Goal</Typography>
      </Stack>

      <StyledTextField
        id="name"
        name="name"
        variant="outlined"
        placeholder="Goal name"
        label="Goal name"
        type="text"
        value={formik.values.name}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        helperText={formik.touched.name ? formik.errors.name : ""}
        error={formik.touched.name && Boolean(formik.errors.name)}
      />

      <StyledTextarea
        id="description"
        name="description"
        variant="outlined"
        placeholder="Description"
        label="Description"
        multiline
        rows={4}
        value={formik.values.description}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        helperText={formik.touched.description ? formik.errors.description : ""}
        error={formik.touched.description && Boolean(formik.errors.description)}
      />
    </StyledWrapper>
  );
};

export default Step1AddGoal;
