import { Box, IconButton, Stack, Typography } from "@mui/material";
import React from "react";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import StyledRoundedBtn from "../../../components/styled/StyledRoundedBtn";
import AddIcon from "@mui/icons-material/Add";
import CloseIcon from "@mui/icons-material/Close";
import DescriptionTooltip from "../../../ui/DescriptionTooltip";
import { useDispatch, useSelector } from "react-redux";
import { setSelectedSkills } from "../../../redux/slices/Employee/goals/goalsSlice";

const Step2AddGoal = ({ formik, handleOpen }) => {
  const { selectedSkills } = useSelector((state) => state.goals);
  const dispatch = useDispatch();

  const handleRemoveSkill = (skillId) => {
    const updatedSkills = selectedSkills.filter((skill) => {
      if (skill.id) {
        return skill.id !== skillId;
      } else {
        return skill.skill_id !== skillId;
      }
    });

    dispatch(setSelectedSkills(updatedSkills));
    formik.setFieldValue("skills", updatedSkills);
  };
  return (
    <StyledWrapper className="step2__addGoal" sx={{ gap: "16px" }}>
      <Stack sx={{ color: "darkGreenAccent", gap: "2px" }}>
        <Typography variant="h4">Step 2 of 4</Typography>

        <Typography variant="h3">Add Skills</Typography>
      </Stack>

      <Stack
        sx={{
          flexDirection: "row",
          justifyContent: { xs: "center", lg: "flex-start" },
          alignItems: "center",
          gap: "12px",
          flexWrap: "wrap",
        }}
      >
        {selectedSkills?.length >= 1 && (
          <Stack
            sx={{
              flexDirection: "row",
              justifyContent: { xs: "center", lg: "flex-start" },
              alignItems: "center",
              gap: "12px",
              flexWrap: "wrap",
            }}
          >
            {selectedSkills?.map((skill) => (
              <Box
                key={skill?.id || skill?.skill_id}
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: "12px",
                  backgroundColor: "softGreen",
                  borderRadius: "100px",
                  py: "4px",
                  px: "12px",
                }}
              >
                <DescriptionTooltip
                  title={skill?.description}
                  placement="bottom-start"
                >
                  <Typography
                    variant="h6"
                    textTransform="none"
                    color="#FFFFFF"
                    fontWeight="500"
                  >
                    {skill?.name || skill?.title}
                  </Typography>
                </DescriptionTooltip>

                <IconButton
                  onClick={() => handleRemoveSkill(skill.id || skill.skill_id)}
                  sx={{ p: 0 }}
                >
                  <CloseIcon
                    sx={{ width: "16px", height: "16px", color: "white" }}
                  />
                </IconButton>
              </Box>
            ))}
          </Stack>
        )}

        <StyledRoundedBtn
          onClick={handleOpen}
          sx={{ alignSelf: "flex-start" }}
          endIcon={<AddIcon sx={{ width: "16px", height: "16px" }} />}
        >
          <Typography
            variant="h6"
            textTransform="capitalize"
            color="softGreen"
            fontWeight="500"
          >
            add skill
          </Typography>
        </StyledRoundedBtn>
      </Stack>
    </StyledWrapper>
  );
};

export default Step2AddGoal;
