import {
  Box,
  IconButton,
  Stack,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import delete_inactive from "../../../assets/delete_inactive.svg";
import React, { useCallback } from "react";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import DevelopActions from "./DevelopActions";
import StyledDarkWrapper from "../../../components/styled/StyledDarkWrapper";
import axiosInstance from "../../../helper/axiosInstance";
import { useDispatch, useSelector } from "react-redux";
import { fetchActionsDataByGoalId } from "../../../redux/slices/Employee/goals/goalsActions";
import {
  setSelectedActivities,
  setSelectedCourses,
  setSelectedProjects,
} from "../../../redux/slices/Employee/goals/goalsSlice";

const Step3AddGoal = ({ formik, onEdit, handleOpenSnack, goalId }) => {
  const theme = useTheme();
  const lgMatches = useMediaQuery(theme.breakpoints.up("lg"));
  const { token } = useSelector((state) => state.auth);
  const { actions, selectedCourses, selectedProjects, selectedActivities } =
    useSelector((state) => state.goals);
  const dispatch = useDispatch();
  const selectedActions = onEdit
    ? [...actions?.courses, ...actions?.projects, ...actions?.activities]
    : [...selectedCourses, ...selectedProjects, ...selectedActivities];

  const removeAction = (title) => {
    dispatch(
      setSelectedProjects(
        selectedProjects?.filter((project) => project?.details?.title !== title)
      )
    );
    dispatch(
      setSelectedActivities(
        selectedActivities?.filter(
          (activity) => activity?.details?.title !== title
        )
      )
    );
    dispatch(
      setSelectedCourses(
        selectedCourses?.filter((course) => course?.details?.title !== title)
      )
    );
  };

  const removeActionRequest = useCallback(async (id) => {
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        id,
      },
    };

    try {
      const response = await axiosInstance.delete("goals/actions", config);
      handleOpenSnack(true, response.data.message);
    } catch (error) {
      handleOpenSnack(false, error?.response.data.message);
    } finally {
      dispatch(fetchActionsDataByGoalId(goalId));
    }
  }, []);

  const handleRemoveAction = (id) => {
    if (onEdit) {
      removeActionRequest(id);
    } else {
      removeAction(id);
    }
  };

  return (
    <StyledWrapper className="step3__addGoal" sx={{ gap: "16px" }}>
      <Stack sx={{ color: "darkGreenAccent", gap: "2px" }}>
        <Typography variant="h4">Step 3 of 4</Typography>

        <Typography variant="h3">Develop Actions</Typography>

        <Typography variant="body1" sx={{ color: "inactive.main", mb: "18px" }}>
          Here you can add concrete actions and sign them off
        </Typography>

        <Typography variant="h3" mb={1}>
          Selected Actions
        </Typography>
        {selectedActions?.length > 0 &&
          selectedActions?.map((action) => (
            <StyledDarkWrapper key={action?.id} gap="12px">
              <Grid container spacing={2} alignItems="center">
                <Grid xs={10} lg={9}>
                  <Typography
                    title={action?.details?.title}
                    variant="body1"
                    color="inactive.main"
                  >
                    {action?.details?.title || action?.details?.name}
                  </Typography>
                </Grid>

                {lgMatches && (
                  <Grid xs={2}>
                    <Typography
                      variant="body1"
                      color="inactive.main"
                      textTransform="capitalize"
                    >
                      {action?.type === "courses" && "Course"}
                      {action?.type === "projects" && "Project"}
                      {action?.type === "activities" && "Activity"}
                    </Typography>
                  </Grid>
                )}

                <Grid xs={2} lg={1} textAlign="right">
                  <IconButton
                    onClick={() =>
                      handleRemoveAction(
                        onEdit ? action?.id : action?.details?.title
                      )
                    }
                    sx={{ p: 0 }}
                  >
                    <Box component={"img"} src={delete_inactive} />
                  </IconButton>
                </Grid>
              </Grid>
            </StyledDarkWrapper>
          ))}

        <DevelopActions
          formik={formik}
          onEdit={onEdit}
          handleOpenSnack={handleOpenSnack}
          goalId={goalId}
        />
      </Stack>
    </StyledWrapper>
  );
};

export default Step3AddGoal;
