import React from "react";
import StyledDatePicker from "../../../components/styled/StyledDatePicker";
import { Stack, TextField, Typography } from "@mui/material";

const TimingModule = ({ formik }) => {
  return (
    <Stack sx={{ flexDirection: { lg: "row", gap: "16px" } }}>
      <Stack sx={{ width: "100%" }}>
        <StyledDatePicker
          label="Start date"
          sx={{ flex: 1 }}
          value={formik.values.startDate}
          onChange={(value) => {
            formik.setFieldValue("startDate", value);
          }}
          slot={(params) => (
            <TextField
              {...params}
              error={Boolean(
                formik.touched.startDate && formik.errors.startDate
              )}
              helperText={formik.touched.startDate && formik.errors.startDate}
              id="startDate"
              name="startDate"
            />
          )}
        />

        {formik.touched.startDate && formik.errors.startDate ? (
          <Typography
            sx={{
              color: "#d32f2f",
              mx: "14px",
              mt: "3px",
              fontSize: "0.8571428571428571rem",
            }}
          >
            {formik.errors.startDate}
          </Typography>
        ) : null}
      </Stack>

      <Stack sx={{ width: "100%" }}>
        <StyledDatePicker
          label="Due date"
          sx={{ flex: 1 }}
          value={formik.values.dueDate}
          onChange={(value) => {
            formik.setFieldValue("dueDate", value);
          }}
          slot={(params) => (
            <TextField
              {...params}
              error={Boolean(formik.touched.dueDate && formik.errors.dueDate)}
              helperText={formik.touched.dueDate && formik.errors.dueDate}
              id="dueDate"
              name="dueDate"
            />
          )}
        />

        {formik.touched.dueDate && formik.errors.dueDate ? (
          <Typography
            sx={{
              color: "#d32f2f",
              mx: "14px",
              mt: "3px",
              fontSize: "0.8571428571428571rem",
            }}
          >
            {formik.errors.dueDate}
          </Typography>
        ) : null}
      </Stack>
    </Stack>
  );
};

export default TimingModule;
