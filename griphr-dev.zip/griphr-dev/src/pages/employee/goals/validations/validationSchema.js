import * as yup from "yup";

const validationSchema = yup.object().shape({
  name: yup.string().required("Name is required"),
  startDate: yup
    .date()
    .required("Start date is required")
    .typeError("Start date is required"),
  dueDate: yup
    .date()
    .required("Due date is required")
    .typeError("Due date is required"),
});

export default validationSchema;
