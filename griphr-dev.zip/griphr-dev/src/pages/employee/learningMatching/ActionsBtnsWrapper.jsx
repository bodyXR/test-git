import { Box, Stack } from "@mui/material";
import { CourseBtn } from "./CoursePreview";
import correctIcon from "../../../assets/correct_icon_btn.svg";
import deleteIcon from "../../../assets/delete_icon.svg";
import { useDispatch, useSelector } from "react-redux";
import { setCourseState } from "../../../redux/slices/Employee/courses/coursesSlice";
import { startCourseAndFetchDetails } from "../../../redux/slices/Employee/courses/coursesActions";

const ActionsBtnsWrapper = ({ onOpenModal, course_id }) => {
  const dispatch = useDispatch();
  const { courseState, isLoadingAction, matchedCourse, myCourse } = useSelector(
    (state) => state.courses
  );

  return (
    <Stack sx={{ gap: "16px", minWidth: { md: "219px" } }}>
      {courseState === "not started" && (
        <CourseBtn
          variant="contained"
          onClick={() => {
            dispatch(
              startCourseAndFetchDetails({
                course_id: matchedCourse?.course_id,
              })
            );
          }}
          disabled={isLoadingAction}
        >
          start course
        </CourseBtn>
      )}
      {courseState === "started" && (
        <>
          <CourseBtn
            endIcon={<Box component={"img"} src={correctIcon} />}
            variant="contained"
            onClick={() => {
              onOpenModal("complete");
            }}
          >
            Mark as completed
          </CourseBtn>
          <CourseBtn
            sx={{
              backgroundColor: "transparent",
              borderColor: "#173433",
              "&:hover": {
                backgroundColor: "alert.main",
                borderColor: "alert.main",
              },
            }}
            endIcon={<Box component={"img"} src={deleteIcon} />}
            variant="outlined"
            onClick={() => {
              onOpenModal("remove");
            }}
          >
            remove course
          </CourseBtn>
        </>
      )}
    </Stack>
  );
};

export default ActionsBtnsWrapper;
