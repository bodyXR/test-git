import { Stack, Typography } from "@mui/material";
import { CourseBtn } from "./CoursePreview";
import { useDispatch, useSelector } from "react-redux";
import {
  completeCourseAndFetchMyCourses,
  fetchMyCourse,
} from "../../../redux/slices/Employee/courses/coursesActions";

const CompleteCourseModalContent = ({
  courseTitle,
  onOpenSkillsModal,
  onClose,
}) => {
  const { courseLevel, myCourse, isLoadingAction } = useSelector(
    (state) => state.courses
  );
  const dispatch = useDispatch();
  return (
    <>
      <Typography
        variant="h4"
        sx={{
          lineHeight: "1.5",
          textAlign: "center",
          color: "darkGreen",
          fontWeight: "600",
        }}
      >
        <Typography
          variant="h4"
          component="span"
          sx={{
            fontWeight: 400,
            color: "inactive.main",
            lineHeight: "1.5",
          }}
        >
          Did you succesfully complete the
        </Typography>{" "}
        {courseTitle}{" "}
      </Typography>
      <Stack
        sx={{ flexDirection: { md: "row" }, gap: { xs: "8px", md: "32px" } }}
      >
        <CourseBtn
          onClick={() => {
            dispatch(completeCourseAndFetchMyCourses(myCourse?.id));
            // onOpenSkillsModal("finished");
            dispatch(fetchMyCourse(myCourse?.id));
            onClose();
          }}
          disabled={isLoadingAction}
        >
          yes, i did
        </CourseBtn>
        <CourseBtn
          onClick={onClose}
          sx={{
            bgcolor: "transparent",
            borderColor: "#173433",
            "&:hover": {
              backgroundColor: "transparent",
            },
          }}
        >
          no, not yet
        </CourseBtn>
      </Stack>
    </>
  );
};

export default CompleteCourseModalContent;
