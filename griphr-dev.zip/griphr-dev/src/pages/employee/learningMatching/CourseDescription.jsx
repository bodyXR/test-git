import React from "react";
import SoftGrayPaper from "./SoftGrayPaper";
import descriptionIcon from "../../../assets/description_menu_icon.svg";
import { Stack, Typography } from "@mui/material";
import { StyledSVG } from "./CourseDetails";
import { useSelector } from "react-redux";

const CourseDescription = ({ course }) => {
  const { myCourse, matchedCourse, courseState } = useSelector(
    (state) => state.courses
  );
  const courseLink =
    courseState === "not started"
      ? matchedCourse?.course_id
      : myCourse?.course_id;
  return (
    <SoftGrayPaper>
      <Typography variant="h3" color={"#173433"}>
        Description
      </Typography>
      <Stack sx={{ flexDirection: "row", gap: "16px" }}>
        <StyledSVG
          src={descriptionIcon}
          beforeInjection={(svg) => {
            svg.setAttribute("width", "24px");
            svg.setAttribute("height", "24px");
          }}
        />
        <Typography variant="body1" color={"#788894"}>
          {course?.description}
        </Typography>
      </Stack>
      <Stack sx={{ flexDirection: "row", gap: "16px" }}>
        <Typography
          variant="body1"
          component={"a"}
          color={"#66c1ff"}
          target="_blank"
          href={`https://www.udemy.com/course/${courseLink}`}
          sx={{ cursor: "pointer", textDecoration: "underline" }}
        >
          Course Link
        </Typography>
      </Stack>
    </SoftGrayPaper>
  );
};

export default CourseDescription;
