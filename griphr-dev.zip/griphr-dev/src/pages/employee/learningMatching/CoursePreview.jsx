import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import CourseTitleWrapper from "./CourseTitleWrapper";
import { Button, CircularProgress, Stack, styled } from "@mui/material";
import CoursePriceWrapper from "./CoursePriceWrapper";
import CourseDescription from "./CourseDescription";
import ActionsBtnsWrapper from "./ActionsBtnsWrapper";
import CourseModal from "./CourseModal";
import CompleteCourseModalContent from "./CompleteCourseModalContent";
import RemoveCourseModalContent from "./RemoveCourseModalContent";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchMatchedCourseById,
  fetchMyCourse,
} from "../../../redux/slices/Employee/courses/coursesActions";
import { setCourseState } from "../../../redux/slices/Employee/courses/coursesSlice";

export const CourseBtn = styled(Button)(({ theme }) => ({
  width: "100%",
  alignSelf: "stretch",
  padding: "10px",
  fontSize: "14px",
  fontWeight: 600,
  textTransform: "capitalize",
  color: theme.palette.darkGreen,
  border: `1px solid ${theme.palette.accent}`,
  borderRadius: "5px",
  backgroundColor: theme.palette.accent,
  "&:hover": {
    backgroundColor: theme.palette.accent,
  },
}));

const CoursePreview = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const { course, fromMyCourses } = location?.state;
  const { courseId: course_id } = useParams();
  const { token } = useSelector((state) => state.auth);
  const {
    myCourses,
    courseSkillId: skill,
    courseLevel: level,
    isLoadingMatchedCourses,
    isLoadingMyCourses,
    isSuccessMatchedCourses,
    isSuccessMyCourses,
    courseState,
  } = useSelector((state) => state.courses);

  const [courseModalAction, setCourseModalAction] = useState(null);

  const [openModal, setOpenModal] = useState(false);
  const openModalHandler = (action = null) => {
    setOpenModal(true);
    setCourseModalAction({ action });
  };
  const closeModalHandler = () => {
    setOpenModal(false);
  };

  // fromMycourses => true => unique course id => course_id
  // fromMycourses => false => unique course id => id

  const [searchCourse, setSearchCourse] = useState(null);
  useEffect(() => {
    if (myCourses?.length > 0)
      setSearchCourse(
        myCourses.find((c) => {
          if (fromMyCourses) {
            return c.course_id === course?.course_id;
          } else {
            return c.course_id === course?.id;
          }
        })
      );
  }, [myCourses, course, fromMyCourses]);

  useEffect(() => {
    if (token && !searchCourse) {
      dispatch(setCourseState("not started"));
      dispatch(fetchMatchedCourseById({ skill_id: skill, level, course_id }));
    } else if (token && searchCourse) {
      dispatch(setCourseState(searchCourse?.status));
      dispatch(fetchMyCourse(searchCourse?.id));
    }
  }, [
    dispatch,
    skill,
    level,
    course_id,
    token,
    courseState,
    searchCourse,
    myCourses,
  ]);

  return (
    <>
      <CourseModal open={openModal} onClose={closeModalHandler}>
        {courseModalAction?.action === "complete" && (
          <CompleteCourseModalContent courseTitle={course?.title} />
        )}
        {courseModalAction?.action === "remove" && (
          <RemoveCourseModalContent courseTitle={course?.title} />
        )}
      </CourseModal>

      {
        <Stack sx={{ gap: "24px" }}>
          <Stack
            sx={{
              flexDirection: { md: "row" },
              justifyContent: { md: "space-between" },
              gap: { md: 3, lg: "48px" },
            }}
          >
            {isLoadingMatchedCourses || isLoadingMyCourses ? (
              <CircularProgress />
            ) : (
              <>
                <CourseTitleWrapper course={course} />
                <ActionsBtnsWrapper
                  onOpenModal={openModalHandler}
                  course_id={course_id}
                />
              </>
            )}
          </Stack>
          <CoursePriceWrapper price={course?.price_detail?.price_string} />
          <CourseDescription course={course} />
        </Stack>
      }
    </>
  );
};

export default CoursePreview;
