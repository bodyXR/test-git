import { Box, Chip, Stack, Typography } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";

const CourseTitleWrapper = ({ course }) => {
  const courseStateColor = {
    "not started": "#c0c0c0",
    started: "#66C1FF",
    completed: "action.selected",
  };
  const { courseState } = useSelector((state) => state.courses);

  return (
    <Stack
      className="courseState__wrapper"
      sx={{ flexDirection: { md: "row" }, gap: "16px" }}
    >
      <Box
        component="img"
        src={course?.image || course?.image_240x135}
        alt="course img"
        sx={{ alignSelf: "flex-start", width: "240px", height: "135px" }}
      />
      <Stack sx={{ gap: "8px" }}>
        <Typography
          variant="h2"
          sx={{ textTransform: "capitalize", color: "darkGreen" }}
        >
          {course?.title}
        </Typography>
        <Chip
          label={courseState}
          sx={{
            backgroundColor: `${courseStateColor[courseState]}`,
            alignSelf: "flex-start",
            "& .MuiChip-label": {
              color: "#788894",
            },
          }}
        />
      </Stack>
    </Stack>
  );
};

export default CourseTitleWrapper;
