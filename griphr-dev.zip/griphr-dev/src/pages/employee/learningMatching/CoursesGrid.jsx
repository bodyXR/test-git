import Grid from "@mui/material/Unstable_Grid2";
import UdemyCourseCard from "./UdemyCourseCard";
import { Box } from "@mui/material";
import { useSelector } from "react-redux";

const CoursesGrid = () => {
  const { matchedCourses } = useSelector((state) => state.courses);
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid
        container
        columnSpacing={{ xs: 3, sm: 3 }}
        rowSpacing={{ xs: 3 }}
        columns={{ xs: 4, sm: 8, lg: 12, xl: 16 }}
      >
        {matchedCourses?.map((course, index) => (
          <Grid
            xs={4}
            key={index}
            sx={{ display: "flex", justifyContent: "center" }}
          >
            <UdemyCourseCard course={course} />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default CoursesGrid;
