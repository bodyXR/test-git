import { Box, Button } from "@mui/material";
import MyCourseCard from "./MyCourseCard";
import CourseModal from "./CourseModal";
import { useState } from "react";
import Grid from "@mui/material/Unstable_Grid2";
import CompleteCourseModalContent from "./CompleteCourseModalContent";
import RemoveCourseModalContent from "./RemoveCourseModalContent";
import { useSelector } from "react-redux";

const CoursesList = () => {
  const [courseModalAction, setCourseModalAction] = useState({});

  const [openModal, setOpenModal] = useState(false);

  const { myCourses } = useSelector((state) => state.courses);

  const openModalHandler = (courseTitle, skills, action) => {
    setOpenModal(true);
    setCourseModalAction({ courseTitle, skills, action });
  };

  const closeModalHandler = () => {
    setOpenModal(false);
  };

  const openSkillsModalHandler = (action) => {
    setCourseModalAction({ action });
  };

  const [showMore, setShowMore] = useState(false);

  const courses = showMore ? myCourses : myCourses.slice(0, 6);

  return (
    <>
      <CourseModal
        onOpenSkillsModal={openSkillsModalHandler}
        open={openModal}
        onClose={closeModalHandler}
      >
        {courseModalAction?.action === "complete" && (
          <CompleteCourseModalContent
            courseTitle={courseModalAction?.courseTitle}
          />
        )}
        {courseModalAction?.action === "remove" && (
          <RemoveCourseModalContent
            courseTitle={courseModalAction?.courseTitle}
          />
        )}
      </CourseModal>

      <Box sx={{ flexGrow: 1, alignSelf: "stretch" }}>
        <Grid
          container
          className="course__list"
          rowSpacing={2}
          columnSpacing={{ xs: 0, md: 2 }}
          sx={{
            width: "100%",
          }}
        >
          {courses?.map((course, index) => (
            <Grid key={index} xs={12} md={6} xl={4}>
              <MyCourseCard onModal={openModalHandler} course={course} />
            </Grid>
          ))}
        </Grid>
        {myCourses.length > 6 && (
          <Button
            disableTouchRipple
            type="button"
            sx={{
              color: "#66C1FF",
              alignSelf: "flex-start",
              textTransform: "capitalize",
              fontWeight: "400",
              lineHeight: "1.5",
              mt: 1,
              "&: hover": {
                backgroundColor: "transparent",
              },
              fontSize: { xs: "12px", md: "16px" },
            }}
            onClick={() => setShowMore((prev) => !prev)}
          >
            {showMore ? "Show Less..." : "Show More..."}
          </Button>
        )}
      </Box>
    </>
  );
};

export default CoursesList;
