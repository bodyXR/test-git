import { CircularProgress, Pagination, Stack, Typography } from "@mui/material";
import MyCourses from "./MyCourses";
import LevelFilter from "./LevelFilter";
import TagsWrapper from "./TagsWrapper";
import CoursesGrid from "./CoursesGrid";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { fetchSkillsData } from "../../../redux/slices/Employee/mySkills/mySkillsActions";
import {
  fetchMatchedCourses,
  fetchMyCourses,
} from "../../../redux/slices/Employee/courses/coursesActions";
import {
  setCourseSkillId,
  setSortedUserSkills,
} from "../../../redux/slices/Employee/courses/coursesSlice";
import PriceFilter from "./PriceFilter";

const EmployeeLearningMatching = () => {
  const { userInfo, token } = useSelector((state) => state.auth);
  const { skills } = useSelector((state) => state.mySkills);
  const dispatch = useDispatch();
  const [pagination, setPagination] = useState(1);

  const {
    matchedCourses: myMatchedCourses,
    isErrorMyCourses,
    isSuccessMyCourses,
    isLoadingMyCourses,
    isLoadingMatchedCourses,
    isErrorMatchedCourses,
    isSuccessMatchedCourses,
    coursesCount,
    courseSkillId,
    courseLevel,
    coursePrice,
    sortedUserSkills,
  } = useSelector((state) => state.courses);

  // Fetch Skills
  useEffect(() => {
    if (token) {
      dispatch(fetchSkillsData(userInfo.id));
    }
  }, [token, dispatch]);

  useEffect(() => {
    if (skills?.length > 0)
      dispatch(
        setSortedUserSkills(
          skills.slice()?.sort((a, b) => a?.title?.localeCompare(b?.title))
        )
      );
  }, [skills]);

  // Fetch My Courses
  useEffect(() => {
    if (token) {
      dispatch(fetchMyCourses());
    }
  }, [token]);

  // Fetch Matched Courses
  useEffect(() => {
    if (sortedUserSkills?.length > 0) {
      if (courseSkillId) {
        if (
          sortedUserSkills?.some((skill) => skill?.skill_id === courseSkillId)
        ) {
          dispatch(
            fetchMatchedCourses({
              skill_id: courseSkillId,
              level: courseLevel,
              page: pagination,
              price: coursePrice,
            })
          );
        } else {
          dispatch(setCourseSkillId(sortedUserSkills[0]?.skill_id));
          dispatch(
            fetchMatchedCourses({
              skill_id: sortedUserSkills[0]?.skill_id,
              level: courseLevel,
              page: pagination,
              price: coursePrice,
            })
          );
        }
      }
    } else {
      dispatch(setCourseSkillId(null));
    }
  }, [courseSkillId, courseLevel, coursePrice, pagination, sortedUserSkills]);

  const handlePagination = (event, value) => {
    setPagination(value);
  };

  return (
    <Stack sx={{ gap: "24px" }}>
      {isErrorMyCourses && (
        <Typography variant="h3">Error Fetching Courses!</Typography>
      )}
      {isLoadingMyCourses && <CircularProgress />}
      {isSuccessMyCourses && <MyCourses />}
      <Stack
        sx={{
          flexDirection: { md: "row" },
          justifyContent: { md: "space-between" },
          alignItems: "center",
          py: "24px",
          px: "0",
          gap: "16px",
        }}
      >
        <Typography variant="h3" sx={{ color: "darkGreen", fontWeight: 600 }}>
          Suggestions based on your job
        </Typography>
        <Stack sx={{ flexDirection: "row", gap: 2 }}>
          <PriceFilter />
          <LevelFilter />
        </Stack>
      </Stack>

      <Typography
        sx={{
          color: "inactive.main",
          textAlign: "center",
        }}
        variant="body1"
      >
        Keep your skill profile updated for the most relevant learning matches
      </Typography>

      <TagsWrapper />
      {isErrorMatchedCourses && (
        <Typography variant="h3" sx={{ alignSelf: "center" }}>
          Error Fetching Courses!
        </Typography>
      )}
      {isLoadingMatchedCourses && (
        <Stack sx={{ alignItems: "center", mt: 3 }}>
          <CircularProgress sx={{ alignSelf: "center" }} />
        </Stack>
      )}
      {isSuccessMatchedCourses && (
        <>
          {myMatchedCourses.length > 0 ? (
            <>
              <CoursesGrid />
              <Stack sx={{ alignItems: "center", mt: 3 }}>
                {coursesCount && (
                  <Pagination
                    page={pagination}
                    count={Math.ceil(coursesCount / 8)}
                    shape="rounded"
                    size="large"
                    onChange={handlePagination}
                  />
                )}
              </Stack>
            </>
          ) : (
            <Typography variant="h3">No Courses Found!</Typography>
          )}
        </>
      )}
    </Stack>
  );
};

export default EmployeeLearningMatching;
