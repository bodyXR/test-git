import { Stack } from "@mui/material";
import React from "react";
import CustomChip from "./CustomChip";
import { setCourseSkillId } from "../../../redux/slices/Employee/courses/coursesSlice";
import { useDispatch, useSelector } from "react-redux";

const TagsWrapper = () => {
  const dispatch = useDispatch();
  const { courseSkillId, sortedUserSkills } = useSelector(
    (state) => state.courses
  );
  return (
    <Stack
      sx={{
        justifyContent: "center",
        alignItems: "center",
        alignContent: "center",
        flexDirection: "row",
        flexWrap: "wrap",
        gap: "10px",
      }}
    >
      {sortedUserSkills?.map((tag, index) => (
        <CustomChip
          onClick={() => dispatch(setCourseSkillId(tag?.skill_id))}
          key={index}
          id={tag?.skill_id}
          label={tag.title}
          selectedskillid={courseSkillId}
        />
      ))}
    </Stack>
  );
};

export default TagsWrapper;
