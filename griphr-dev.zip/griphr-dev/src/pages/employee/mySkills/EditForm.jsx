import { CircularProgress, Stack } from "@mui/material";
import PersonalInformation from "../../admin/organigram/PersonalInformation";
import StyledDarkBtn from "../../../components/styled/StyledDarkBtn";
import StyledOutlinedBtn from "../../../components/styled/StyledOutlinedBtn";
import RoleDetails from "../../admin/organigram/RoleDetails";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const EditForm = ({ formik, loading, closeModal, employeeId }) => {
  const { token } = useSelector((state) => state.auth);

  useEffect(() => {
    console.log("formik.values", formik.values);
  }, [formik.values]);

  return (
    <form onSubmit={formik.handleSubmit}>
      <Stack sx={{ gap: 3, px: { xs: 2.5, lg: 0 } }}>
        <PersonalInformation formik={formik} onEdit={true} />
        <RoleDetails formik={formik} employeeId={employeeId} />

        <Stack
          sx={{
            flexDirection: { lg: "row" },
            alignItems: "center",
            gap: "16px",
          }}
        >
          <StyledDarkBtn
            type="submit"
            sx={{ width: { xs: "100%", lg: "initial" } }}
          >
            save
          </StyledDarkBtn>

          <StyledOutlinedBtn
            onClick={closeModal}
            sx={{
              width: { xs: "100%", lg: "initial" },
              backgroundColor: "softAccent",
              borderColor: "skillGreen",
              color: "skillGreen",
            }}
          >
            cancel
          </StyledOutlinedBtn>

          {loading && <CircularProgress size={20} />}
        </Stack>
      </Stack>
    </form>
  );
};

export default EditForm;
