// import Uppy from "@uppy/core";
// import Webcam from "@uppy/webcam";
// import { Dashboard } from "@uppy/react";

// const uppy = new Uppy().use();

// const ResumeUploader = () => {
//   return <div>ResumeUploader</div>;
// };

// export default ResumeUploader;v
