import { Box, useMediaQuery, useTheme } from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import CourseCard from "./CourseCard";
import { useSelector } from "react-redux";

const CoursesCards = () => {
  const theme = useTheme();
  const xlMatches = useMediaQuery(theme.breakpoints.up("xl"));

  const { matchedCourses } = useSelector((state) => state.courses);
  const courses = xlMatches
    ? matchedCourses.slice(0, 4)
    : matchedCourses.slice(0, 3);

  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid
        container
        columnSpacing={{ xs: 3, sm: 3 }}
        rowSpacing={{ xs: 3 }}
        columns={{ xs: 4, sm: 8, lg: 12, xl: 16 }}
      >
        {courses.slice(0, 4)?.map((course, index) => (
          <Grid
            xs={4}
            key={index}
            sx={{ display: "flex", justifyContent: "center" }}
          >
            <CourseCard course={course} />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default CoursesCards;
