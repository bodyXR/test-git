import { Box, useMediaQuery } from "@mui/material";
import { useState } from "react";
import Grid from "@mui/material/Unstable_Grid2";
import { useSelector } from "react-redux";
import CourseModal from "../learningMatching/CourseModal";
import CompleteCourseModalContent from "../learningMatching/CompleteCourseModalContent";
import RemoveCourseModalContent from "../learningMatching/RemoveCourseModalContent";
import MyCourseCard from "../learningMatching/MyCourseCard";
import { useTheme } from "@emotion/react";

const CurrentCourses = () => {
  const theme = useTheme();
  const xlMatches = useMediaQuery(theme.breakpoints.up("xl"));

  const [courseModalAction, setCourseModalAction] = useState({});

  const [openModal, setOpenModal] = useState(false);

  const { myCourses } = useSelector((state) => state.courses);

  const courses = xlMatches ? myCourses.slice(0, 3) : myCourses.slice(0, 2);

  const openModalHandler = (courseTitle, skills, action) => {
    setOpenModal(true);
    setCourseModalAction({ courseTitle, skills, action });
  };

  const closeModalHandler = () => {
    setOpenModal(false);
  };

  const openSkillsModalHandler = (action) => {
    setCourseModalAction({ action });
  };

  return (
    <>
      <CourseModal
        onOpenSkillsModal={openSkillsModalHandler}
        open={openModal}
        onClose={closeModalHandler}
      >
        {courseModalAction?.action === "complete" && (
          <CompleteCourseModalContent
            courseTitle={courseModalAction?.courseTitle}
          />
        )}
        {courseModalAction?.action === "remove" && (
          <RemoveCourseModalContent
            courseTitle={courseModalAction?.courseTitle}
          />
        )}
      </CourseModal>

      <Box sx={{ flexGrow: 1, alignSelf: "stretch" }}>
        <Grid
          container
          className="course__list"
          rowSpacing={2}
          columnSpacing={{ xs: 0, md: 2 }}
          sx={{
            width: "100%",
          }}
        >
          {courses?.map((course, index) => (
            <Grid key={index} xs={12} md={6} xl={4}>
              <MyCourseCard onModal={openModalHandler} course={course} />
            </Grid>
          ))}
        </Grid>
      </Box>
    </>
  );
};

export default CurrentCourses;
