import {
  Button,
  CircularProgress,
  InputAdornment,
  ListItemText,
  Menu,
  MenuItem,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import search from "../../../assets/search.svg";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import EmployeeHeaders from "./EmployeeHeaders";
import EmployeeTableRow from "./EmployeeTableRow";
import StyledWrapper from "../../../components/styled/StyledWrapper";
import { fetchGoalsData } from "../../../redux/slices/Employee/goals/goalsActions";
import { useLocation, useOutletContext } from "react-router-dom";

const EmployeeGoals = () => {
  const location = useLocation();
  const [title, setTitle] = useOutletContext();
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOrder, setSortOrder] = useState("asc");
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const { data, loading } = useSelector((state) => state.goals);
  const dispatch = useDispatch();

  useEffect(() => {
    setTitle(location.pathname.split("/").at(-1));
  }, [setTitle, location]);

  useEffect(() => {
    dispatch(fetchGoalsData("users"));
  }, []);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const handleFilterClick = (sortBy) => {
    setSortOrder(sortBy);
    handleClose();
  };

  const sortedUsers = data
    ?.slice()
    ?.sort((a, b) => {
      if (sortOrder === "asc") {
        return a?.first_name?.localeCompare(b?.first_name);
      } else {
        return b?.first_name?.localeCompare(a?.first_name);
      }
    })
    .filter(
      (user) =>
        user?.first_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user?.last_name?.toLowerCase().includes(searchQuery.toLowerCase())
    );

  return (
    <Stack gap="26.5px">
      <Stack
        sx={{
          flexDirection: { xs: "column-reverse", md: "row" },
          gap: "20px",
        }}
      >
        <Stack
          sx={{
            flexDirection: "row",
            alignItems: "center",
            gap: "20px",
            width: "100%",
          }}
        >
          <TextField
            name="search_employee"
            fullWidth
            size="small"
            type="search"
            variant="outlined"
            value={searchQuery}
            onChange={handleSearchChange}
            sx={{
              background: "white",
              "& .MuiInputBase-input": {
                height: "31px",
              },
            }}
            placeholder="Search Employee"
            InputProps={{
              endAdornment: (
                <InputAdornment position="start">
                  <img src={search} alt="search icon" />
                </InputAdornment>
              ),
            }}
          />

          <Button
            onClick={handleClick}
            sx={{
              width: "125px",
              height: "48px",
              textTransform: "none",
              background: "white",
              border: "1px solid #C0C0C0 ",
              borderRadius: "4px",
              px: "12px",
            }}
            disableElevation
            disableRipple
            endIcon={
              open ? (
                <KeyboardArrowUpIcon style={{ color: "darkGrey" }} />
              ) : (
                <KeyboardArrowDownIcon style={{ color: "darkGrey" }} />
              )
            }
            variant="outlined"
          >
            <Typography variant="h5" color="darkGrey">
              Sort by
            </Typography>
          </Button>

          <Menu anchorEl={anchorEl} open={open} onClose={handleClose}>
            <MenuItem
              onClick={() => handleFilterClick("asc")}
              sx={{
                justifyContent: "flex-end",
                gap: "16px",
                color: "inactive.main",
              }}
            >
              <ListItemText>Ascending</ListItemText>
            </MenuItem>

            <MenuItem
              onClick={() => handleFilterClick("desc")}
              sx={{
                justifyContent: "flex-end",
                gap: "16px",
                color: "inactive.main",
              }}
            >
              <ListItemText>Descending</ListItemText>
            </MenuItem>
          </Menu>
        </Stack>
      </Stack>

      {loading && <CircularProgress size={20} />}
      {!loading &&
        (sortedUsers?.length > 0 ? (
          <StyledWrapper>
            <EmployeeHeaders />

            <Stack gap="12px">
              {sortedUsers.map((employee) => (
                <EmployeeTableRow key={employee.id} data={employee} />
              ))}
            </Stack>
          </StyledWrapper>
        ) : (
          <Typography variant="h3" color="primary">
            No Employees found
          </Typography>
        ))}
    </Stack>
  );
};

export default EmployeeGoals;
