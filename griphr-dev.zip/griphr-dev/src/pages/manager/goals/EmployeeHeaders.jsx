import { Grid, Typography, useMediaQuery, useTheme } from "@mui/material";

const mobileHeaderKeys = ["Employee"];
const headerKeys = ["Employee", "Status", "Progress"];

const xsSpacingMap = [12];
const lgSpacingMap = [5, 3, 3, 1];

const EmployeeHeaders = () => {
  const theme = useTheme();
  const lgMatches = useMediaQuery(theme.breakpoints.up("lg"));
  const shownHeaders = !lgMatches ? mobileHeaderKeys : headerKeys;
  const spacingMap = !lgMatches ? xsSpacingMap : lgSpacingMap;
  const checkFirstChild = (index, array) => index + 1 === array.length - 2;

  return (
    <Grid className="tableHeader__section" container spacing={1} mb="12px">
      {shownHeaders.map((header, index) => (
        <Grid item xs={spacingMap[index]} key={header}>
          <Typography
            sx={{
              color: "darkGreen",
              fontWeight: "500",
              textAlign:
                checkFirstChild(index, headerKeys) && lgMatches
                  ? "left"
                  : "center",
              pl: checkFirstChild(index, headerKeys) && lgMatches ? "53px" : 0,
            }}
            variant="h5"
          >
            {header}
          </Typography>
        </Grid>
      ))}
    </Grid>
  );
};

export default EmployeeHeaders;
