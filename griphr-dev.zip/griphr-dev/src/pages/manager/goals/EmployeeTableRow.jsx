import {
  Avatar,
  Box,
  Collapse,
  Grid,
  IconButton,
  Stack,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import React, { useEffect, useState } from "react";
import StyledDarkWrapper from "../../../components/styled/StyledDarkWrapper";
import GoalTableRow from "./GoalTableRow";

const EmployeeTableRow = ({ data }) => {
  const theme = useTheme();
  const lgMatches = useMediaQuery(theme.breakpoints.up("lg"));
  const [isRowOpen, setIsRowOpen] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleClick = () => {
    setIsRowOpen(!isRowOpen);
  };

  const progressCalculation = (actions) => {
    const totalPercentage = actions?.reduce((sum, action) => {
      return sum + action.percentage;
    }, 0);
    const numberOfActions = actions.length;

    const progress = totalPercentage / numberOfActions;
    return progress;
  };

  const calculateTotalProgress = (goals) => {
    let totalProgress = 0;
    const numberOfGoals = goals?.length;

    goals?.forEach((goal) => {
      const progress = progressCalculation([
        ...goal?.actions?.projects,
        ...goal?.actions?.activities,
      ]);

      // Accumulate the progress for each goal
      totalProgress += progress;
    });

    return totalProgress / numberOfGoals || 0;
  };

  useEffect(() => {
    const totalProgress = calculateTotalProgress(data.goals);
    setProgress(totalProgress);
  }, [data]);

  return (
    <Stack>
      <StyledDarkWrapper
        sx={{
          borderBottomLeftRadius: isRowOpen ? "0px" : "10px",
          borderBottomRightRadius: isRowOpen ? "0px" : "10px",
          borderBottom: isRowOpen ? "none" : "2px solid #EEE",
        }}
      >
        <Grid container sx={{ p: 0 }}>
          <Grid item xs={10} lg={8}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                <Avatar
                  src={data?.profile_picture?.url}
                  alt={data?.profile_picture?.name}
                  sx={{ width: "30px", height: "30px" }}
                />

                <Typography
                  variant="body1"
                  color="inactive.main"
                  textTransform="capitalize"
                >
                  {data.first_name + " " + data.last_name}
                </Typography>
              </Box>
            </Box>
          </Grid>

          {lgMatches && (
            <Grid item xs={2} sx={{ textAlign: "center" }}>
              <Typography
                variant="body1"
                sx={{
                  textTransform: "capitalize",
                  color: "inactive.main",
                  pl: "105px",
                }}
              >
                {progress.toFixed(2)}%
              </Typography>
            </Grid>
          )}

          <Grid item xs={2} sx={{ textAlign: "right" }}>
            <IconButton
              aria-label="expand row"
              size="small"
              onClick={handleClick}
              sx={{ p: 0 }}
            >
              {isRowOpen ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
            </IconButton>
          </Grid>
        </Grid>
      </StyledDarkWrapper>

      <Collapse in={isRowOpen} timeout="auto" unmountOnExit>
        <StyledDarkWrapper
          sx={{
            borderTopLeftRadius: isRowOpen ? "0px" : "10px",
            borderTopRightRadius: isRowOpen ? "0px" : "10px",
            borderTop: isRowOpen ? "none" : "2px solid #EEE",
            gap: 1,
          }}
        >
          {data.goals?.map((goal) => (
            <GoalTableRow
              key={goal.id}
              data={goal}
              userInfo={{
                userName: data.first_name + " " + data.last_name,
                userImg: data.profile_picture?.url,
              }}
            />
          ))}
        </StyledDarkWrapper>
      </Collapse>
    </Stack>
  );
};

export default EmployeeTableRow;
