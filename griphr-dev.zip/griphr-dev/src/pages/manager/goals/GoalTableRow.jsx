import React, { useEffect, useState } from "react";
import { Box, Grid, Typography } from "@mui/material";
import goalIcon from "../../../assets/goals_active.svg";
import { useNavigate } from "react-router-dom";
import { MANAGER_GOAL_DETAILS_ROUTE } from "../../../routes/paths";
import StyledDarkWrapper from "../../../components/styled/StyledDarkWrapper";

const GoalTableRow = ({ data, userInfo }) => {
  const [progress, setProgress] = useState(0);
  const navigate = useNavigate();

  const progressCalculation = (actions) => {
    const totalPercentage = actions?.reduce((sum, action) => {
      return sum + action.percentage;
    }, 0);
    const numberOfActions = actions.length;

    const progress = totalPercentage / numberOfActions;
    return progress;
  };

  useEffect(() => {
    if (data?.id) {
      const progress = progressCalculation([
        ...data?.actions?.projects,
        ...data?.actions?.activities,
      ]);
      setProgress(progress);
    }
  }, [data]);

  return (
    <StyledDarkWrapper>
      <Grid container spacing={1}>
        <Grid item xs={12} lg={5}>
          <Box sx={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <Box
              component={"img"}
              src={goalIcon}
              sx={{ width: "24px", height: "24px" }}
            />

            <Typography
              variant="body1"
              sx={{
                textTransform: "capitalize",
                color: "inactive.main",
              }}
              title={data.name}
            >
              {data.name}
            </Typography>
          </Box>
        </Grid>

        <Grid item xs={6} lg={3} sx={{ textAlign: { lg: "center" } }}>
          <Typography
            variant="body1"
            sx={{
              textTransform: "capitalize",
              color: "inactive.main",
              pl: { lg: "33px" },
            }}
          >
            {data.status}
          </Typography>
        </Grid>

        <Grid
          item
          xs={6}
          lg={3}
          sx={{ textAlign: { xs: "right", lg: "center" } }}
        >
          <Typography
            variant="body1"
            sx={{
              textTransform: "capitalize",
              color: "inactive.main",
              pl: "18px",
            }}
          >
            {progress.toFixed(2)}%
          </Typography>
        </Grid>

        <Grid
          item
          xs={12}
          lg={1}
          sx={{ textAlign: { xs: "center", lg: "right" } }}
        >
          <Typography
            onClick={() =>
              navigate(`${MANAGER_GOAL_DETAILS_ROUTE}/${data.id}`, {
                state: {
                  data: {
                    userName: userInfo.userName,
                    userImg: userInfo.userImg,
                  },
                },
              })
            }
            variant="body1"
            style={{
              color: "#66c1ff",
              textDecoration: "1px underline",
              pointerEvents: "auto",
              cursor: "pointer",
            }}
          >
            Overview
          </Typography>
        </Grid>
      </Grid>
    </StyledDarkWrapper>
  );
};

export default GoalTableRow;
