import { useState } from "react";
import DefaultLayout from "../../../ui/DefaultLayout";
import { Outlet } from "react-router-dom";
import { moderatorSidebarData } from "../../../data/sidebarData";

const Moderator = () => {
  const [title, setTitle] = useState("Moderator");
  return (
    <DefaultLayout sidebarData={moderatorSidebarData} title={title}>
      <Outlet context={[title, setTitle]} />
    </DefaultLayout>
  );
};

export default Moderator;
