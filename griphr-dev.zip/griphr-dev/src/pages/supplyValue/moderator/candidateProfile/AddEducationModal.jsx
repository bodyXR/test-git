import { useDispatch } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { useFormik } from "formik";
import { Box, Stack } from "@mui/material";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../components/styled/StyledDarkOutlinedBtn";
import CandidateEducationInfo from "./CandidateEducationInfo";
import { addEducationValidationSchema } from "./addEducationValidationSchema";
import { useEffect } from "react";
import {
  addEducation,
  editEducation,
  getEducation,
} from "../../../../redux/slices/moderator/candidate/candidateActions";
import moment from "moment";
import { unwrapResult } from "@reduxjs/toolkit";

const AddEducationModal = ({
  onClose,
  candidateId,
  data,
  editMode = false,
}) => {
  const dispatch = useDispatch();
  const { id, degree, institution, start_date, end_date, level } = data || {};

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    formik.setValues({
      degree: degree || "",
      institution: institution || "",
      start_date: start_date ? new Date(start_date) : null,
      end_date: end_date ? new Date(end_date) : null,
      level: level || "",
    });
  }, [data]);

  const initialValues = {
    degree: "",
    institution: "",
    start_date: null,
    end_date: null,
    level: "",
  };

  const formik = useFormik({
    initialValues,
    validationSchema: addEducationValidationSchema,
    onSubmit: async (values) => {
      // Convert start_date and end_date and filter out empty values
      const filteredValues = Object.fromEntries(
        Object.entries(values)
          .map(([key, value]) => {
            if (key === "start_date" || key === "end_date") {
              return [key, moment(value).format("YYYY-MM-DD")];
            }
            return [key, value];
          })
          .filter(([key, value]) => value)
      );
      try {
        if (editMode) {
          const editEducationResult = await dispatch(
            editEducation({ ...filteredValues, id })
          );
          await unwrapResult(editEducationResult);
          const getEducationResult = await dispatch(getEducation(+candidateId));
          await unwrapResult(getEducationResult);
          handleClickSnackbar("Education updated successfully", "success");
        } else {
          const addEducationResult = await dispatch(
            addEducation({ ...filteredValues, user_id: +candidateId })
          );
          await unwrapResult(addEducationResult);
          const getEducationResult = await dispatch(getEducation(+candidateId));
          await unwrapResult(getEducationResult);
          handleClickSnackbar("Education added successfully", "success");
        }
        onClose();
      } catch (error) {
        console.log(error);
        handleClickSnackbar(error, "error");
      }
    },
  });

  return (
    <Box
      sx={{ display: "flex", flexDirection: "column", gap: { xs: 3 } }}
      component={"form"}
      onSubmit={formik.handleSubmit}
    >
      <CandidateEducationInfo formik={formik} />
      <Stack sx={{ flexDirection: { lg: "row" }, p: { xs: 2, lg: 0 } }} gap={1}>
        <StyledDarkBtn min_width={172} type="submit">
          Finish
        </StyledDarkBtn>
        <StyledDarkOutlinedBtn min_width={172} onClick={onClose}>
          Cancel
        </StyledDarkOutlinedBtn>
      </Stack>
    </Box>
  );
};

export default AddEducationModal;
