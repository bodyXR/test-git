import { useDispatch } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { useFormik } from "formik";
import { Box, Stack } from "@mui/material";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../components/styled/StyledDarkOutlinedBtn";
import CandidateWorkInfo from "./CandidateExperienceInfo";
import { addExperienceValidationSchema } from "./addExperienceValidationSchema";
import { useEffect } from "react";
import {
  addExperience,
  editExperience,
  getExperience,
} from "../../../../redux/slices/moderator/candidate/candidateActions";
import moment from "moment";
import { unwrapResult } from "@reduxjs/toolkit";

const AddExperienceModal = ({
  onClose,
  candidateId,
  data,
  editMode = false,
}) => {
  const dispatch = useDispatch();
  const { id, title, company, start_date, end_date, is_current } = data || {};

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    formik.setValues({
      title: title || "",
      company: company || "",
      start_date: start_date ? new Date(start_date) : null,
      end_date: is_current ? null : end_date ? new Date(end_date) : null,
      is_current: is_current || false,
    });
  }, [data]);

  const initialValues = {
    title: "",
    company: "",
    start_date: null,
    end_date: null,
    is_current: false,
  };

  const formik = useFormik({
    initialValues,
    validationSchema: addExperienceValidationSchema,
    onSubmit: async (values) => {
      // Ensure end_date is null if is_current is true
      if (values.is_current) {
        values.end_date = null;
      }

      // Convert start_date and end_date and filter out empty values
      const filteredValues = Object.fromEntries(
        Object.entries(values)
          .map(([key, value]) => {
            if (key === "start_date" || key === "end_date") {
              return [key, value ? moment(value).format("YYYY-MM-DD") : null];
            }
            return [key, value];
          })
          .filter(([key, value]) => value !== null)
      );
      try {
        if (editMode) {
          const editExperienceResult = await dispatch(
            editExperience({ ...filteredValues, id })
          );
          await unwrapResult(editExperienceResult);
          const getExperienceResult = await dispatch(
            getExperience(+candidateId)
          );
          await unwrapResult(getExperienceResult);
          handleClickSnackbar("Experience updated successfully", "success");
        } else {
          const addExperienceResult = await dispatch(
            addExperience({ ...filteredValues, user_id: +candidateId })
          );
          await unwrapResult(addExperienceResult);
          const getExperienceResult = await dispatch(
            getExperience(+candidateId)
          );
          await unwrapResult(getExperienceResult);
          handleClickSnackbar("Experience added successfully", "success");
        }
        onClose();
      } catch (error) {
        console.log(error);
        handleClickSnackbar(error, "error");
      }
    },
  });

  // Use an effect to update the end date value if is_current is true
  useEffect(() => {
    if (formik.values.is_current) {
      formik.setFieldValue("end_date", null);
    }
  }, [formik.values.is_current]); // Run the effect only when is_current changes

  return (
    <Box
      sx={{ display: "flex", flexDirection: "column", gap: { xs: 3 } }}
      component={"form"}
      onSubmit={formik.handleSubmit}
    >
      <CandidateWorkInfo formik={formik} />
      <Stack sx={{ flexDirection: { lg: "row" }, p: { xs: 2, lg: 0 } }} gap={1}>
        <StyledDarkBtn min_width={172} type="submit">
          Finish
        </StyledDarkBtn>
        <StyledDarkOutlinedBtn min_width={172} onClick={onClose}>
          Cancel
        </StyledDarkOutlinedBtn>
      </Stack>
    </Box>
  );
};

export default AddExperienceModal;
