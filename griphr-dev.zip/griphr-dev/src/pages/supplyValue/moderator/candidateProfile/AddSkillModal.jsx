import { useCallback, useEffect, useState } from "react";
import {
  Autocomplete,
  Box,
  CircularProgress,
  IconButton,
  InputAdornment,
  Stack,
  TextField,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../components/styled/StyledDarkOutlinedBtn";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { useFormik } from "formik";
import { addSkillValidationSchema } from "./addSkillValidationSchema";
import {
  addSkill,
  getSkills,
} from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";
import axiosInstance from "../../../../helper/axiosInstance";
import { debounce } from "lodash";

const AddSkillModal = ({ onClose, candidateId }) => {
  const [value, setValue] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const noSkillsMatch = "No skills match";

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const initialValues = {
    skill_id: "",
  };

  const formik = useFormik({
    initialValues,
    validationSchema: addSkillValidationSchema,
    onSubmit: async (values, { setSubmitting }) => {
      if (values.skill_id === null || values.skill_id === noSkillsMatch) {
        // Handle "No skills match" validation
        formik.setFieldError("skill_id", "Please select a valid skill");
        setSubmitting(false);
        return;
      }

      try {
        const addSkillResult = await dispatch(
          addSkill({
            skill_id: values.skill_id,
            level: 1,
            user_id: +candidateId,
          })
        );
        unwrapResult(addSkillResult);
        const getSkillsResult = await dispatch(getSkills(+candidateId));
        unwrapResult(getSkillsResult);
        handleClickSnackbar("Skill added successfully", "success");
        onClose();
      } catch (error) {
        console.log(error);
        handleClickSnackbar(error, "error");
      }
    },
  });

  const searchSkills = useCallback(
    async (token, value) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `search`,
          {
            key: "skill",
            value: value,
          },
          config
        );
        console.log(response.data);
        setOptions(response.data.payload);
      } catch (error) {
        console.log(error?.response?.data?.message);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const debouncedSearchSkills = useCallback(
    debounce((token, inputValue) => {
      if (inputValue !== "") {
        searchSkills(token, inputValue);
      } else {
        setOptions([]);
      }
    }, 1000),
    []
  );

  useEffect(() => {
    debouncedSearchSkills(token, inputValue);
  }, [debouncedSearchSkills, token, inputValue]);

  const selectValue = useCallback(
    (e, optionName) => {
      const selectedOption = options.find(
        (option) => option.name === optionName
      );

      if (selectedOption) {
        formik.setFieldValue("skill_id", selectedOption.id);
      } else {
        formik.setFieldValue("skill_id", "");
      }
    },
    [formik, options]
  );

  const handleSearch = useCallback(
    async (event) => {
      event.preventDefault();
      formik.handleSubmit(); // Submit the form

      if (formik.values.skill === noSkillsMatch) {
        return;
      }

      // Call the searchSkills function here
      await searchSkills(token, formik.values.skill);
    },
    [searchSkills, token, formik]
  );

  const handleInputChange = (event, newValue) => {
    setInputValue(newValue);
  };

  return (
    <Box
      sx={{ display: "flex", flexDirection: "column", gap: { xs: 3 } }}
      component={"form"}
      onSubmit={handleSearch}
    >
      <Stack sx={{ p: { xs: 2, lg: 0 }, gap: { xs: 2.5 } }}>
        <Autocomplete
          freeSolo
          id="skill_id"
          name="skill_id"
          value={value}
          options={
            options.length < 1
              ? [noSkillsMatch].map((option) => option)
              : options.map((option) => option.name)
          }
          inputValue={inputValue}
          onInputChange={handleInputChange}
          onBlur={formik.handleBlur}
          onChange={(e, value) => selectValue(e, value)}
          label="Search input"
          sx={{ background: "white", mt: "16px" }}
          renderInput={(params) => (
            <TextField
              error={formik.touched.skill_id && Boolean(formik.errors.skill_id)}
              helperText={formik.touched.skill_id ? formik.errors.skill_id : ""}
              name="skill_id"
              fullWidth
              placeholder="Search Skill"
              {...params}
              type="search"
              InputProps={{
                ...params.InputProps,
                startAdornment: (
                  <InputAdornment position="start">
                    <IconButton>
                      <SearchIcon />
                    </IconButton>
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <div style={{ display: "flex", alignItems: "center" }}>
                      {params.InputProps.endAdornment}
                      {loading && <CircularProgress size={20} />}
                    </div>
                  </InputAdornment>
                ),
              }}
            />
          )}
        />
      </Stack>
      <Stack sx={{ flexDirection: { lg: "row" }, p: { xs: 2, lg: 0 } }} gap={1}>
        <StyledDarkBtn min_width={172} type="submit">
          Finish
        </StyledDarkBtn>
        <StyledDarkOutlinedBtn min_width={172} onClick={onClose}>
          Cancel
        </StyledDarkOutlinedBtn>
      </Stack>
    </Box>
  );
};

export default AddSkillModal;
