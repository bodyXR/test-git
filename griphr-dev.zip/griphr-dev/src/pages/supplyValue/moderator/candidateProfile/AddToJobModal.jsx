import {
  Autocomplete,
  Box,
  CircularProgress,
  IconButton,
  InputAdornment,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import React, { useCallback, useEffect, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import CancelIcon from "@mui/icons-material/Cancel";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../../helper/axiosInstance";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { useFormik } from "formik";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../components/styled/StyledDarkOutlinedBtn";
import { addToJobValidationSchema } from "./addToJobValidationSchema";
import { addToJobList } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { debounce } from "lodash";
import { bulkAddToJobList } from "../../../../redux/slices/moderator/searchCandidate/searchCandidateActions";

const AddToJobModal = ({ onClose, candidateId, bulkActionMode = false }) => {
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [selectedJobs, setSelectedJobs] = useState([]);
  const { selectedCandidates } = useSelector((state) => state.candidatesList);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const initialValues = {
    role_ids: [],
  };

  const formik = useFormik({
    initialValues,
    validationSchema: addToJobValidationSchema,
    onSubmit: async (values) => {
      const roleIds = selectedJobs.map((job) => job.id);
      formik.setFieldValue("role_ids", roleIds);
      setSelectedJobs([]);
      try {
        if (bulkActionMode) {
          const bulkAddToJobListResult = await dispatch(
            bulkAddToJobList({
              job_vacancy_ids: values.role_ids,
              user_ids: selectedCandidates,
            })
          );
          await unwrapResult(bulkAddToJobListResult);
        } else {
          const addToJobListResult = await dispatch(
            addToJobList({
              job_vacancy_ids: values.role_ids,
              user_id: +candidateId,
            })
          );
          await unwrapResult(addToJobListResult);
        }
        handleClickSnackbar("Candidate added successfully", "success");
        onClose();
      } catch (error) {
        console.log(error);
        handleClickSnackbar(error || "Fail to Add Candidate to Job", "error");
      }
    },
  });

  const handleInputChange = (event, newValue) => {
    setSearchQuery(newValue);
  };

  const searchJobs = useCallback(
    async (token, value) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `search`,
          {
            key: "job_vacancy",
            value,
          },
          config
        );

        setSearchResults(response?.data?.payload || []);
      } catch (error) {
        console.error("Error searching jobs:", error);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const debouncedSearchJobs = useCallback(
    debounce((token, searchQuery) => {
      if (searchQuery !== "") {
        searchJobs(token, searchQuery);
      } else {
        setSearchResults([]);
      }
    }, 1000),
    []
  );

  useEffect(() => {
    debouncedSearchJobs(token, searchQuery);
  }, [debouncedSearchJobs, token, searchQuery]);

  return (
    <Box
      sx={{ display: "flex", flexDirection: "column", gap: { xs: 3 } }}
      component={"form"}
      onSubmit={formik.handleSubmit}
    >
      <Stack sx={{ p: { xs: 2, lg: 0 }, gap: { xs: 2.5 } }}>
        <Typography variant="body1" color="inactive.main">
          Select one or more jobs to add this candidate to
        </Typography>
        <Autocomplete
          multiple
          id="search_jobs"
          options={searchResults.filter(
            (option) => !selectedJobs.some((job) => job.id === option.id)
          )}
          getOptionLabel={(option) => option.title}
          value={selectedJobs}
          onChange={(event, newValue) => {
            setSelectedJobs(newValue);
            const roleIds = newValue.map((job) => job.id);
            formik.setFieldValue("role_ids", roleIds);
          }}
          inputValue={searchQuery}
          onInputChange={handleInputChange}
          disableCloseOnSelect
          sx={{ background: "white" }}
          renderInput={(params) => (
            <TextField
              {...params}
              fullWidth
              label="Search jobs"
              placeholder="Search Jobs"
              error={formik.touched.role_ids && Boolean(formik.errors.role_ids)}
              helperText={formik.touched.role_ids && formik.errors.role_ids}
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton>
                      <SearchIcon />
                    </IconButton>
                    {loading && <CircularProgress size={20} />}
                  </InputAdornment>
                ),
              }}
            />
          )}
          renderTags={(value, getTagProps) =>
            value.map((option, index) => (
              <Typography
                key={index}
                variant="body1"
                component="div"
                sx={{
                  display: "flex",
                  alignItems: "center",
                  padding: 1,
                  backgroundColor: "#f0f0f0",
                  borderRadius: "5px",
                  marginRight: "5px",
                }}
                {...getTagProps({ index })}
              >
                {option.title}
                <IconButton
                  size="small"
                  onClick={() => {
                    const newValue = [...selectedJobs];
                    newValue.splice(index, 1);
                    setSelectedJobs(newValue);
                    const roleIds = newValue.map((job) => job.id);
                    formik.setFieldValue("role_ids", roleIds);
                  }}
                >
                  <CancelIcon fontSize="small" />
                </IconButton>
              </Typography>
            ))
          }
          renderOption={(props, option) => (
            <li {...props}>
              <Typography variant="body1">{option.title}</Typography>
            </li>
          )}
        />
        <Stack
          sx={{ flexDirection: { lg: "row" }, p: { xs: 2, lg: 0 } }}
          gap={1}
        >
          <StyledDarkBtn min_width={172} type="submit">
            Confirm
          </StyledDarkBtn>
          <StyledDarkOutlinedBtn min_width={172} onClick={onClose}>
            Cancel
          </StyledDarkOutlinedBtn>
        </Stack>
      </Stack>
    </Box>
  );
};

export default AddToJobModal;
