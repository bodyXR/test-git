import {
  Autocomplete,
  Box,
  CircularProgress,
  IconButton,
  InputAdornment,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import React, { useCallback, useEffect, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import CancelIcon from "@mui/icons-material/Cancel";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../../helper/axiosInstance";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { useFormik } from "formik";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../components/styled/StyledDarkOutlinedBtn";
import { addToTalentValidationSchema } from "./addToTalentValidationSchema";
import { addToTalentPool } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { debounce } from "lodash";
import { bulkAddToTalentPool } from "../../../../redux/slices/moderator/searchCandidate/searchCandidateActions";

const AddToTalentModal = ({ onClose, candidateId, bulkActionMode = false }) => {
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [selectedPools, setSelectedPools] = useState([]);
  const { selectedCandidates } = useSelector((state) => state.candidatesList);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const initialValues = {
    pool_ids: [],
  };

  const formik = useFormik({
    initialValues,
    validationSchema: addToTalentValidationSchema,
    onSubmit: async (values) => {
      const poolIds = selectedPools.map((pool) => pool.id);
      formik.setFieldValue("pool_ids", poolIds);
      setSelectedPools([]);
      try {
        if (bulkActionMode) {
          const bulkAddToTalentPoolResult = await dispatch(
            bulkAddToTalentPool({
              pool_ids: values.pool_ids,
              user_ids: selectedCandidates,
            })
          );
          await unwrapResult(bulkAddToTalentPoolResult);
        } else {
          const addToTalentPoolResult = await dispatch(
            addToTalentPool({ pool_ids: values.pool_ids, user_id: candidateId })
          );
          await unwrapResult(addToTalentPoolResult);
        }
        handleClickSnackbar("Candidate added successfully", "success");
        onClose();
      } catch (error) {
        console.log(error);
        handleClickSnackbar(
          error || "Fail to Add Candidate to Talent Pool",
          "error"
        );
      }
    },
  });

  const handleInputChange = (event, newValue) => {
    setSearchQuery(newValue);
  };

  const searchPools = useCallback(
    async (token, value) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `search`,
          {
            key: "talent_pools",
            value,
          },
          config
        );

        setSearchResults(response?.data?.payload || []);
      } catch (error) {
        console.error("Error searching pools:", error);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const debouncedSearchPools = useCallback(
    debounce((token, searchQuery) => {
      if (searchQuery !== "") {
        searchPools(token, searchQuery);
      } else {
        setSearchResults([]);
      }
    }, 1000),
    []
  );

  useEffect(() => {
    debouncedSearchPools(token, searchQuery);
  }, [debouncedSearchPools, token, searchQuery]);

  return (
    <Box
      sx={{ display: "flex", flexDirection: "column", gap: { xs: 3 } }}
      component={"form"}
      onSubmit={formik.handleSubmit}
    >
      <Stack sx={{ p: { xs: 2, lg: 0 }, gap: { xs: 2.5 } }}>
        <Typography variant="body1" color="inactive.main">
          Select one or more talent pools to add this candidate to
        </Typography>
        <Autocomplete
          multiple
          id="search_pools"
          options={searchResults.filter(
            (option) => !selectedPools.some((pool) => pool.id === option.id)
          )}
          getOptionLabel={(option) => option.name}
          value={selectedPools}
          onChange={(event, newValue) => {
            setSelectedPools(newValue);
            const poolIds = newValue.map((pool) => pool.id);
            formik.setFieldValue("pool_ids", poolIds);
          }}
          inputValue={searchQuery}
          onInputChange={handleInputChange}
          disableCloseOnSelect
          sx={{ background: "white" }}
          renderInput={(params) => (
            <TextField
              {...params}
              fullWidth
              label="Search pools"
              placeholder="Search Pools"
              error={formik.touched.pool_ids && Boolean(formik.errors.pool_ids)}
              helperText={formik.touched.pool_ids && formik.errors.pool_ids}
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton>
                      <SearchIcon />
                    </IconButton>
                    {loading && <CircularProgress size={20} />}
                  </InputAdornment>
                ),
              }}
            />
          )}
          renderTags={(value, getTagProps) =>
            value.map((option, index) => (
              <Typography
                key={index}
                variant="body1"
                component="div"
                sx={{
                  display: "flex",
                  alignItems: "center",
                  padding: 1,
                  backgroundColor: "#f0f0f0",
                  borderRadius: "5px",
                  marginRight: "5px",
                }}
                {...getTagProps({ index })}
              >
                {option.name}
                <IconButton
                  size="small"
                  onClick={() => {
                    const newValue = [...selectedPools];
                    newValue.splice(index, 1);
                    setSelectedPools(newValue);
                    const poolIds = newValue.map((pool) => pool.id);
                    formik.setFieldValue("pool_ids", poolIds);
                  }}
                >
                  <CancelIcon fontSize="small" />
                </IconButton>
              </Typography>
            ))
          }
          renderOption={(props, option) => (
            <li {...props}>
              <Typography variant="body1">{option.name}</Typography>
            </li>
          )}
        />
        <Stack
          sx={{ flexDirection: { lg: "row" }, p: { xs: 2, lg: 0 } }}
          gap={1}
        >
          <StyledDarkBtn min_width={172} type="submit">
            Confirm
          </StyledDarkBtn>
          <StyledDarkOutlinedBtn min_width={172} onClick={onClose}>
            Cancel
          </StyledDarkOutlinedBtn>
        </Stack>
      </Stack>
    </Box>
  );
};

export default AddToTalentModal;
