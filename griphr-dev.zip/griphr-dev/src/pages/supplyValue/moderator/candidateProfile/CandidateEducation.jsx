import StyledWrapper from "../../../../components/styled/StyledWrapper";
import { CircularProgress, Stack, Typography } from "@mui/material";
import { useParams } from "react-router-dom";
import useModal from "../../../../hooks/useModal";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { useEffect } from "react";
import { getEducation } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";
import CustomModal from "../../../../ui/CustomModal";
import AddEducationModal from "./AddEducationModal";
import StyledLightBtn from "../../../../components/styled/StyledLightBtn";
import EmptyEducationMessage from "./EmptyEducationMessage";
import EducationItem from "./EducationItem";

const CandidateEducation = () => {
  const { candidateId } = useParams();
  const { handleClose, handleOpen, open } = useModal();
  const {
    education,
    isLoadingGetEducation,
    isErrorGetEducation,
    isSuccessGetEducation,
  } = useSelector((state) => state.candidate);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    const fetchEducation = async (id) => {
      try {
        const res = await dispatch(getEducation(id));
        await unwrapResult(res);
        handleClickSnackbar("Education fetched successfully", "success");
      } catch (error) {
        console.log("error", error);
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch education data.",
          "error"
        );
      }
    };
    fetchEducation(candidateId);
  }, []);

  return (
    <>
      <CustomModal onClose={handleClose} open={open} title="Education">
        <AddEducationModal onClose={handleClose} candidateId={candidateId} />
      </CustomModal>
      <StyledWrapper sx={{ gap: 2, flex: 1 }}>
        <Typography variant="h3" color="darkGreen">
          Education
        </Typography>

        {isErrorGetEducation && (
          <Typography variant="h3">Error fetching education!</Typography>
        )}
        {isLoadingGetEducation && <CircularProgress size={20} />}
        {isSuccessGetEducation && (
          <>
            <Stack
              sx={{
                height: "142px",
                maxHeight: "142px",
                overflowY: education?.length > 0 ? "auto" : "initial",
                pr: 2,
              }}
            >
              {education?.length > 0 ? (
                education?.map((edu, index) => (
                  <EducationItem
                    key={index}
                    data={edu}
                    isLast={index === education.length - 1}
                  />
                ))
              ) : (
                <EmptyEducationMessage handleOpen={handleOpen} />
              )}
            </Stack>
            {education?.length > 0 && (
              <StyledLightBtn onClick={handleOpen} sx={{ mt: "auto" }}>
                Add new education +
              </StyledLightBtn>
            )}
          </>
        )}
      </StyledWrapper>
    </>
  );
};

export default CandidateEducation;
