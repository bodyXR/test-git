import React from "react";
import { Stack, Typography } from "@mui/material";
import StyledTextField from "../../../../components/styled/StyledTextField";
import StyledDatePicker from "../../../../components/styled/StyledDatePicker";
import Grid from "@mui/material/Unstable_Grid2";

const CandidateEducationInfo = ({ formik }) => {
  return (
    <Stack sx={{ p: { xs: 2, lg: 0 }, gap: { xs: 2.5 } }}>
      <Grid container spacing={2.5}>
        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="degree"
              name="degree"
              variant="outlined"
              placeholder="Degree"
              label="Degree"
              type="text"
              required
              value={formik.values.degree}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.degree ? formik.errors.degree : ""}
              error={formik.touched.degree && Boolean(formik.errors.degree)}
              sx={{ background: "white" }}
            />
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="institution"
              name="institution"
              variant="outlined"
              placeholder="Institution"
              label="Institution"
              type="text"
              required
              value={formik.values.institution}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.institution ? formik.errors.institution : ""
              }
              error={
                formik.touched.institution && Boolean(formik.errors.institution)
              }
              sx={{ background: "white" }}
            />
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledDatePicker
              label="Start date *"
              value={formik.values.start_date}
              onChange={(value) => {
                formik.setFieldValue("start_date", value);
              }}
              slot={(params) => (
                <StyledTextField
                  {...params}
                  error={Boolean(
                    formik.touched.start_date && formik.errors.start_date
                  )}
                  helperText={
                    formik.touched.start_date && formik.errors.start_date
                  }
                  id="start_date"
                  name="start_date"
                />
              )}
              sx={{
                flex: 1,
                background: "white",
                "& .MuiInputBase-input": {
                  paddingTop: "17.5px",
                  paddingBottom: "17.5px",
                },
              }}
            />

            {formik.touched.start_date && formik.errors.start_date ? (
              <Typography
                sx={{
                  color: "#d32f2f",
                  mx: "14px",
                  mt: "3px",
                  fontSize: "0.8571428571428571rem",
                }}
              >
                {formik.errors.start_date}
              </Typography>
            ) : null}
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledDatePicker
              label="End date *"
              value={formik.values.end_date}
              onChange={(value) => {
                formik.setFieldValue("end_date", value);
              }}
              slot={(params) => (
                <StyledTextField
                  {...params}
                  error={Boolean(
                    formik.touched.end_date && formik.errors.end_date
                  )}
                  helperText={formik.touched.end_date && formik.errors.end_date}
                  id="end_date"
                  name="end_date"
                />
              )}
              sx={{
                flex: 1,
                background: "white",
                "& .MuiInputBase-input": {
                  paddingTop: "17.5px",
                  paddingBottom: "17.5px",
                },
              }}
            />

            {formik.touched.end_date && formik.errors.end_date ? (
              <Typography
                sx={{
                  color: "#d32f2f",
                  mx: "14px",
                  mt: "3px",
                  fontSize: "0.8571428571428571rem",
                }}
              >
                {formik.errors.end_date}
              </Typography>
            ) : null}
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="level"
              name="level"
              variant="outlined"
              placeholder="Level"
              label="Level"
              type="text"
              required
              value={formik.values.level}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.level ? formik.errors.level : ""}
              error={formik.touched.level && Boolean(formik.errors.level)}
              sx={{ background: "white" }}
            />
          </Stack>
        </Grid>
      </Grid>
    </Stack>
  );
};

export default CandidateEducationInfo;
