import React from "react";
import { Stack, Typography } from "@mui/material";
import StyledTextField from "../../../../components/styled/StyledTextField";
import StyledFilterLabel from "../../../../components/styled/StyledFilterLabel";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";
import StyledDatePicker from "../../../../components/styled/StyledDatePicker";
import Grid from "@mui/material/Unstable_Grid2";

const CandidateExperienceInfo = ({ formik }) => {
  return (
    <Stack sx={{ p: { xs: 2, lg: 0 }, gap: { xs: 2.5 } }}>
      <Grid container spacing={2.5}>
        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="title"
              name="title"
              variant="outlined"
              placeholder="Position"
              label="Position"
              type="text"
              required
              value={formik.values.title}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.title ? formik.errors.title : ""}
              error={formik.touched.title && Boolean(formik.errors.title)}
              sx={{ background: "white" }}
            />
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="company"
              name="company"
              variant="outlined"
              placeholder="Company"
              label="Company"
              type="text"
              required
              value={formik.values.company}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.company ? formik.errors.company : ""}
              error={formik.touched.company && Boolean(formik.errors.company)}
              sx={{ background: "white" }}
            />
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledDatePicker
              label="Start date *"
              value={formik.values.start_date}
              onChange={(value) => {
                formik.setFieldValue("start_date", value);
              }}
              slot={(params) => (
                <StyledTextField
                  {...params}
                  error={Boolean(
                    formik.touched.start_date && formik.errors.start_date
                  )}
                  helperText={
                    formik.touched.start_date && formik.errors.start_date
                  }
                  id="start_date"
                  name="start_date"
                />
              )}
              sx={{
                flex: 1,
                background: "white",
                "& .MuiInputBase-input": {
                  paddingTop: "17.5px",
                  paddingBottom: "17.5px",
                },
              }}
            />

            {formik.touched.start_date && formik.errors.start_date ? (
              <Typography
                sx={{
                  color: "#d32f2f",
                  mx: "14px",
                  mt: "3px",
                  fontSize: "0.8571428571428571rem",
                }}
              >
                {formik.errors.start_date}
              </Typography>
            ) : null}
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledDatePicker
              label="End date *"
              value={formik.values.end_date}
              onChange={(value) => {
                formik.setFieldValue("end_date", value);
              }}
              slot={(params) => (
                <StyledTextField
                  {...params}
                  error={Boolean(
                    formik.touched.end_date && formik.errors.end_date
                  )}
                  helperText={formik.touched.end_date && formik.errors.end_date}
                  id="end_date"
                  name="end_date"
                />
              )}
              sx={{
                flex: 1,
                background: "white",
                "& .MuiInputBase-input": {
                  paddingTop: "17.5px",
                  paddingBottom: "17.5px",
                },
              }}
            />

            {formik.touched.end_date && formik.errors.end_date ? (
              <Typography
                sx={{
                  color: "#d32f2f",
                  mx: "14px",
                  mt: "3px",
                  fontSize: "0.8571428571428571rem",
                }}
              >
                {formik.errors.end_date}
              </Typography>
            ) : null}
          </Stack>
        </Grid>
      </Grid>

      <StyledFilterLabel
        sx={{ ml: 0 }}
        control={<StyledFilterCheckbox checked={formik.values.is_current} />}
        label="Current job"
        name="is_current"
        onChange={formik.handleChange}
      />
    </Stack>
  );
};

export default CandidateExperienceInfo;
