import { Box, IconButton, Stack, Typography } from "@mui/material";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import { useDispatch, useSelector } from "react-redux";
import edit_inactive from "../../../../assets/edit_inactive.svg";
import ResumeDropContainer from "../components/ResumeDropContainer";
import call_inactive from "../../../../assets/call_inactive.svg";
import mail_inactive from "../../../../assets/mail_inactive.svg";
import role_inactive from "../../../../assets/role_inactive.svg";
import dollar_icon from "../../../../assets/dollar_icon.svg";
import date_inactive from "../../../../assets/date_inactive.svg";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../components/styled/StyledDarkOutlinedBtn";
import CustomModal from "../../../../ui/CustomModal";
import useModal from "../../../../hooks/useModal";
import EditCandidateModal from "./EditCandidateModal";
import { useEffect } from "react";
import { getCandidate } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { useParams } from "react-router-dom";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { unwrapResult } from "@reduxjs/toolkit";
import AddToJobModal from "./AddToJobModal";
import AddToTalentModal from "./AddToTalentModal";
import PhotoDropContainer from "../components/PhotoDropContainer";

const fileTypes = {
  "application/pdf": [".pdf"],
  "application/msword": [".doc"],
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [
    ".docx",
  ],
};

const CandidatePersonalInfo = () => {
  const { candidateId: id } = useParams();
  const dispatch = useDispatch();
  const {
    candidate,
    isLoadingGetCandidate,
    isErrorGetCandidate,
    isSuccessGetCandidate,
  } = useSelector((state) => state.candidate);
  const {
    phone,
    email,
    system_role,
    hourly_rate,
    availability,
    first_name,
    last_name,
  } = candidate;
  const candidateProfile = [
    { phone, img: call_inactive },
    { email, img: mail_inactive },
    { system_role, img: role_inactive },
    { hourly_rate, img: dollar_icon },
    { availability, img: date_inactive },
  ];

  const { handleClose, handleOpen, open } = useModal();
  const {
    handleClose: handleAddToJobClose,
    handleOpen: handleAddToJobOpen,
    open: addToJobOpen,
  } = useModal();
  const {
    handleClose: handleAddToTalentClose,
    handleOpen: handleAddToTalentOpen,
    open: addToTalentOpen,
  } = useModal();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    const fetchCandidate = async (id) => {
      try {
        const res = await dispatch(getCandidate(id));
        await unwrapResult(res);
        handleClickSnackbar("Candidate fetched successfully", "success");
      } catch (error) {
        console.log("error", error);
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch candidate data.",
          "error"
        );
      }
    };
    fetchCandidate(id);
  }, []);

  return (
    <>
      <CustomModal
        onClose={handleClose}
        open={open}
        title="Edit personal info"
        height="95%"
      >
        <EditCandidateModal onClose={handleClose} />
      </CustomModal>
      <CustomModal
        onClose={handleAddToJobClose}
        open={addToJobOpen}
        title="Add to job list"
      >
        <AddToJobModal onClose={handleAddToJobClose} candidateId={id} />
      </CustomModal>
      <CustomModal
        onClose={handleAddToTalentClose}
        open={addToTalentOpen}
        title="Add to talent pool"
      >
        <AddToTalentModal onClose={handleAddToTalentClose} candidateId={id} />
      </CustomModal>
      <StyledWrapper sx={{ gap: 2.5, position: "relative" }}>
        <IconButton
          sx={{
            position: "absolute",
            right: 0,
            top: 0,
          }}
          onClick={handleOpen}
        >
          <Box
            component={"img"}
            sx={{ width: "20px", height: "20px" }}
            src={edit_inactive}
          />
        </IconButton>

        <Stack sx={{ gap: 3 }}>
          <Stack
            sx={{
              flexDirection: { xs: "column", lg: "row" },
              mx: "auto",
            }}
          >
            <PhotoDropContainer />
          </Stack>
          <Stack>
            <Typography
              variant="h3"
              sx={{
                textTransform: "capitalize",
                color: "darkGreen",
              }}
            >{`${first_name || "Unknown"} ${
              last_name || "Unknwon"
            }`}</Typography>

            <Typography
              variant="h4"
              sx={{
                textTransform: "capitalize",
                color: "inactive.main",
              }}
            >
              {/* TODO: Change condition  */}
              {candidate?.role?.title && candidate?.role?.title !== "0"
                ? candidate?.role?.title
                : "No Title"}
            </Typography>
          </Stack>
        </Stack>

        <ResumeDropContainer
          title={"CV-Resume.pdf"}
          fileTypes={fileTypes}
          name={"file"}
          profilePageMode
        />

        <Stack sx={{ gap: { xs: 1.5 } }}>
          {candidateProfile?.map((item, index) => {
            const firstValue = Object.values(item)[0];
            const firstKey = Object.keys(item)[0];
            const unit =
              firstKey === "hourly_rate"
                ? "/h"
                : firstKey === "availability"
                ? "hr/week"
                : "";
            return (
              <Stack
                key={index}
                sx={{ flexDirection: "row", alignItems: "center", gap: 1.75 }}
              >
                <Box
                  component={"img"}
                  sx={{ width: "20px", height: "20px" }}
                  src={item?.img}
                />

                <Typography variant="body1" color="darkGreenAccent">
                  {`${firstValue || ""} ${unit}`}
                </Typography>
              </Stack>
            );
          })}
        </Stack>

        <Stack sx={{ gap: { xs: 1 }, flexDirection: { lg: "row" } }}>
          <StyledDarkBtn onClick={handleAddToJobOpen} sx={{textTransform:"unset"}}>Add to job</StyledDarkBtn>
          <StyledDarkOutlinedBtn onClick={handleAddToTalentOpen}  sx={{textTransform:"unset"}}>
            Add to talent pool
          </StyledDarkOutlinedBtn>
        </Stack>
      </StyledWrapper>
    </>
  );
};

export default CandidatePersonalInfo;
