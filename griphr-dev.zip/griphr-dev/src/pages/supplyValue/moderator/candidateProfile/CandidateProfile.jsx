import { useLocation } from "react-router-dom";
import useTitle from "../../../../hooks/useTitle";
import { Stack } from "@mui/material";
import CandidatePersonalInfo from "./CandidatePersonalInfo";
import CandidateSkills from "./CandidateSkills";
import CandidateWork from "./CandidateWork";
import CandidateEducation from "./CandidateEducation";

const CandidateProfile = () => {
  const location = useLocation();
  useTitle(location, -2);

  return (
    <Stack
      className="candidate__profile__wrapper"
      sx={{ gap: 3, flexDirection: { lg: "row" } }}
    >
      <CandidatePersonalInfo />
      <Stack sx={{ flex: { lg: 1 }, gap: 3 }}>
        <CandidateSkills />
        <Stack sx={{ flex: { lg: 1 }, flexDirection: { lg: "row" }, gap: 3 }}>
          <CandidateWork />
          <CandidateEducation />
        </Stack>
      </Stack>
    </Stack>
  );
};

export default CandidateProfile;
