import StyledWrapper from "../../../../components/styled/StyledWrapper";
import { Button, CircularProgress, Stack, Typography } from "@mui/material";
import { useParams } from "react-router-dom";
import useModal from "../../../../hooks/useModal";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { useEffect, useState } from "react";
import { getSkills } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";
import CustomModal from "../../../../ui/CustomModal";
import AddSkillModal from "./AddSkillModal";
import StyledLightBtn from "../../../../components/styled/StyledLightBtn";
import SkillItem from "../components/SkillItem";
import EmptySkillsMessage from "./EmptySkillsMessage";
import VerifiedSkillItem from "./VerifiedSkillItem";

const CandidateSkills = () => {
  const [showAll, setShowAll] = useState(false);
  const { candidateId } = useParams();
  const { handleClose, handleOpen, open } = useModal();
  const { skills, isLoadingGetSkills, isErrorGetSkills, isSuccessGetSkills } =
    useSelector((state) => state.candidate);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    const fetchSkills = async (id) => {
      try {
        const res = await dispatch(getSkills(id));
        await unwrapResult(res);
        handleClickSnackbar("Skills fetched successfully", "success");
      } catch (error) {
        console.log("error", error);
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch skills data.",
          "error"
        );
      }
    };
    fetchSkills(candidateId);
  }, [candidateId]);

  const displayedSkills = showAll ? skills : skills?.slice(0, 10);

  return (
    <>
      <CustomModal onClose={handleClose} open={open} title="Add skill">
        <AddSkillModal onClose={handleClose} candidateId={candidateId} />
      </CustomModal>
      <StyledWrapper sx={{ gap: 2 }}>
        <Typography variant="h3" color="darkGreen">
          Skills
        </Typography>

        {isErrorGetSkills && (
          <Typography variant="h3">Error fetching work skills!</Typography>
        )}
        {isLoadingGetSkills && <CircularProgress size={20} />}
        {isSuccessGetSkills && (
          <>
            <Stack
              sx={{
                flexDirection: "row",
                justifyContent: skills?.length > 0 ? "initial" : "center",
                alignItems: "center",
                gap: "12px",
                flexWrap: "wrap",
              }}
            >
              {skills?.length > 0 ? (
                displayedSkills?.map((skill) =>
                  skill.verified ? (
                    <VerifiedSkillItem key={skill.title} data={skill} />
                  ) : (
                    <SkillItem key={skill.title} data={skill} />
                  )
                )
              ) : (
                <EmptySkillsMessage handleOpen={handleOpen} />
              )}
            </Stack>
            {skills?.length > 10 && (
              <Button
                onClick={() => setShowAll((prev) => !prev)}
                disableRipple={true}
                variant="text"
                sx={{
                  alignSelf: "flex-start",
                  textTransform: "capitalize",
                  "&: hover": {
                    backgroundColor: "transparent",
                  },
                  p: 0,
                }}
              >
                <Typography
                  variant="body1"
                  sx={{ textDecoration: "underline", color: "#66C1FF" }}
                >
                  {showAll ? "Show Less" : "Show More"}
                </Typography>
              </Button>
            )}
            {skills?.length > 0 && (
              <StyledLightBtn onClick={handleOpen} sx={{ mt: "auto" }}>
                Add new skill +
              </StyledLightBtn>
            )}
          </>
        )}
      </StyledWrapper>
    </>
  );
};

export default CandidateSkills;
