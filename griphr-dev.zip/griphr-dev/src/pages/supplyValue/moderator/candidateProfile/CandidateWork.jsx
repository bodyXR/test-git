import StyledWrapper from "../../../../components/styled/StyledWrapper";
import { CircularProgress, Stack, Typography } from "@mui/material";
import useModal from "../../../../hooks/useModal";
import CustomModal from "../../../../ui/CustomModal";
import AddExperienceModal from "./AddExperienceModal";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { getExperience } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import StyledLightBtn from "../../../../components/styled/StyledLightBtn";
import ExperienceItem from "./ExperienceItem";
import EmptyExperienceMessage from "./EmptyExperienceMessage";

const CandidateWork = () => {
  const { candidateId } = useParams();
  const { handleClose, handleOpen, open } = useModal();
  const {
    experience,
    isLoadingGetExperience,
    isErrorGetExperience,
    isSuccessGetExperience,
  } = useSelector((state) => state.candidate);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    const fetchExperience = async (id) => {
      try {
        const res = await dispatch(getExperience(id));
        await unwrapResult(res);
        handleClickSnackbar("Experience fetched successfully", "success");
      } catch (error) {
        console.log("error", error);
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch experience data.",
          "error"
        );
      }
    };
    fetchExperience(candidateId);
  }, []);

  return (
    <>
      <CustomModal onClose={handleClose} open={open} title="Work experience">
        <AddExperienceModal onClose={handleClose} candidateId={candidateId} />
      </CustomModal>
      <StyledWrapper sx={{ gap: 2, flex: 1 }}>
        <Typography variant="h3" color="darkGreen">
          Work experience
        </Typography>

        {isErrorGetExperience && (
          <Typography variant="h3">Error fetching work experience!</Typography>
        )}
        {isLoadingGetExperience && <CircularProgress size={20} />}
        {isSuccessGetExperience && (
          <>
            <Stack
              sx={{
                height: "142px",
                maxHeight: "142px",
                overflowY: experience?.length > 0 ? "auto" : "initial",
                pr: 2,
              }}
            >
              {experience?.length > 0 ? (
                experience?.map((exp, index) => (
                  <ExperienceItem
                    key={index}
                    data={exp}
                    isLast={index === experience.length - 1}
                  />
                ))
              ) : (
                <EmptyExperienceMessage handleOpen={handleOpen} />
              )}
            </Stack>
            {experience?.length > 0 && (
              <StyledLightBtn onClick={handleOpen} sx={{ mt: "auto" }}>
                Add new work experience +
              </StyledLightBtn>
            )}
          </>
        )}
      </StyledWrapper>
    </>
  );
};

export default CandidateWork;
