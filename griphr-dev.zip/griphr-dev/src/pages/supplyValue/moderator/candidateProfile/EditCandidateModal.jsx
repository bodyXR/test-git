import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { useFormik } from "formik";
import { Box, Stack } from "@mui/material";
import PersonalInformationCandidate from "../candidatesList/PersonalInformationCandidate";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../components/styled/StyledDarkOutlinedBtn";
import { useEffect } from "react";
import { editCandidateAndGetCandidateById } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";
import SearchRole from "../components/SearchRole";

const EditCandidateModal = ({ onClose }) => {
  const { candidate } = useSelector((state) => state.candidate);
  const {
    id,
    first_name,
    last_name,
    phone,
    location,
    gender,
    system_role,
    is_active,
    role,
    hourly_rate,
    experience_years,
    availability,
  } = candidate;
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const filterEmptyValues = (obj, isActive) => {
    return Object.keys(obj).reduce((acc, key) => {
      if (key === "checked" && isActive) {
        return acc;
      }
      if (obj[key] !== undefined && obj[key] !== null && obj[key] !== "") {
        acc[key] = obj[key];
      }
      return acc;
    }, {});
  };

  useEffect(() => {
    formik.setValues({
      first_name: first_name || "",
      last_name: last_name || "",
      phone: phone || "",
      location: location || "",
      gender: gender || "",
      system_role: system_role || "",
      checked: is_active ? true : false || false,
      job_profile: role?.job_profile_id || "",
      hourly_rate: hourly_rate || "",
      experience_years: experience_years || "",
      availability: availability || "",
    });
  }, [candidate]);

  const initialValues = {
    first_name: "",
    last_name: "",
    phone: "",
    location: "",
    gender: "",
    system_role: "",
    checked: false,
    job_profile: "",
    hourly_rate: "",
    experience_years: "",
    availability: "",
  };

  const formik = useFormik({
    initialValues,
    onSubmit: async (values) => {
      const filteredValues = filterEmptyValues(values, is_active);
      try {
        const editCandidateResult = await dispatch(
          editCandidateAndGetCandidateById({ ...filteredValues, id })
        );
        await unwrapResult(editCandidateResult);
        handleClickSnackbar("Candidate updated successfully", "success");
        onClose();
      } catch (error) {
        console.log(error);
        handleClickSnackbar(error, "error");
      }
    },
  });

  return (
    <Box
      sx={{ display: "flex", flexDirection: "column", gap: { xs: 3 } }}
      component={"form"}
      onSubmit={formik.handleSubmit}
    >
      <PersonalInformationCandidate formik={formik} editMode />
      <SearchRole formik={formik} editMode />
      <Stack sx={{ flexDirection: { lg: "row" } }} gap={1}>
        <StyledDarkBtn min_width={172} type="submit">
          Save
        </StyledDarkBtn>
        <StyledDarkOutlinedBtn min_width={172} onClick={onClose}>
          Cancel
        </StyledDarkOutlinedBtn>
      </Stack>
    </Box>
  );
};

export default EditCandidateModal;
