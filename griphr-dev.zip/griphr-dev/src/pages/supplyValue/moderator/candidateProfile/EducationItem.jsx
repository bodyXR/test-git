import React from "react";
import { Stack, Typography, Divider, Box, IconButton } from "@mui/material";
import edit_inactive from "../../../../assets/edit_inactive.svg";
import delete_inactive from "../../../../assets/delete_inactive.svg";
import moment from "moment";
import CustomModal from "../../../../ui/CustomModal";
import useModal from "../../../../hooks/useModal";
import AddEducationModal from "./AddEducationModal";
import { useDispatch } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { deleteEducationAndGetAll } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { useParams } from "react-router-dom";

const formatDate = (dateString) => {
  // Parse the date string using Moment.js
  const parsedDate = moment(dateString, "YYYY-MM-DD");

  // Format the parsed date to "Month Year" format
  const formattedDate = parsedDate.format("MMMM YYYY");

  return formattedDate;
};

const EducationItem = ({ data, isLast }) => {
  const { handleClose, handleOpen, open } = useModal();
  const dispatch = useDispatch();
  const { candidateId: id } = useParams();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleDeleteEducation = async (data) => {
    try {
      const deleteCandidateAndGetAllResult = await dispatch(
        deleteEducationAndGetAll(data)
      );
      await unwrapResult(deleteCandidateAndGetAllResult);
      handleClickSnackbar("Education deleted successfully", "success");
    } catch (error) {
      handleClickSnackbar(
        error?.response?.data?.message || "Fail to delete education",
        "error"
      );
    }
  };

  return (
    <>
      <CustomModal onClose={handleClose} open={open} title="Education">
        <AddEducationModal
          onClose={handleClose}
          candidateId={id}
          data={data}
          editMode
        />
      </CustomModal>
      <Stack sx={{ gap: 0.5, pb: isLast ? 0 : 2 }}>
        <Stack
          sx={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography
            variant="h5"
            title={data.degree}
            sx={{
              fontWeight: 600,
              textTransform: "capitalize",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              width: "20ch",
            }}
          >
            {data.degree}
          </Typography>
          <Stack
            className="btns__wrapper"
            sx={{ flexDirection: "row", alignItems: "center" }}
          >
            <IconButton onClick={handleOpen}>
              <Box component="img" src={edit_inactive} alt="edit icon" />
            </IconButton>
            <IconButton
              onClick={() =>
                handleDeleteEducation({
                  educationId: data.id,
                  candidateId: id,
                })
              }
            >
              <Box component="img" src={delete_inactive} alt="delete icon" />
            </IconButton>
          </Stack>
        </Stack>
        <Typography
          variant="body2"
          component="h3"
          sx={{
            color: "primary.main",
            textTransform: "capitalize",
            fontWeight: 500,
          }}
        >
          {data.institution} -{" "}
          <Typography
            variant="body2"
            component="span"
            color={"inactive.main"}
            sx={{ fontWeight: "400" }}
          >
            {formatDate(data.start_date)} - {formatDate(data.end_date)}
          </Typography>
        </Typography>
        {!isLast && <Divider sx={{ pt: 1 }} />}
      </Stack>
    </>
  );
};

export default EducationItem;
