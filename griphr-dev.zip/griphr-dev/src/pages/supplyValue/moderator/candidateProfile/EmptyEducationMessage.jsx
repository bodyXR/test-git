import React from "react";
import { Stack, Typography, Box } from "@mui/material";
import add_file_icon from "../../../../assets/add_file_icon.svg";
import AddIcon from "@mui/icons-material/Add";
import StyledGreenRoundedIconBtn from "../../../../components/styled/StyledGreenRoundedIconBtn";

const EmptyEducationMessage = ({ handleOpen }) => (
  <Stack gap={2}>
    <Box
      sx={{ width: "52px", height: "65px", alignSelf: "center" }}
      component={"img"}
      src={add_file_icon}
      alt="Add icon"
    />

    <Typography
      variant="body1"
      sx={{ textAlign: "center", color: "inactive.main" }}
    >
      Your work education information is empty, add a new one{" "}
    </Typography>

    <StyledGreenRoundedIconBtn
      onClick={handleOpen}
      sx={{
        alignSelf: "center",
      }}
    >
      <AddIcon sx={{ width: "17.5px", height: "17.5px" }} />
    </StyledGreenRoundedIconBtn>
  </Stack>
);

export default EmptyEducationMessage;
