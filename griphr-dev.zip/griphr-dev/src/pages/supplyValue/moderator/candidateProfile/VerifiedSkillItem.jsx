import { Box, Typography } from "@mui/material";
import React from "react";
import correctIcon from "../../../../assets/green_correct_icon.svg";

const VerifiedSkillItem = ({ data }) => {
  return (
    <Box
      key={data.title}
      sx={{
        display: "flex",
        alignItems: "center",
        gap: "12px",
        backgroundColor: "softAccent",
        borderRadius: "100px",
        py: "4px",
        px: "12px",
      }}
    >
      <Typography
        variant="h6"
        textTransform="none"
        color="darkGreenAccent"
        fontWeight="500"
      >
        {data.title}
      </Typography>

      <img
        src={correctIcon}
        alt="Status validation icon"
        style={{ width: "16px", height: "16px" }}
      />
    </Box>
  );
};

export default VerifiedSkillItem;
