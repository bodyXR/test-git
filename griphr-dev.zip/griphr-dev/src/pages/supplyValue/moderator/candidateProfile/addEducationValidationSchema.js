import * as yup from "yup";

export const addEducationValidationSchema = yup.object().shape({
  degree: yup.string().required("Degree is required"),
  institution: yup.string().required("Institution is required"),
  start_date: yup
    .date()
    .required("Start date is required")
    .typeError("Start date is required"),
  end_date: yup
    .date()
    .required("End date is required")
    .typeError("End date is required"),
  level: yup.string().required("Level is required"),
});
