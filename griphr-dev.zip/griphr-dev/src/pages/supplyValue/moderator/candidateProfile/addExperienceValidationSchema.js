import * as yup from "yup";

export const addExperienceValidationSchema = yup.object().shape({
  title: yup.string().required("Position is required"),
  company: yup.string().required("Company is required"),
  start_date: yup
    .date()
    .required("Start date is required")
    .typeError("Start date is required"),
  is_current: yup.boolean(),
  end_date: yup.date().when("is_current", {
    is: false,
    then: () => {
      return yup
        .date()
        .required("End date is required")
        .typeError("End date is required")
        .min(yup.ref("start_date"), "Must be after start date");
    },
    otherwise: () => {
      return yup.date().notRequired();
    },
  }),
});
