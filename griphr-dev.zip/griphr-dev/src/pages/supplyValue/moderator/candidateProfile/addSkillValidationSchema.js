import * as yup from "yup";

export const addSkillValidationSchema = yup.object().shape({
  skill_id: yup.string().required("Skill is required"),
});
