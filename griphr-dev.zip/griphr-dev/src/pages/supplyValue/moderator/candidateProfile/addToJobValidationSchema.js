import * as yup from "yup";

export const addToJobValidationSchema = yup.object().shape({
  role_ids: yup.array().min(1, "At least one job must be selected"),
});
