import { Box, Stack } from "@mui/material";
import { useFormik } from "formik";
import ResumeDropContainer from "../components/ResumeDropContainer";
import { useEffect } from "react";
import PersonalInformationCandidate from "./PersonalInformationCandidate";
import CandidateRoleDetails from "./CandidateRoleDetails";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../components/styled/StyledDarkOutlinedBtn";
import { useDispatch } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { addCandidateValidationSchema } from "./addCandidateValidationSchema";
import { unwrapResult } from "@reduxjs/toolkit";
import {
  addAvailability,
  addReusme,
  createCandidate,
  getAllCandidates,
} from "../../../../redux/slices/moderator/candidatesList/candidatesListActions";
import SearchRole from "../components/SearchRole";

const fileTypes = {
  "application/pdf": [".pdf"],
  "application/msword": [".doc"],
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [
    ".docx",
  ],
};

const AddCandidateModal = ({ onClose }) => {
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const initialValues = {
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    location: "",
    gender: "",
    system_role: "",
    checked: false,
    job_profile: "",
    hourly_rate: "",
    experience_years: "",
    availability: "",
    file: null,
  };

  const formik = useFormik({
    initialValues,
    validationSchema: addCandidateValidationSchema,
    onSubmit: async (values) => {
      // filter values to remove empty key-value pairs
      // and return only the ones that have values into new object
      const filteredValues = Object.fromEntries(
        Object.entries(values).filter(
          ([key, value]) => value && key !== "availability"
        )
      );

      try {
        const resCreateCandidate = await dispatch(
          createCandidate(filteredValues)
        );

        const data = await unwrapResult(resCreateCandidate);

        if (!!values?.availability && !!values?.file) {
          const res = await Promise.allSettled([
            await dispatch(
              addAvailability({
                id: data?.payload?.id,
                hours: values?.availability,
              })
            ),
            await dispatch(
              addReusme({
                id: data?.payload?.id,
                file: values?.file,
              })
            ),
          ]);

          await unwrapResult(res);
        } else if (!!values?.availability) {
          const res = await dispatch(
            addAvailability({
              id: data?.payload?.id,
              hours: values?.availability,
            })
          );
          await unwrapResult(res);
        } else if (!!values?.file) {
          const res = await dispatch(
            addReusme({
              id: data?.payload?.id,
              file: values?.file,
            })
          );
          await unwrapResult(res);
        }

        await dispatch(getAllCandidates({}));

        handleClickSnackbar("Candidate added successfully", "success");
        onClose();
      } catch (error) {
        handleClickSnackbar(error || "Fail to add candidate ", "error");
      }
    },
  });

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        p: { xs: 2, lg: 0 },
        pb: { lg: 2 },
        pt: { xs: 0 },
        mt: { xs: -3, lg: 0 },
        gap: { xs: 5 },
      }}
      component={"form"}
      onSubmit={formik.handleSubmit}
    >
      <ResumeDropContainer
        title={"CV-Resume.pdf"}
        fileTypes={fileTypes}
        formik={formik}
        name={"file"}
      />
      <PersonalInformationCandidate formik={formik} />

      {/* <CandidateRoleDetails formik={formik} /> */}
      <SearchRole formik={formik} />

      <Stack sx={{ flexDirection: { lg: "row" } }} gap={1}>
        <StyledDarkBtn
          min_width={172}
          type="submit"
          disabled={formik.isSubmitting}
        >
          Save
        </StyledDarkBtn>
        <StyledDarkOutlinedBtn min_width={172} onClick={onClose}>
          Cancel
        </StyledDarkOutlinedBtn>
      </Stack>
    </Box>
  );
};

export default AddCandidateModal;
