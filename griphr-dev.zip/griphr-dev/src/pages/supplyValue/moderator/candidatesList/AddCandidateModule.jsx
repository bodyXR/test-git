import React from "react";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import AddIcon from "@mui/icons-material/Add";
import CustomModal from "../../../../ui/CustomModal";
import useModal from "../../../../hooks/useModal";
import AddCandidateModal from "./AddCandidateModal";
import { useMediaQuery } from "@mui/material";

const AddCandidateModule = () => {
  const lgMedia = useMediaQuery((theme) => theme.breakpoints.up("lg"));

  const {
    handleClose: handleCloseAddCandidate,
    handleOpen: handleOpenAddCandidate,
    open: openAddCandidate,
  } = useModal();
  return (
    <>
      <CustomModal
        open={openAddCandidate}
        onClose={handleCloseAddCandidate}
        title={"Add candidate"}
        height="95%"
      >
        <AddCandidateModal onClose={handleCloseAddCandidate} />
      </CustomModal>
      <StyledDarkBtn
        onClick={handleOpenAddCandidate}
        min_width={lgMedia ? "190px" : "120px"}
        sx={{ flex: { xs: 1 } , textTransform:"unset"}}
        endIcon={<AddIcon />}
      >
        Add candidate
      </StyledDarkBtn>
    </>
  );
};

export default AddCandidateModule;
