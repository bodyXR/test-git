import React, { useEffect, useRef, useState } from "react";
import CandidateListActionsMenu from "./CandidateListActionsMenu";
import StyledGreenActionsBtn from "../../../../components/styled/StyledGreenActionsBtn";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import useMenu from "../../../../hooks/useMenu";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
const CandidateListActionsModule = () => {
  const { handleClose, handleOpen, menuAnchorEl, open } = useMenu();
  const [width, setWidth] = useState(0);
  const buttonRef = useRef(null);

  useEffect(() => {
    if (buttonRef.current) {
      setWidth(buttonRef.current.offsetWidth);
    }
  }, []);

  return (
    <>
      <StyledGreenActionsBtn
        disableElevation
        disableRipple
        expand={!!open}
        endIcon={<ExpandMoreIcon />}
        variant="outlined"
        onClick={handleOpen}
        ref={buttonRef}
        sx={{ flex: { md: 1 }, minWidth: { lg: "120px" } }}
      >
        actions
      </StyledGreenActionsBtn>
      <CandidateListActionsMenu
        width={width}
        anchor={menuAnchorEl}
        open={open}
        onClose={handleClose}
      />
    </>
  );
};

export default CandidateListActionsModule;
