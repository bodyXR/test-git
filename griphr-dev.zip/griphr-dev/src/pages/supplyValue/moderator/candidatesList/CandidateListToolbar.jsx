import { Stack, useMediaQuery } from "@mui/material";
import SearchCandidateModule from "./SearchCandidateModule";
import CandidateListActionsModule from "./CandidateListActionsModule";
import AddCandidateModule from "./AddCandidateModule";
import { useDispatch, useSelector } from "react-redux";
import CandidatesListFiltersMobileModule from "./CandidatesListFiltersMobileModule";
import { toggleCandidatesFilters } from "../../../../redux/slices/moderator/candidatesList/candidatesListSlice";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import StyledFiltersStateButton from "../components/styled/StyledFiltersStateButton";
import filter from "../../../../assets/filter.svg";

const CandidateListToolbar = ({}) => {
  const dispatch = useDispatch();
  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const mdMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("md", "lg")
  );
  const xsMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("xs", "md")
  );

  const { candidates, selectedCandidates, isFilterExtended } = useSelector(
    (state) => state.candidatesList
  );

  return (
    <Stack
      sx={{
        gap: { xs: 2 },
        flexDirection: { lg: "row" },
        justifyContent: "space-between",
      }}
    >
      <Stack sx={{ flexDirection: "row", width: "100%", gap: 1 }}>
        {lgMatches && (
          <StyledFiltersStateButton
            startIcon={<img src={filter} alt="filter icon" />}
            variant="outlined"
            onClick={() => dispatch(toggleCandidatesFilters())}
          >
            {isFilterExtended ? "Hide filters" : "Show filters"}
          </StyledFiltersStateButton>
        )}
        <SearchCandidateModule />
      </Stack>
      {candidates && candidates?.length > 0 && (
        <>
          {lgMatches && (
            <Stack sx={{ flexDirection: "row", gap: 2 }}>
              {selectedCandidates.length > 0 && <CandidateListActionsModule />}
              <AddCandidateModule />
            </Stack>
          )}
          {mdMatches && (
            <Stack sx={{ gap: { xs: 2 }, flexDirection: { xs: "row" } }}>
              <CandidatesListFiltersMobileModule />
              {selectedCandidates.length > 0 && <CandidateListActionsModule />}
              <AddCandidateModule />
            </Stack>
          )}
          {xsMatches && (
            <>
              <Stack sx={{ gap: { xs: 2 }, flexDirection: { xs: "row" } }}>
                <CandidatesListFiltersMobileModule />
                <AddCandidateModule />
              </Stack>
              {selectedCandidates.length > 0 && <CandidateListActionsModule />}{" "}
            </>
          )}
        </>
      )}
    </Stack>
  );
};

export default CandidateListToolbar;
