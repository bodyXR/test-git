import React from "react";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import { Typography } from "@mui/material";
import StyledTextField from "../../../../components/styled/StyledTextField";
import StyledFilterLabel from "../../../../components/styled/StyledFilterLabel";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";

const CandidateRoleDetails = ({ formik }) => {
  return (
    <StyledWrapper sx={{ p: { xs: 2 }, gap: { xs: 2.5 } }}>
      <Typography
        variant="h4"
        sx={{ color: "darkGreenAccent", fontWeight: 600 }}
      >
        Role Details{" "}
      </Typography>

      <StyledTextField
        id="role"
        name="role"
        variant="outlined"
        placeholder="Role"
        label="Role"
        type="text"
        size="medium"
        value={formik.values.role}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        helperText={formik.touched.role ? formik.errors.role : ""}
        error={formik.touched.role && Boolean(formik.errors.role)}
      />
      <StyledFilterLabel
        control={<StyledFilterCheckbox checked={formik.values.invitation} />}
        label="Send invitation to employee"
        name="invitation"
        onChange={formik.handleChange}
      />
    </StyledWrapper>
  );
};

export default CandidateRoleDetails;
