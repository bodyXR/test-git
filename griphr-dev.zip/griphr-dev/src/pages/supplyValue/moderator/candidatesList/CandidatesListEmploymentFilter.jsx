import React from "react";
import FilterSection from "../components/FilterSection";
import { useDispatch, useSelector } from "react-redux";
import { FormGroup } from "@mui/material";
import StyledFilterLabel from "../../../../components/styled/StyledFilterLabel";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";
import {
  addSelectedEmploymentType,
  removeSelectedEmploymentType,
} from "../../../../redux/slices/moderator/candidatesList/candidatesListSlice";
import capitalizeFirstWord from "../../../../helper/capitalizeFirstWord";

const CandidatesListEmploymentFilter = () => {
  const dispatch = useDispatch();
  const { employmentType, selectedEmploymentType } = useSelector(
    (state) => state.candidatesList
  );

  console.log("selectedEmploymentType", selectedEmploymentType);

  return (
    <FilterSection title="Employment type">
      <FormGroup>
        {employmentType?.length > 0 &&
          employmentType?.map((employmentType, index) => (
            <StyledFilterLabel
              key={employmentType}
              control={
                <StyledFilterCheckbox
                  checked={selectedEmploymentType.includes(employmentType)}
                  onChange={() => {
                    if (selectedEmploymentType.includes(employmentType)) {
                      return dispatch(
                        removeSelectedEmploymentType(employmentType)
                      );
                    }
                    dispatch(addSelectedEmploymentType(employmentType));
                  }}
                  name={employmentType}
                />
              }
              label={capitalizeFirstWord(employmentType)}
            />
          ))}
      </FormGroup>
    </FilterSection>
  );
};

export default CandidatesListEmploymentFilter;
