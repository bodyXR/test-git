import React from "react";
import CandidatesListRoleFilter from "./CandidatesListRoleFilter";
import CandidatesListEmploymentFilter from "./CandidatesListEmploymentFilter";
import CandidatesHourlyRateFilter from "./CandidatesListHourlyRateFilter";
import CandidatesListAvailabilityFilter from "./CandidatesListAvailabilityFilter";
import CandidatesListStatusFilter from "./CandidatesListStatusFilter";

const CandidatesListFiltersContent = () => {
  return (
    <>
      <CandidatesListRoleFilter />
      <CandidatesListEmploymentFilter />
      <CandidatesHourlyRateFilter />
      <CandidatesListAvailabilityFilter />
      <CandidatesListStatusFilter />
    </>
  );
};

export default CandidatesListFiltersContent;
