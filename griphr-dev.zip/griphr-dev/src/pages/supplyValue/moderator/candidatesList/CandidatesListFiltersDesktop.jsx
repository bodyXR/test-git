import { Stack, Typography } from "@mui/material";
import CandidatesListFiltersContent from "./CandidatesListFiltersContent";
import StyledWrapper from "../../../../components/styled/StyledWrapper";

const CandidatesListFiltersDesktop = () => {
  return (
    <StyledWrapper
      sx={{
        minWidth: "292px",
        maxWidth: "292px",
        gap: 2,
        height: "62vh",
        // height:'400px',
        overflowY: "auto",
      }}
    >
      <Typography variant="h6">Filters</Typography>
      <CandidatesListFiltersContent />
    </StyledWrapper>
  );
};

export default CandidatesListFiltersDesktop;
