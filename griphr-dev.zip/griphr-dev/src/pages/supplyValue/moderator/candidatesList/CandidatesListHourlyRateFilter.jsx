import React, { useState } from "react";
import FilterSection from "../components/FilterSection";
import { Stack } from "@mui/material";
import StyledSlider from "../../../../components/styled/StyledSlider";
import StyledTextField from "../../../../components/styled/StyledTextField";
import { useDispatch, useSelector } from "react-redux";
import {
  setMinHourlyRate,
  setMaxHourlyRate,
} from "../../../../redux/slices/moderator/candidatesList/candidatesListSlice";

const CandidatesHourlyRateFilter = () => {
  const dispatch = useDispatch();
  const { minHourlyRate, maxHourlyRate } = useSelector(
    (state) => state.candidatesList
  );

  const [value, setValue] = useState([minHourlyRate, maxHourlyRate]);

  const handleSliderChange = (event, newValue) => {
    setValue(newValue);
    dispatch(setMinHourlyRate(newValue[0]));
    dispatch(setMaxHourlyRate(newValue[1]));
  };

  const handleMinHourChange = (event) => {
    const newMin = Number(event.target.value);
    setValue([newMin, value[1]]); // Update the slider immediately
    dispatch(setMinHourlyRate(newMin)); // Immediate update
  };

  const handleMaxHourChange = (event) => {
    const newMax = Number(event.target.value);
    setValue([value[0], newMax]); // Update the slider immediately
    dispatch(setMaxHourlyRate(newMax)); // Immediate update
  };

  return (
    <FilterSection title="Hourly rate">
      <StyledSlider
        getAriaLabel={() => "Hourly rate range"}
        value={value}
        onChange={handleSliderChange}
        valueLabelDisplay="auto"
        min={0}
        max={100}
      />
      <Stack sx={{ flexDirection: "row", gap: 1, mt: 1 }}>
        <StyledTextField
          id="minHour"
          name="minHour"
          variant="outlined"
          placeholder="Min/h"
          label="Min/h"
          type="number"
          size="medium"
          value={value[0]}
          onChange={handleMinHourChange}
          inputProps={{ min: 0, max: value[1] }}
        />
        <StyledTextField
          id="maxHour"
          name="maxHour"
          variant="outlined"
          placeholder="Max/h"
          label="Max/h"
          type="number"
          size="medium"
          value={value[1]}
          onChange={handleMaxHourChange}
          inputProps={{ min: value[0], max: 100 }}
        />
      </Stack>
    </FilterSection>
  );
};

export default CandidatesHourlyRateFilter;
