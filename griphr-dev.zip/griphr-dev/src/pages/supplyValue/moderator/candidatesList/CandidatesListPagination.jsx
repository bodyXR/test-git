import { Pagination } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllCandidates } from "../../../../redux/slices/moderator/candidatesList/candidatesListActions";

const CandidatesListPagination = () => {
  const dispatch = useDispatch();
  const { prev, next, total_candidates } = useSelector(
    (state) => state.candidatesList.paginationStatus
  );
  const { currentFilterParams } = useSelector((state) => state.candidatesList);

  const [pagination, setPagination] = useState(1);

  const handlePagination = (event, value) => {
    setPagination(value);
  };

  useEffect(() => {
    let params = { page: pagination };
    let filterParams = { filters: currentFilterParams };
    if (currentFilterParams && Object.keys(currentFilterParams).length > 0) {
      params = { ...params, ...filterParams };
    }
    dispatch(getAllCandidates(params));
  }, [pagination, currentFilterParams, dispatch]);

  return (
    <Pagination
      page={pagination}
      count={Math.ceil(total_candidates / 5)}
      shape="rounded"
      size="large"
      onChange={handlePagination}
    />
  );
};

export default CandidatesListPagination;
