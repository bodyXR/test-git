import { FormGroup, InputAdornment } from "@mui/material";
import StyledSearchBar from "../../../../components/styled/StyledSearchBar";
import search from "../../../../assets/search.svg";
import { useDispatch, useSelector } from "react-redux";
import {
  addSelectedRole,
  removeSelectedRole,
} from "../../../../redux/slices/moderator/candidatesList/candidatesListSlice";
import FilterSection from "../components/FilterSection";
import StyledFilterLabel from "../../../../components/styled/StyledFilterLabel";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";
import useSearch from "../../../../hooks/useSearch";
import { useEffect } from "react";
import { getAllJobProfiles } from "../../../../redux/slices/moderator/candidatesList/candidatesListActions";
import capitalizeFirstWord from "../../../../helper/capitalizeFirstWord";

const CandidatesListRoleFilter = () => {
  const { selectedRoles, jobProfiles: roles } = useSelector(
    (state) => state.candidatesList
  );
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getAllJobProfiles());
  }, []);

  const { filteredData, setSearchQuery, searchQuery } = useSearch(roles, [
    "title",
  ]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  return (
    <FilterSection title="Role">
      <StyledSearchBar
        name="roleSearch"
        fullWidth
        size="small"
        type="search"
        variant="outlined"
        value={searchQuery}
        onChange={(e) => handleSearchChange(e)}
        placeholder="Search"
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <img src={search} alt="search icon" />
            </InputAdornment>
          ),
        }}
      />
      <FormGroup>
        {filteredData?.length > 0 &&
          filteredData.map((role, index) => (
            <StyledFilterLabel
              key={role?.id}
              control={
                <StyledFilterCheckbox
                  checked={selectedRoles.includes(role?.id)}
                  onChange={() => {
                    if (selectedRoles.includes(role?.id)) {
                      return dispatch(removeSelectedRole(role?.id));
                    }
                    dispatch(addSelectedRole(role?.id));
                  }}
                  name={role?.title}
                />
              }
              label={capitalizeFirstWord(role?.title)}
            />
          ))}
      </FormGroup>
    </FilterSection>
  );
};

export default CandidatesListRoleFilter;
