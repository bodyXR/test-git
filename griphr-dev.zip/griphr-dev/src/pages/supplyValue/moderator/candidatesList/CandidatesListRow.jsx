import Grid from "@mui/material/Unstable_Grid2";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";
import { useDispatch, useSelector } from "react-redux";
import {
  addSelectedCandidate,
  removeSelectedCandidate,
} from "../../../../redux/slices/moderator/candidatesList/candidatesListSlice";
import { Avatar, Stack, Typography, styled } from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import useMenu from "../../../../hooks/useMenu";
import StyledSingleActionsBtn from "../../../../components/styled/StyledSingleActionsBtn";
import CandidateListActionsMenu from "./CandidateListActionsMenu";
import StyledCandidatesRowBody1 from "../../../../components/styled/StyledCandidatesRowBody1";
import { Link } from "react-router-dom";

const CandidatesListRow = ({ data }) => {
  const { handleClose, handleOpen, menuAnchorEl, open } = useMenu();
  const dispatch = useDispatch();
  const { selectedCandidates } = useSelector((state) => state.candidatesList);

  return (
    <Grid
      className="candidate__row"
      container
      sx={{
        alignItems: "center",
        borderBottom: "2px solid #EEE",
        p: 2,
      }}
    >
      <Grid xs={0.5}>
        <StyledFilterCheckbox
          checked={selectedCandidates.includes(data?.id)}
          onChange={() => {
            if (selectedCandidates.includes(data?.id)) {
              dispatch(removeSelectedCandidate(data?.id));
              return;
            }
            dispatch(addSelectedCandidate(data?.id));
          }}
        />
      </Grid>

      {/* Candidate Col */}
      <Grid xs={2.5}>
        <Stack
          sx={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Stack
            sx={{
              flexDirection: "row",
              alignItems: "center",
              gap: 1.25,
            }}
          >
            <Avatar
              src={data?.profile_picture?.url}
              alt={data?.profile_picture?.name}
              sx={{ width: "30px", height: "30px" }}
            />

            <Stack sx={{ gap: 1.25 }}>
              <Link to={`/moderator/candidates/profile/${data?.id}`}>
                <Typography
                  variant="h5"
                  sx={{
                    "&:hover": {
                      color: "#66C1FF",
                      textDecoration: "underline",
                    },
                    textTransform: "capitalize",
                    color: "inactive.main",
                    fontWeight: 600,
                    textOverflow: "ellipsis",
                    overflow: "hidden",
                  }}
                >
                  {data?.first_name + " " + data?.last_name}
                </Typography>
              </Link>
              <StyledCandidatesRowBody1
                sx={{ textAlign: "left" }}
                variant="body1"
              >
                {data?.role?.title || "N/A"}
              </StyledCandidatesRowBody1>
            </Stack>
          </Stack>
        </Stack>
      </Grid>

      {/* Experience Col */}
      <Grid xs={1.5}>
        <StyledCandidatesRowBody1
          variant="body1"
          sx={{ textTransform: "none" }}
        >
          {data?.experience_years ? `${data?.experience_years}years` : `N/A`}
        </StyledCandidatesRowBody1>
      </Grid>

      {/* Hourly-Rate Col */}
      <Grid xs={1.5}>
        <StyledCandidatesRowBody1
          variant="body1"
          sx={{ textTransform: "none" }}
        >
          {data?.hourly_rate ? `€${data?.hourly_rate}` : "N/A"}
        </StyledCandidatesRowBody1>
      </Grid>

      {/* Availability Col */}
      <Grid xs={1.5}>
        <StyledCandidatesRowBody1
          variant="body1"
          sx={{ textTransform: "none" }}
        >
          {data?.availability ? `${data?.availability}h/w` : "N/A"}
        </StyledCandidatesRowBody1>
      </Grid>

      {/* Employment-Type Col */}
      <Grid xs={2}>
        <StyledCandidatesRowBody1 variant="body1">
          {data?.system_role}
        </StyledCandidatesRowBody1>
      </Grid>

      {/* Status Col */}
      <Grid xs={1} sx={{ display: "flex", justifyContent: "center" }}>
        <Stack
          sx={{
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            backgroundColor:
              data?.status === "active"
                ? "#DBF0DE"
                : data?.status === "inactive"
                ? "#EEE"
                : "#E5F3FC",
            borderRadius: "16px",
            p: "4px 8px",
            maxWidth: "fit-content",
          }}
        >
          <Typography variant="body2" textTransform="capitalize">
            {data?.status}
          </Typography>
        </Stack>
      </Grid>

      {/* Actions Col */}
      <Grid xs={1.5} sx={{ textAlign: "right" }}>
        <StyledSingleActionsBtn
          expand={!!open}
          onClick={handleOpen}
          endIcon={<ExpandMoreIcon />}
        >
          Actions
        </StyledSingleActionsBtn>
        <CandidateListActionsMenu
          userId={data?.id}
          anchor={menuAnchorEl}
          open={open}
          onClose={handleClose}
        />
      </Grid>
    </Grid>
  );
};

export default CandidatesListRow;
