import CandidatesListRow from "./CandidatesListRow";
import { useSelector } from "react-redux";

const CandidatesListRowsWrapper = () => {
  const { searchedCandidates } = useSelector((state) => state.candidatesList);

  return (
    <>
      {searchedCandidates &&
        searchedCandidates?.map((candidate, index) => (
          <CandidatesListRow
            key={candidate?.id}
            isLast={index === candidate?.length - 1}
            data={candidate}
          />
        ))}
    </>
  );
};

export default CandidatesListRowsWrapper;
