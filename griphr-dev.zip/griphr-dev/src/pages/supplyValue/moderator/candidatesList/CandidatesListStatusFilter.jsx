import React from "react";
import FilterSection from "../components/FilterSection";
import { FormGroup } from "@mui/material";
import {
  addSelectedStatus,
  removeSelectedStatus,
} from "../../../../redux/slices/moderator/candidatesList/candidatesListSlice";
import { useDispatch, useSelector } from "react-redux";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";
import StyledFilterLabel from "../../../../components/styled/StyledFilterLabel";
import capitalizeFirstWord from "../../../../helper/capitalizeFirstWord";

const status = ["active", "inactive", "invited"];

const CandidatesListStatusFilter = () => {
  const dispatch = useDispatch();
  const { selectedStatus } = useSelector((state) => state.candidatesList);
  return (
    <FilterSection title="Status">
      <FormGroup>
        {status?.length > 0 &&
          status.map((status, index) => (
            <StyledFilterLabel
              key={status}
              control={
                <StyledFilterCheckbox
                  checked={selectedStatus.includes(status)}
                  onChange={() => {
                    if (selectedStatus.includes(status)) {
                      return dispatch(removeSelectedStatus(status));
                    }
                    dispatch(addSelectedStatus(status));
                  }}
                  name={status}
                />
              }
              label={capitalizeFirstWord(status)}
            />
          ))}
      </FormGroup>
    </FilterSection>
  );
};

export default CandidatesListStatusFilter;
