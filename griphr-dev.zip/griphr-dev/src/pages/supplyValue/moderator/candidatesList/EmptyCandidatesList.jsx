import { Box, Stack, Typography } from "@mui/material";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import pluspaperIcon from "../../../../assets/plus_paper.svg";
import useModal from "../../../../hooks/useModal";
import CustomModal from "../../../../ui/CustomModal";
import AddCandidateModal from "./AddCandidateModal";
import { useDispatch } from "react-redux";

const EmptyCandidatesList = () => {
  const dispatch = useDispatch();
  const {
    handleClose: handleCloseAddCandidate,
    handleOpen: handleOpenAddCandidate,
    open: openAddCandidate,
  } = useModal();
  return (
    <>
      <CustomModal
        open={openAddCandidate}
        onClose={handleCloseAddCandidate}
        title={"Add candidate"}
        height="95%"
      >
        <AddCandidateModal />
      </CustomModal>
      <StyledWrapper
        sx={{
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center",
          gap: "12px",
          py: { xs: 5, lg: "20px" },
          flex: 1,
        }}
      >
        <Box
          sx={{ width: "40px", height: "50px" }}
          component={"img"}
          src={pluspaperIcon}
        />

        <Typography variant="h4" color="inactive.main">
          The list is empty, choose an option to start fill it{" "}
        </Typography>

        <Stack
          sx={{
            flexDirection: { lg: "row" },
            justifyContent: "center",
            alignItems: "center",
            gap: { xs: "12px", lg: 3 },
            width: { xs: "100%", md: "150px" },
          }}
        >
          <StyledDarkBtn
            onClick={handleOpenAddCandidate}
            min_width="120px"
            sx={{ width: "100%",textTransform:"unset" }}
          >
            Add candidate
          </StyledDarkBtn>
        </Stack>
      </StyledWrapper>
    </>
  );
};

export default EmptyCandidatesList;
