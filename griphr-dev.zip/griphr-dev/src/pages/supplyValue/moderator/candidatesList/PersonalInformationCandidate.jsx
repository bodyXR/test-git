import { MenuItem, Stack, TextField, Typography } from "@mui/material";
import React from "react";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import StyledTextField from "../../../../components/styled/StyledTextField";
import StyledDatePicker from "../../../../components/styled/StyledDatePicker";
import Grid from "@mui/material/Unstable_Grid2";

const PersonalInformationCandidate = ({ formik, editMode = false }) => {
  return (
    <StyledWrapper sx={{ p: { xs: 2 }, gap: { xs: 2.5 } }}>
      <Typography
        variant="h4"
        sx={{ color: "darkGreenAccent", fontWeight: 600 }}
      >
        Personal information
      </Typography>
      <Grid container spacing={2.5}>
        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="first_name"
              name="first_name"
              variant="outlined"
              placeholder="First Name"
              label="First name"
              type="text"
              required
              value={formik.values.first_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.first_name ? formik.errors.first_name : ""
              }
              error={
                formik.touched.first_name && Boolean(formik.errors.first_name)
              }
            />
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="last_name"
              name="last_name"
              variant="outlined"
              placeholder="Last Name"
              label="Last name"
              type="text"
              required
              value={formik.values.last_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.last_name ? formik.errors.last_name : ""
              }
              error={
                formik.touched.last_name && Boolean(formik.errors.last_name)
              }
            />
          </Stack>
        </Grid>

        {!editMode && (
          <Grid xs={12} lg={6}>
            <Stack sx={{ alignItems: { xs: "stretch" } }}>
              <StyledTextField
                id="email"
                name="email"
                variant="outlined"
                placeholder="Email"
                label="Email"
                type="email"
                required
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                helperText={formik.touched.email ? formik.errors.email : ""}
                error={formik.touched.email && Boolean(formik.errors.email)}
              />
            </Stack>
          </Grid>
        )}

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="phone"
              name="phone"
              variant="outlined"
              placeholder="Phone"
              label="Phone"
              type="text"
              value={formik.values.phone}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.phone ? formik.errors.phone : ""}
              error={formik.touched.phone && Boolean(formik.errors.phone)}
            />
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="gender"
              name="gender"
              variant="outlined"
              placeholder="Gender"
              label="Gender"
              select
              value={formik.values.gender}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.gender ? formik.errors.gender : ""}
              error={formik.touched.gender && Boolean(formik.errors.gender)}
            >
              <MenuItem value="male">Male</MenuItem>
              <MenuItem value="female">Female</MenuItem>
              <MenuItem value="diverse">Diverse</MenuItem>
              <MenuItem value="undifined">Undifined</MenuItem>
            </StyledTextField>
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="location"
              name="location"
              variant="outlined"
              placeholder="Location"
              label="Location"
              type="text"
              value={formik.values.location}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={formik.touched.location ? formik.errors.location : ""}
              error={formik.touched.location && Boolean(formik.errors.location)}
            />
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="system_role"
              name="system_role"
              variant="outlined"
              placeholder="Employment Type"
              label="Employment type"
              select
              required
              value={formik.values.system_role}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.system_role ? formik.errors.system_role : ""
              }
              error={
                formik.touched.system_role && Boolean(formik.errors.system_role)
              }
            >
              <MenuItem value="moderator">Moderator</MenuItem>
              <MenuItem value="freelancer">Freelancer</MenuItem>
              <MenuItem value="internal">Internal</MenuItem>
            </StyledTextField>
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="hourly_rate"
              name="hourly_rate"
              variant="outlined"
              placeholder="Hourly Rate"
              label="Hourly rate"
              type="number"
              value={formik.values.hourly_rate}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.hourly_rate ? formik.errors.hourly_rate : ""
              }
              error={
                formik.touched.hourly_rate && Boolean(formik.errors.hourly_rate)
              }
            />
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="availability"
              name="availability"
              variant="outlined"
              placeholder="Availability"
              label="Availability"
              type="number"
              value={formik.values.availability}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.availability ? formik.errors.availability : ""
              }
              error={
                formik.touched.availability &&
                Boolean(formik.errors.availability)
              }
            />
          </Stack>
        </Grid>

        <Grid xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              id="experience_years"
              name="experience_years"
              variant="outlined"
              placeholder="Experience Years"
              label="Experience years"
              type="number"
              value={formik.values.experience_years}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.experience_years
                  ? formik.errors.experience_years
                  : ""
              }
              error={
                formik.touched.experience_years &&
                Boolean(formik.errors.experience_years)
              }
            />
          </Stack>
        </Grid>
      </Grid>
    </StyledWrapper>
  );
};

export default PersonalInformationCandidate;
