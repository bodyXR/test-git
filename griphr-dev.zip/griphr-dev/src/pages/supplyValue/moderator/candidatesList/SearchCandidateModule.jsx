import { InputAdornment } from "@mui/material";
import search from "../../../../assets/search.svg";
import StyledSearchBar from "../../../../components/styled/StyledSearchBar";
import useSearch from "../../../../hooks/useSearch";
import { useDispatch, useSelector } from "react-redux";
import { searchCandidates } from "../../../../redux/slices/moderator/candidatesList/candidatesListSlice";

const SearchCandidateModule = () => {
  const dispatch = useDispatch();
  const { candidates } = useSelector((state) => state.candidatesList);

  const { searchQuery, setSearchQuery, filteredData } = useSearch(candidates, [
    "first_name",
    "last_name",
  ]);

  return (
    <StyledSearchBar
      name="search_candidate"
      fullWidth
      size="small"
      type="search"
      variant="outlined"
      value={searchQuery}
      onChange={(e) => {
        setSearchQuery(e.target.value);
        if (e.target.value === "") {
          return dispatch(searchCandidates(candidates));
        }
        dispatch(searchCandidates(filteredData));
      }}
      placeholder="Search candidate"
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <img src={search} alt="search icon" />
          </InputAdornment>
        ),
      }}
      sx={{
        alignSelf: "stretch",
        "& .MuiInputBase-root": {
          minHeight: "44.5px",
          height: "100%",
        },
      }}
    />
  );
};

export default SearchCandidateModule;
