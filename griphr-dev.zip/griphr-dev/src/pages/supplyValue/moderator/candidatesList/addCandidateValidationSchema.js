import * as yup from "yup";

export const addCandidateValidationSchema = yup.object().shape({
  first_name: yup.string().required("First name is required"),
  last_name: yup.string().required("Last name is required"),
  email: yup
    .string()
    .email("Invalid email format")
    .required("Email is required"),
  phone: yup.string().optional(),
  location: yup.string().optional(),
  gender: yup.string().optional(),
  system_role: yup.string().required("Access level is required"),
  checked: yup.boolean().optional(),
  job_profile: yup.number().optional(),
  hourly_rate: yup.number().optional(),
  experience_years: yup.number().optional(),
  availability: yup
    .number()
    .optional()
    .max(40, "Availability should not exceed 40 hours"),
  file: yup.mixed().nullable().optional(),
});
