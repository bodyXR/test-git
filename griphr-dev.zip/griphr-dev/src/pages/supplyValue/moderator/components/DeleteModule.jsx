import {
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Typography,
} from "@mui/material";
import React from "react";

const DeleteModule = ({
  title,
  openDialog,
  handleCloseDialog,
  handleDelete,
  isDeleting = false,
}) => {
  return (
    <Dialog
      open={openDialog}
      onClose={() => {
        handleCloseDialog();
      }}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle id="alert-dialog-title">{`Delete ${title}`}</DialogTitle>
      <DialogContent sx={{ mt: 1 }}>
        <Typography variant="h4" fontWeight={"bold"}>
          {`Are you sure you want to delete this ${title}?`}
        </Typography>
      </DialogContent>
      <DialogContent sx={{ pt: 0 }}>
        <DialogContentText id="alert-dialog-description">
          This action is permanent and cannot be undo.
        </DialogContentText>
      </DialogContent>
      <DialogActions sx={{ justifyContent: "flex-start", px: 3 }}>
        <Button
          onClick={handleDelete}
          variant="contained"
          color="error"
          disabled={isDeleting}
          sx={{ textTransform: "unset" }}
        >
          Delete
        </Button>
        {isDeleting && (
          <CircularProgress
            // sx={{ position: "absolute", left: "44%", top: "35%" }}
            size={20}
          />
        )}
        <Button
          variant="outlined"
          onClick={handleCloseDialog}
          autoFocus
          sx={{ textTransform: "unset" }}
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteModule;
