import { Collapse, Stack, Typography } from "@mui/material";
import { useState } from "react";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import StyledExpandMoreBtn from "../../../../components/styled/StyledExpandMoreBtn";

const FilterSection = ({ children, title }) => {
  const [expanded, setExpanded] = useState(false);

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  return (
    <StyledWrapper sx={{ p: { xs: 1.5 }, gap: 1.5 }}>
      <Stack
        sx={{
          flexDirection: "row",
          alignItems: "center",
        }}
      >
        <Typography variant="h5">{title}</Typography>
        <StyledExpandMoreBtn
          expand={expanded}
          onClick={handleExpandClick}
          aria-expanded={expanded}
          aria-label="show more"
        >
          <ExpandMoreIcon />
        </StyledExpandMoreBtn>
      </Stack>
      <Collapse in={expanded} timeout="auto" unmountOnExit>
        <Stack
          sx={{
            gap: 1.5,
            borderTop: "1px solid",
            borderColor: "darkGrey",
            pt: 1.5,
          }}
        >
          {children}
        </Stack>
      </Collapse>
    </StyledWrapper>
  );
};

export default FilterSection;
