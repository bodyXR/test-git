import { Avatar, Box, List, ListItem, Typography } from "@mui/material";
import { useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useDispatch, useSelector } from "react-redux";
import editIcon from "../../../../assets/edit_icon.svg";
import {
  addPhoto,
  getCandidate,
} from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";

const fileTypes = {
  "image/*": [".jpeg", ".jpg", ".png"],
};
// Move this component to components Folder inside moderator folder
const PhotoDropContainer = () => {
  const { candidate } = useSelector((state) => state.candidate);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const onDrop = useCallback(
    async (acceptedFiles) => {
      if (acceptedFiles.length === 0) return;

      const file = acceptedFiles[0];
      try {
        const addPhotoResult = await dispatch(
          addPhoto({
            id: candidate?.id,
            file,
          })
        );
        await unwrapResult(addPhotoResult);
        await dispatch(getCandidate(candidate?.id));
        handleClickSnackbar("Photo uploaded successfully", "success");
      } catch (error) {
        console.error(error);
        handleClickSnackbar(error, "error");
      }
    },
    [dispatch, candidate?.id]
  );

  const { acceptedFiles, fileRejections, getRootProps, getInputProps } =
    useDropzone({
      onDrop,
      accept: fileTypes,
      maxFiles: 1,
      maxSize: 4 * 10 ** 6,
    });

  const fileRejectionItems = fileRejections.map(({ file, errors }) => (
    <Box key={file.path}>
      <Typography variant="h5" color={"secondary.main"} fontWeight={"400"}>
        Selected File:{" "}
        <Typography variant="span" color={"secondary.main"} fontWeight={"700"}>
          {file.path}
        </Typography>
      </Typography>
      <List>
        {errors.map((e) => (
          <ListItem key={e.code} sx={{ color: "warning.main" }}>
            {e.message}
          </ListItem>
        ))}
      </List>
    </Box>
  ));

  return (
    <Box sx={{ position: "relative" }}>
      <input {...getInputProps()} />
      <Box
        {...getRootProps({ className: "dropzone" })}
        sx={{
          width: "27px",
          height: "27px",
          background: "#FFFFFF",
          borderRadius: "38px",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          position: "absolute",
          bottom: "0px",
          right: "0px",
          cursor: "pointer",
          zIndex: 3,
        }}
      >
        <img src={editIcon} alt="Edit icon" />
      </Box>

      <Avatar
        src={candidate?.profile_picture?.url}
        alt={candidate?.profile_picture?.name}
        sx={{ width: "100px", height: "100px" }}
      />

      {fileRejectionItems}
    </Box>
  );
};

export default PhotoDropContainer;
