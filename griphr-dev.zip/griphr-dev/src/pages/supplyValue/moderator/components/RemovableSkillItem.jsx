import { Divider, IconButton, Stack, Typography } from "@mui/material";
import { Delete } from "@mui/icons-material";
import { useDispatch } from "react-redux";
import { deleteSelectedSkill } from "../../../../redux/slices/moderator/jobs/jobVacancySlice";
import { deleteVacancySkill } from "../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";

const RemovableSkillItem = ({ data, editMode = false }) => {
  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };
  const dispatch = useDispatch();
  const handleDelete = async () => {
    try {
      const res = await dispatch(deleteVacancySkill(data?.id));
      await unwrapResult(res);
      handleClickSnackbar("Skill deleted successfully", "success");
      dispatch(deleteSelectedSkill(data?.skill_ref));
    } catch (error) {
      console.log(error);
      handleClickSnackbar(error || "Fail to delete skill", "error");
    }
  };

  const handleDeleteLocally = () => {
    dispatch(deleteSelectedSkill(data?.skill_ref));
  };

  return (
    <Stack
      key={data.title}
      sx={{
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "softAccent",
        borderRadius: "100px",
        py: "4px",
        px: "12px",
      }}
    >
      <Typography
        variant="h6"
        textTransform="none"
        color="darkGreenAccent"
        fontWeight="500"
        sx={{ mr: 1 }}
      >
        {data.title}
      </Typography>

      <Divider
        orientation="vertical"
        variant="middle"
        flexItem
        sx={{
          bgcolor: "darkGreenAccent",
          mr: 0.25,
        }}
      />

      <IconButton
        onClick={() => {
          if (editMode) {
            handleDelete();
            return;
          }
          handleDeleteLocally();
        }}
      >
        <Delete
          sx={{ color: "darkGreenAccent", width: "18px", height: "18px" }}
        />
      </IconButton>
    </Stack>
  );
};

export default RemovableSkillItem;
