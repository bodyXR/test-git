import {
  Box,
  IconButton,
  List,
  ListItem,
  Stack,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import { useDropzone } from "react-dropzone";
import { useCallback } from "react";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import delete_inactive from "../../../../assets/delete_inactive.svg";
import { addReusme } from "../../../../redux/slices/moderator/candidatesList/candidatesListActions";
import { useDispatch, useSelector } from "react-redux";
import { unwrapResult } from "@reduxjs/toolkit";
import {
  deleteResumeAndGetCandidateById,
  getCandidate,
} from "../../../../redux/slices/moderator/candidate/candidateActions";
import { useParams } from "react-router-dom";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";

// Move this component to components Folder inside moderator folder
const ResumeDropContainer = ({
  title,
  fileTypes,
  formik,
  name,
  profilePageMode = false,
}) => {
  const [acceptedFile, setAcceptedFile] = useState(null);
  const { candidate } = useSelector((state) => state.candidate);
  const { candidateId: id } = useParams();
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const onDrop = useCallback(
    async (acceptedFiles) => {
      if (acceptedFiles.length === 0) return;

      const file = acceptedFiles[0];
      setAcceptedFile(file);
      if (profilePageMode) {
        try {
          const addResumeResult = await dispatch(
            addReusme({
              id,
              file,
            })
          );
          await unwrapResult(addResumeResult);
          await dispatch(getCandidate(id));
          handleClickSnackbar("Resume uploaded successfully", "success");
        } catch (error) {
          console.error(error);
          handleClickSnackbar(error, "error");
        }
      } else {
        formik.setFieldValue(name, file);
      }
    },
    [name, formik]
  );

  const { acceptedFiles, fileRejections, getRootProps, getInputProps } =
    useDropzone({
      onDrop,
      accept: fileTypes,
      maxFiles: 1,
      maxSize: 10 * 10 ** 6,
    });

  const files = acceptedFiles.map((file, index) => (
    <Typography
      key={index}
      variant="span"
      color={"secondary.main"}
      fontWeight={"700"}
    >
      {file.path}
    </Typography>
  ));

  const fileRejectionItems = fileRejections.map(({ file, errors }) => (
    <Box key={file.path}>
      <Typography variant="h5" color={"secondary.main"} fontWeight={"400"}>
        Selected File:{" "}
        <Typography variant="span" color={"secondary.main"} fontWeight={"700"}>
          {file.path}
        </Typography>
      </Typography>
      <List>
        {errors.map((e) => (
          <ListItem key={e.code} sx={{ color: "warning.main" }}>
            {e.message}
          </ListItem>
        ))}
      </List>
    </Box>
  ));

  const handleDeleteResume = async (data) => {
    try {
      const deleteResumeAndGetCandidateByIdResult = await dispatch(
        deleteResumeAndGetCandidateById({
          resumeId: data.resumeId,
          candidateId: data.candidateId,
        })
      );
      await unwrapResult(deleteResumeAndGetCandidateByIdResult);
      handleClickSnackbar("Resume deleted successfully", "success");
    } catch (error) {
      handleClickSnackbar(
        error?.response?.data?.message || "Fail to delete resume",
        "error"
      );
    }
  };

  return (
    <StyledWrapper sx={{ p: { xs: 0 } }}>
      <Stack>
        <Stack
          {...getRootProps({ className: "dropzone" })}
          sx={{ alignItems: "center", gap: 3, textAlign: "center", p: 2.5 }}
        >
          <input {...getInputProps()} />

          <Stack
            sx={{
              width: "100%",
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography
              sx={{
                alignSelf: "flex-start",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                overflow: "hidden",
                width: "20ch",
                textAlign: "left",
              }}
              variant="h5"
              color="inactive.main"
            >
              {profilePageMode && candidate?.resume !== null
                ? candidate?.resume?.name
                : acceptedFile?.path || title}
            </Typography>

            <IconButton
              sx={{ width: "24px", height: "24px" }}
              onClick={(e) => {
                e.stopPropagation();
                if (profilePageMode) {
                  if (candidate?.resume !== null) {
                    handleDeleteResume({
                      resumeId: candidate?.resume?.id,
                      candidateId: candidate?.id,
                    });
                  } else {
                    handleClickSnackbar(
                      "You don't have resume to delete",
                      "info"
                    );
                  }
                } else {
                  formik.setFieldValue(name, null);
                  setAcceptedFile(null);
                }
              }}
            >
              <Box component={"img"} src={delete_inactive} />
            </IconButton>
            {/* <Typography
              variant="body1"
              sx={{ fontSize: "12px", opacity: "0.5" }}
              color="inactive.main"
            >
              or, click to browse (4MB max)
            </Typography> */}
          </Stack>
        </Stack>
        <Box>
          {fileRejectionItems}

          {/* {!!formik.initialValues.files && acceptedFiles.length === 0 && (
            <Typography
              variant="h5"
              color={"secondary.main"}
              fontWeight={"400"}
            >
              Selected File:
              <Typography
                variant="span"
                color={"secondary.main"}
                fontWeight={"700"}
                sx={{ wordBreak: "break-all" }}
              >
                {formik.initialValues.files}
              </Typography>
            </Typography>
          )}
          {!!path && (
            <Typography
              variant="h5"
              color={"secondary.main"}
              fontWeight={"400"}
            >
              Selected File: {files}
            </Typography>
          )} */}
        </Box>
      </Stack>
    </StyledWrapper>
  );
};

export default ResumeDropContainer;
