import {
  Autocomplete,
  CircularProgress,
  IconButton,
  InputAdornment,
  TextField,
  Typography,
} from "@mui/material";
import React, { useCallback, useEffect, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import { useDispatch, useSelector } from "react-redux";
import { debounce } from "chart.js/helpers";
import axiosInstance from "../../../../helper/axiosInstance";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import StyledFilterLabel from "../../../../components/styled/StyledFilterLabel";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";

// Move this component to components Folder inside moderator folder
const SearchRole = ({ formik, editMode = false }) => {
  const { candidate } = useSelector((state) => state.candidate);
  const { role: currentRole } = candidate;
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [inputJobRoleValue, setInputJobRoleValue] = useState(
    editMode ? currentRole?.title : ""
  );
  const [jobRoleOptions, setJobRoleOptions] = useState([]);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleInputChange = (event, newValue) => {
    setInputJobRoleValue(newValue);
  };

  useEffect(() => {
    console.log("inputJobRoleValue", inputJobRoleValue);
  }, [inputJobRoleValue]);

  const searchJobs = useCallback(
    debounce(async (value) => {
      console.log("value inside search jobs ", value);
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `search`,
          {
            key: "job_profile",
            value: value[0],
          },
          config
        );

        setJobRoleOptions(response?.data?.payload);

        return response?.data?.payload;
      } catch (error) {
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch roles!!",
          "error"
        );
        console.log(error?.response?.data?.message);
      } finally {
        setLoading(false);
      }
    }, 500),
    [token]
  );

  const addRole = useCallback(
    async (title) => {
      // Remove double quotes from the title
      const roleTitle = title.replace(/"/g, "");

      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        const response = await axiosInstance.post(
          `job_profile`,
          {
            title: roleTitle,
          },
          config
        );
        console.log(response.data);
        return response?.data?.payload?.id;
      } catch (error) {
        setInputJobRoleValue("");
        console.log(error?.response?.data?.message);
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to add a new role!!",
          "error"
        );
      }
    },
    [token]
  );

  useEffect(() => {
    if (inputJobRoleValue !== "") {
      searchJobs(inputJobRoleValue);
    } else {
      setJobRoleOptions([]);
    }
  }, [searchJobs, token, inputJobRoleValue]);

  return (
    <StyledWrapper sx={{ p: { xs: 2 }, gap: { xs: 2.5 } }}>
      <Typography
        variant="h4"
        sx={{ color: "darkGreenAccent", fontWeight: 600 }}
      >
        Role details{" "}
      </Typography>
      <Autocomplete
        freeSolo
        id="job_profile"
        name="job_profile"
        value={inputJobRoleValue}
        options={[
          ...jobRoleOptions.map((option) => option.title),
          // Add "Add 'string that user typed'" option conditionally
          inputJobRoleValue &&
          !jobRoleOptions.some((option) => option.title === inputJobRoleValue)
            ? `Add "${inputJobRoleValue}"`
            : null,
        ].filter(Boolean)}
        inputValue={inputJobRoleValue}
        onInputChange={(event, newValue) => {
          handleInputChange(event, newValue, "role");
        }}
        onBlur={formik.handleBlur}
        onChange={async (e, value) => {
          try {
            if (value && value.startsWith("Add ")) {
              // Handle adding the role here
              const newRole = value.substring(4);
              // Call the addRole function to add the new role
              const newRoleId = await addRole(newRole);
              if (newRoleId) {
                // Update your formik field with the newly added role ID
                formik.setFieldValue("job_profile", newRoleId);
              }
            } else {
              // Check if a valid option is selected
              const selectedOption = jobRoleOptions.find(
                (option) => option.title === value
              );

              if (selectedOption) {
                // Update your formik field with the selected option
                formik.setFieldValue("job_profile", selectedOption.id);
              } else {
                // If the selected option is not in the current options, it may be a newly added role
                // In this case, you may handle it based on your requirements
              }
            }
          } catch (error) {
            handleClickSnackbar(
              error?.response?.data?.message || "Fail to add a new role!!",
              "error"
            );
          }
        }}
        sx={{ mt: "16px" }}
        renderInput={(params) => (
          <TextField
            error={
              formik.touched.job_profile && Boolean(formik.errors.job_profile)
            }
            helperText={
              formik.touched.job_profile ? formik.errors.job_profile : ""
            }
            name="job_profile"
            fullWidth
            label="Search or add new role"
            placeholder="Search or add new Role"
            {...params}
            type="search"
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <InputAdornment position="end">
                  <div style={{ display: "flex", alignItems: "center" }}>
                    {params.InputProps.endAdornment}
                    {loading && <CircularProgress size={20} />}
                  </div>

                  <IconButton>
                    <SearchIcon />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        )}
      />
      <StyledFilterLabel
        control={<StyledFilterCheckbox checked={formik.values.checked} />}
        label="Send invitation to employee"
        name="checked"
        onChange={formik.handleChange}
      />
    </StyledWrapper>
  );
};

export default SearchRole;
