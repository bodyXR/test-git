import { Box, Typography } from "@mui/material";
import React from "react";

const SkillItem = ({ data, tableMode = false }) => {
  return (
    <Box
      key={data.title}
      sx={{
        // backgroundColor: "rgba(23, 52, 51, 0.40)",
        backgroundColor: "softAccent",
        borderRadius: "100px",
        py: "4px",
        px: "12px",
        maxWidth: tableMode ? "100px" : "auto",
      }}
    >
      <Typography
        variant="h6"
        textTransform="none"
        color="darkGreenAccent"
        fontWeight="500"
        whiteSpace={tableMode ? "nowrap" : "auto"}
        textOverflow={tableMode ? "ellipsis" : "auto"}
        overflow={tableMode ? "hidden" : "auto"}
      >
        {data.title}
      </Typography>
    </Box>
  );
};

export default SkillItem;
