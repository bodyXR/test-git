import { styled } from "@mui/material";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import { forwardRef } from "react";

const StyledTable = styled(
  forwardRef((props, ref) => {
    return <StyledWrapper ref={ref} {...props} />;
  })
)(({ theme }) => ({
  overflowX: "auto",
  flex: 1,
  width: "86vw",
  userSelect: "none",
  height: "62vh",
  overflowY: "auto",
  [theme.breakpoints.up("xs")]: { paddingTop: 0 },
  [theme.breakpoints.up("lg")]: { width: "45vw" },
}));

export default StyledTable;
