import { Button, styled } from "@mui/material";

const StyledFiltersStateButton = styled(Button)(() => ({
  alignSelf: "stretch",
  textTransform: "unset",
  border: "2px solid #e9e9e9 ",
  borderRadius: "4px",
  color: "primary.main",
  fontWeight: "400",
  mb: 2,
  px: 3,
  "&: hover": {
    border: "2px solid #e9e9e9 ",
  },
  width: "200px",
}));

export default StyledFiltersStateButton;
