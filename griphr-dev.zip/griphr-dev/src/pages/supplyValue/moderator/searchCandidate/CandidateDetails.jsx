import {
  Box,
  Button,
  Divider,
  IconButton,
  Paper,
  Stack,
  Typography,
} from "@mui/material";
import Close from "@mui/icons-material/Close";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import React, { useState } from "react";
import CandidateDetailsSkills from "./CandidateDetailsSkills";
import CandidateDetailsExperience from "./CandidateDetailsExperience";
import CandidateDetailsPersonalInfo from "./CandidateDetailsPersonalInfo";
import CandidateDetailsEducation from "./CandidateDetailsEducation";
import mail_white from "../../../../assets/mail_icon_white.svg";

const CandidateDetails = ({ data, onClose }) => {
  const [showExperience, setShowExperience] = useState(false);
  const [showEducation, setShowEducation] = useState(false);
  console.log(data);
  return (
    <Paper
      sx={{
        position: "fixed",
        top: 0,
        right: 0,
        width: { xs: "100%", lg: "50%" },
        maxWidth: "552px",
        height: "100%",
        maxHeight: "100vh",
        overflowY: "auto",
        backgroundColor: "white",
        boxShadow: "-5px 0px 12px 0px rgba(0, 0, 0, 0.20)",
        borderRadius: 0,
        zIndex: 100,
        p: 2,
      }}
    >
      <Stack sx={{ gap: 3 }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography variant="h6">Candidate</Typography>
          <IconButton onClick={onClose} sx={{ p: 0 }}>
            <Close />
          </IconButton>
        </Box>

        <CandidateDetailsPersonalInfo data={data} />

        <Stack>
          <Typography variant="h3" pb="10px">
            Skills
          </Typography>
          <CandidateDetailsSkills data={data?.skills} />
          <Divider />
        </Stack>

        <Stack>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography variant="h3" pb={2}>
              Work Experience
            </Typography>
            <IconButton
              aria-label="expand row"
              size="small"
              onClick={() => setShowExperience(!showExperience)}
              sx={{ p: 0 }}
            >
              {showExperience ? (
                <KeyboardArrowUpIcon />
              ) : (
                <KeyboardArrowDownIcon />
              )}
            </IconButton>
          </Box>
          {showExperience && (
            <>
              <CandidateDetailsExperience candidateId={data.id} />
              <Divider />
            </>
          )}
        </Stack>

        <Stack>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography variant="h3" pb={2}>
              Education
            </Typography>
            <IconButton
              aria-label="expand row"
              size="small"
              onClick={() => setShowEducation(!showEducation)}
              sx={{ p: 0 }}
            >
              {showEducation ? (
                <KeyboardArrowUpIcon />
              ) : (
                <KeyboardArrowDownIcon />
              )}
            </IconButton>
          </Box>
          {showEducation && <CandidateDetailsEducation candidateId={data.id} />}
        </Stack>
        <a href={`mailto:${data.email}`} style={{display:"block"}}>
          <Button
            variant="contained"
            color="secondary"
            sx={{
              textTransform: "capitalize",
              p: "10px",
              width:"100%"
            }}
            startIcon={
              <img
                src={mail_white}
                alt="contact"
                style={{ width: "24px", height: "24px" }}
              />
            }
          >
            <Typography variant="h6">contact</Typography>
          </Button>
        </a>
      </Stack>
    </Paper>
  );
};

export default CandidateDetails;
