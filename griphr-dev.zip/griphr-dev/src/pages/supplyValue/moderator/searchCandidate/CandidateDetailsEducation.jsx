import { CircularProgress, Stack, Typography } from "@mui/material";
import React, { useEffect } from "react";
import EducationItem from "../candidateProfile/EducationItem";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { getEducation } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";

const CandidateDetailsEducation = ({ candidateId }) => {
  const {
    education,
    isLoadingGetEducation,
    isErrorGetEducation,
    isSuccessGetEducation,
  } = useSelector((state) => state.candidate);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    const fetchEducation = async (id) => {
      try {
        const res = await dispatch(getEducation(id));
        await unwrapResult(res);
        handleClickSnackbar("Education fetched successfully", "success");
      } catch (error) {
        console.log("error", error);
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch education data.",
          "error"
        );
      }
    };
    fetchEducation(candidateId);
  }, [candidateId]);

  return (
    <Stack sx={{ gap: 2, px: 2, pb: "20px" }}>
      {isErrorGetEducation && (
        <Typography variant="h3">Error fetching education!</Typography>
      )}
      {isLoadingGetEducation && <CircularProgress size={20} />}
      {isSuccessGetEducation && (
        <>
          <Stack>
            {education?.length > 0 ? (
              education?.map((edu, index) => (
                <EducationItem
                  key={index}
                  data={edu}
                  isLast={index === education.length - 1}
                />
              ))
            ) : (
              <Typography
                variant="body1"
                sx={{ textAlign: "center", color: "inactive.main" }}
              >
                Your education information is empty
              </Typography>
            )}
          </Stack>
        </>
      )}
    </Stack>
  );
};

export default CandidateDetailsEducation;
