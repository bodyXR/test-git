import { CircularProgress, Stack, Typography } from "@mui/material";
import React, { useEffect } from "react";
import ExperienceItem from "../candidateProfile/ExperienceItem";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { getExperience } from "../../../../redux/slices/moderator/candidate/candidateActions";
import { unwrapResult } from "@reduxjs/toolkit";

const CandidateDetailsExperience = ({ candidateId }) => {
  const {
    experience,
    isLoadingGetExperience,
    isErrorGetExperience,
    isSuccessGetExperience,
  } = useSelector((state) => state.candidate);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    const fetchExperience = async (id) => {
      try {
        const res = await dispatch(getExperience(id));
        await unwrapResult(res);
        handleClickSnackbar("Experience fetched successfully", "success");
      } catch (error) {
        console.log("error", error);
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch experience data.",
          "error"
        );
      }
    };
    fetchExperience(candidateId);
  }, [candidateId]);

  return (
    <Stack sx={{ gap: 2, px: 2, pb: "20px" }}>
      {isErrorGetExperience && (
        <Typography variant="h3">Error fetching work experience!</Typography>
      )}
      {isLoadingGetExperience && <CircularProgress size={20} />}
      {isSuccessGetExperience && (
        <>
          <Stack>
            {experience?.length > 0 ? (
              experience?.map((exp, index) => (
                <ExperienceItem
                  key={index}
                  data={exp}
                  isLast={index === experience.length - 1}
                />
              ))
            ) : (
              <Typography
                variant="body1"
                sx={{ textAlign: "center", color: "inactive.main" }}
              >
                Your work experience information is empty
              </Typography>
            )}
          </Stack>
        </>
      )}
    </Stack>
  );
};

export default CandidateDetailsExperience;
