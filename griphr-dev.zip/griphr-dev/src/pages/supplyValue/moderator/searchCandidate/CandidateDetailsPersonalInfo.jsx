import { Avatar, Box, Button, Stack, Typography } from "@mui/material";
import React from "react";
import StyledCandidatesRowBody1 from "../../../../components/styled/StyledCandidatesRowBody1";
import downloadIcon from "../../../../assets/download_icon_grey.svg";
import call_inactive from "../../../../assets/call_inactive.svg";
import role_inactive from "../../../../assets/role_inactive.svg";
import dollar_icon from "../../../../assets/dollar_icon.svg";
import date_inactive from "../../../../assets/date_inactive.svg";

const CandidateDetailsPersonalInfo = ({ data }) => {
  const candidateProfile = [
    { phone: data.phone, img: call_inactive },
    { system_role: data.system_role, img: role_inactive },
    { hourly_rate: data.hourly_rate, img: dollar_icon },
    { availability: data.availability, img: date_inactive },
  ];

  return (
    <Stack
      sx={{
        flexDirection: { lg: "row" },
        alignItems: { lg: "center" },
        gap: 3,
      }}
    >
      <Stack sx={{ gap: "10px" }}>
        <Stack
          sx={{
            flexDirection: "row",
            alignItems: "center",
            gap: 1.25,
          }}
        >
          <Avatar
            src={data?.profile_picture?.url}
            alt={data?.profile_picture?.name}
            sx={{ width: "80px", height: "80px" }}
          />

          <Stack sx={{ gap: 1.25 }}>
            <Typography
              variant="h5"
              sx={{
                "&:hover": {
                  color: "#66C1FF",
                  textDecoration: "underline",
                },
                textTransform: "capitalize",
                color: "inactive.main",
                fontWeight: 600,
                textOverflow: "ellipsis",
                overflow: "hidden",
                cursor: "pointer",
              }}
            >
              {data?.first_name + " " + data?.last_name}
            </Typography>
            <StyledCandidatesRowBody1
              sx={{ textAlign: "left" }}
              variant="body1"
            >
              {data?.role?.title || "N/A"}
            </StyledCandidatesRowBody1>
          </Stack>
        </Stack>
        {data?.resume?.name ? (
          <a
            href={data?.resume?.url}
            download={data?.resume?.name}
            target="_blank"
            // style={{ alignSelf: "flex-end" }}
          >
            <Button
              variant="contained"
              sx={{
                textTransform: "capitalize",
                p: "12px",
                maxWidth: "240px",
                background: "transparent",
                "&:hover": {
                  background: "#f0f0f0",
                },
              }}
              endIcon={
                <img
                  src={downloadIcon}
                  alt="download resume"
                  style={{ width: "24px", height: "24px" }}
                />
              }
            >
              <Typography
                title={data?.resume?.name}
                variant="h6"
                sx={{
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  color: "inactive.main",
                }}
              >
                {data?.resume?.name}
              </Typography>
            </Button>
          </a>
        ) : (
          <Typography variant="h3" color="primary" pt={{ xs: 2, lg: "20px" }}>
            No resume found!
          </Typography>
        )}
      </Stack>

      <Stack sx={{ gap: { xs: 1.5 } }}>
        {candidateProfile?.map((item, index) => {
          const firstValue = Object.values(item)[0];
          const firstKey = Object.keys(item)[0];
          const unit =
            firstKey === "hourly_rate"
              ? "/h"
              : firstKey === "availability"
              ? "hr/week"
              : "";
          return (
            <Stack
              key={index}
              sx={{ flexDirection: "row", alignItems: "center", gap: 1.75 }}
            >
              <Box
                component={"img"}
                sx={{ width: "20px", height: "20px" }}
                src={item?.img}
              />

              <Typography variant="body1" color="darkGreenAccent">
                {`${firstValue || ""} ${unit}`}
              </Typography>
            </Stack>
          );
        })}
      </Stack>
    </Stack>
  );
};

export default CandidateDetailsPersonalInfo;
