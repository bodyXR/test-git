import { Stack, Typography } from "@mui/material";
import React from "react";
import SkillItem from "../components/SkillItem";

const CandidateDetailsSkills = ({ data }) => {
  return (
    <Stack
      sx={{
        flexDirection: "row",
        justifyContent: data?.length > 0 ? "initial" : "center",
        alignItems: "center",
        gap: 1,
        flexWrap: "wrap",
        pb: "20px",
      }}
    >
      {data?.length > 0 ? (
        data?.map((skill) => <SkillItem key={skill.id} data={skill} />)
      ) : (
        <Typography
          variant="body1"
          sx={{ textAlign: "center", color: "inactive.main" }}
        >
          Your skills information is empty
        </Typography>
      )}
    </Stack>
  );
};

export default CandidateDetailsSkills;
