import React, { useCallback, useEffect, useMemo } from "react";
import { useLocation } from "react-router-dom";
import useTitle from "../../../../hooks/useTitle";
import { Stack, useMediaQuery } from "@mui/material";
import SearchCandidateToolbar from "./SearchCandidateToolbar";
import { useDispatch, useSelector } from "react-redux";
import SearchCandidateFiltersDesktop from "./SearchCandidateFiltersDesktop";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { debounce } from "lodash";
import { getAllCandidates } from "../../../../redux/slices/moderator/candidatesList/candidatesListActions";
import { unwrapResult } from "@reduxjs/toolkit";
import SearchCandidateSelectedSkills from "./SearchCandidateSelectedSkills";
import SearchCandidatesTable from "./SearchCandidatesTable";
import {
  resetCandidatesListFilters,
  resetSelectedCandidates,
  setCurrentFilterParams,
} from "../../../../redux/slices/moderator/candidatesList/candidatesListSlice";
import { resetSearchCandidateFilters } from "../../../../redux/slices/moderator/searchCandidate/searchCandidateSlice";

const SearchCandidate = () => {
  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const location = useLocation();
  useTitle(location);
  const dispatch = useDispatch();

  const {
    selectedSkills: skills,
    experienceYears: experience_years,
    selectedLocations: locations,
    isFilterExtended,
  } = useSelector((state) => state.searchCandidate);
  const {
    selectedRoles: roles,
    selectedEmploymentType: system_roles,
    selectedAvailabilityHours: hourly_availabilities,
    selectedStatus: statuses,
    minHourlyRate: min_hourly_rate,
    maxHourlyRate: max_hourly_rate,
  } = useSelector((state) => state.candidatesList);

  // Memoize filters object to prevent unnecessary recalculations
  const filters = useMemo(
    () => ({
      roles,
      system_roles,
      hourly_availabilities,
      statuses,
      skills: skills.map((skill) => skill.id),
      locations,
    }),
    [roles, system_roles, hourly_availabilities, statuses, skills, locations]
  );
  // Filter out empty or undefined values & Memoize the filtered filters to avoid unnecessary re-renders
  const filteredFilters = useMemo(() => {
    const result = Object.keys(filters).reduce((acc, key) => {
      if (filters[key] && filters[key].length > 0) {
        acc[key] = filters[key];
      }
      return acc;
    }, {});

    if (min_hourly_rate !== 0 || max_hourly_rate !== 0) {
      result.min_hourly_rate = min_hourly_rate;
      result.max_hourly_rate = max_hourly_rate;
    }

    if (experience_years !== 0) {
      result.experience_years = experience_years;
    }

    return result;
  }, [filters, min_hourly_rate, max_hourly_rate, experience_years]);
  console.log("filters", filters);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const fetchAllCandidates = useCallback(
    debounce(async (filters) => {
      try {
        const res = await dispatch(getAllCandidates({ filters }));
        const data = await unwrapResult(res);
        console.log("data from candidates", data);
        handleClickSnackbar("Candidates list loaded successfully", "success");
      } catch (error) {
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch candidates",
          "error"
        );
      }
    }, 1000),
    [dispatch]
  );

  useEffect(() => {
    if (skills.length === 0) {
      // Reset filters when skills length is 0
      dispatch(resetCandidatesListFilters());
      dispatch(resetSearchCandidateFilters());
    }
    dispatch(resetSelectedCandidates());
  }, [skills.length]);

  useEffect(() => {
    // Check if there are any filters present
    const hasFilters = Object.keys(filteredFilters).length > 0;
    // Check if there are any skills selected
    const hasSkills = skills.length > 0;

    if (hasSkills && hasFilters) {
      dispatch(setCurrentFilterParams(filteredFilters));
      fetchAllCandidates(filteredFilters);
    }

    // Cleanup function to cancel debounce on unmount
    return () => {
      fetchAllCandidates.cancel();
    };
  }, [filteredFilters]);

  useEffect(() => {
    return () => {
      dispatch(resetCandidatesListFilters());
      dispatch(resetSearchCandidateFilters());
      dispatch(resetSelectedCandidates());
    };
  }, [dispatch]);

  return (
    <Stack className="searchCandidate" sx={{ height: "100%" }} gap={3}>
      <SearchCandidateToolbar />
      <SearchCandidateSelectedSkills />
      {skills.length > 0 && (
        <Stack sx={{ flexDirection: "row", gap: 1.5, flex: 1 }}>
          {lgMatches && isFilterExtended && <SearchCandidateFiltersDesktop />}
          <SearchCandidatesTable />
        </Stack>
      )}
    </Stack>
  );
};

export default SearchCandidate;
