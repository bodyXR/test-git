import {
  Box,
  ListItemIcon,
  ListItemText,
  Menu,
  useMediaQuery,
} from "@mui/material";
import group_icon_grey from "../../../../assets/group_icon_grey.svg";
import menu_icon_grey from "../../../../assets/menu_icon_grey.svg";
import StyledMenuItem from "../../../../components/styled/StyledMenuItem";
import CustomModal from "../../../../ui/CustomModal";
import AddToJobModal from "../candidateProfile/AddToJobModal";
import AddToTalentModal from "../candidateProfile/AddToTalentModal";
import useModal from "../../../../hooks/useModal";

const SearchCandidateActionsMenu = ({
  userId,
  width = "",
  anchor,
  open,
  onClose,
}) => {
  const smStyles = useMediaQuery((theme) => theme.breakpoints.up("sm"));

  const {
    handleClose: handleAddToJobClose,
    handleOpen: handleAddToJobOpen,
    open: addToJobOpen,
  } = useModal();
  const {
    handleClose: handleAddToTalentClose,
    handleOpen: handleAddToTalentOpen,
    open: addToTalentOpen,
  } = useModal();

  return (
    <>
      <CustomModal
        onClose={handleAddToJobClose}
        open={addToJobOpen}
        title="Add to job list"
      >
        <AddToJobModal
          onClose={handleAddToJobClose}
          candidateId={userId}
          bulkActionMode={userId ? false : true}
        />
      </CustomModal>
      <CustomModal
        onClose={handleAddToTalentClose}
        open={addToTalentOpen}
        title="Add to talent pool"
      >
        <AddToTalentModal
          onClose={handleAddToTalentClose}
          candidateId={userId}
          bulkActionMode={userId ? false : true}
        />
      </CustomModal>
      <Menu
        anchorEl={anchor}
        open={open}
        onClose={onClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
        sx={{
          ".MuiMenu-paper": smStyles
            ? {}
            : {
                width: width || "auto",
                maxWidth: { sm: "600px" },
              },
        }}
      >
        <StyledMenuItem onClick={handleAddToTalentOpen}>
          <ListItemIcon>
            <Box component={"img"} src={group_icon_grey} />
          </ListItemIcon>
          <ListItemText>Add to talent pool</ListItemText>
        </StyledMenuItem>
        <StyledMenuItem onClick={handleAddToJobOpen}>
          <ListItemIcon>
            <Box component={"img"} src={menu_icon_grey} />
          </ListItemIcon>
          <ListItemText>Add to job list</ListItemText>
        </StyledMenuItem>
      </Menu>
    </>
  );
};

export default SearchCandidateActionsMenu;
