import React, { useState, useEffect } from "react";
import { Stack } from "@mui/material";
import StyledSlider from "../../../../components/styled/StyledSlider";
import StyledTextField from "../../../../components/styled/StyledTextField";
import { useDispatch, useSelector } from "react-redux";
import { setExperienceYears } from "../../../../redux/slices/moderator/searchCandidate/searchCandidateSlice";
import FilterSection from "../components/FilterSection";

const SearchCandidateExperienceFilter = () => {
  const dispatch = useDispatch();
  const { experienceYears } = useSelector((state) => state.searchCandidate);

  const [value, setValue] = useState(experienceYears || 0);

  useEffect(() => {
    setValue(experienceYears);
  }, [experienceYears]);

  const handleSliderChange = (event, newValue) => {
    setValue(newValue);
    dispatch(setExperienceYears(newValue));
  };

  const handleExperienceChange = (event) => {
    const newExperience = Number(event.target.value);
    setValue(newExperience);
    dispatch(setExperienceYears(newExperience));
  };

  return (
    <FilterSection title="Experience">
      <StyledSlider
        getAriaLabel={() => "Experience range"}
        value={value}
        onChange={handleSliderChange}
        valueLabelDisplay="auto"
        min={0}
        max={30}
      />
      <Stack sx={{ flexDirection: "row", gap: 1, mt: 1 }}>
        <StyledTextField
          id="experience"
          name="experience"
          variant="outlined"
          placeholder="Experience"
          label="Experience"
          type="number"
          size="medium"
          value={value}
          onChange={handleExperienceChange}
          inputProps={{ min: 0, max: 30 }}
        />
      </Stack>
    </FilterSection>
  );
};

export default SearchCandidateExperienceFilter;
