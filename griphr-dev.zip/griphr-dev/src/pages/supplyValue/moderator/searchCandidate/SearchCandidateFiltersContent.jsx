import React from "react";
import CandidatesListRoleFilter from "../candidatesList/CandidatesListRoleFilter";
import CandidatesListEmploymentFilter from "../candidatesList/CandidatesListEmploymentFilter";
import CandidatesHourlyRateFilter from "../candidatesList/CandidatesListHourlyRateFilter";
import CandidatesListAvailabilityFilter from "../candidatesList/CandidatesListAvailabilityFilter";
import SearchCandidateExperienceFilter from "./SearchCandidateExperienceFilter";
import SearchCandidateLocationsFilter from "./SearchCandidateLocationsFilter";

const SearchCandidateFiltersContent = () => {
  return (
    <>
      <CandidatesListRoleFilter />
      <CandidatesListEmploymentFilter />
      <SearchCandidateExperienceFilter />
      <CandidatesHourlyRateFilter />
      <CandidatesListAvailabilityFilter />
      <SearchCandidateLocationsFilter />
    </>
  );
};

export default SearchCandidateFiltersContent;
