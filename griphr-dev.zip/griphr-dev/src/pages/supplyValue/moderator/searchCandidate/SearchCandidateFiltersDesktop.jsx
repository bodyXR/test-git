import { Typography } from "@mui/material";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import SearchCandidateFiltersContent from "./SearchCandidateFiltersContent";

const SearchCandidateFiltersDesktop = () => {
  return (
    <StyledWrapper
      sx={{
        minWidth: "292px",
        maxWidth: "292px",
        gap: 2,
        height: "62vh",
        overflowY: "auto",
      }}
    >
      <Typography variant="h6">Filters</Typography>
      <SearchCandidateFiltersContent />
    </StyledWrapper>
  );
};

export default SearchCandidateFiltersDesktop;
