import { FormGroup, InputAdornment } from "@mui/material";
import StyledSearchBar from "../../../../components/styled/StyledSearchBar";
import search from "../../../../assets/search.svg";
import { useDispatch, useSelector } from "react-redux";
import {
  addSelectedLocation,
  removeSelectedLocation,
} from "../../../../redux/slices/moderator/searchCandidate/searchCandidateSlice";
import StyledFilterLabel from "../../../../components/styled/StyledFilterLabel";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";
import useSearch from "../../../../hooks/useSearch";
import { useEffect } from "react";
import { getCandidateFilters } from "../../../../redux/slices/moderator/searchCandidate/searchCandidateActions";
import capitalizeFirstWord from "../../../../helper/capitalizeFirstWord";
import FilterSection from "../components/FilterSection";

const SearchCandidateLocationsFilter = () => {
  const { locations, selectedLocations } = useSelector(
    (state) => state.searchCandidate
  );
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getCandidateFilters());
  }, []);

  const { filteredData, setSearchQuery, searchQuery } = useSearch(locations, [
    "name",
  ]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  return (
    <FilterSection title="Location">
      <StyledSearchBar
        name="locationSearch"
        fullWidth
        size="small"
        type="search"
        variant="outlined"
        value={searchQuery}
        onChange={handleSearchChange}
        placeholder="Search"
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <img src={search} alt="search icon" />
            </InputAdornment>
          ),
        }}
      />
      <FormGroup>
        {filteredData?.length > 0 &&
          filteredData.map((location, index) => (
            <StyledFilterLabel
              key={index}
              control={
                <StyledFilterCheckbox
                  checked={selectedLocations.includes(location?.name)}
                  onChange={() => {
                    if (selectedLocations.includes(location?.name)) {
                      dispatch(removeSelectedLocation(location?.name));
                    } else {
                      dispatch(addSelectedLocation(location?.name));
                    }
                  }}
                  name={location?.name}
                />
              }
              label={capitalizeFirstWord(location?.name)}
            />
          ))}
      </FormGroup>
    </FilterSection>
  );
};

export default SearchCandidateLocationsFilter;
