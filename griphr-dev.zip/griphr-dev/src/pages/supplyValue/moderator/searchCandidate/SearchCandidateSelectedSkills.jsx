import { Stack } from "@mui/material";
import React from "react";
import SearchCandidateSkillRow from "./SearchCandidateSkillRow";
import { useSelector } from "react-redux";

const SearchCandidateSelectedSkills = () => {
  const { selectedSkills } = useSelector((state) => state.searchCandidate);

  return (
    <Stack
      sx={{
        flexDirection: "row",
        alignItems: "center",
        gap: "12px",
        flexWrap: "wrap",
      }}
    >
      {selectedSkills?.length > 0 &&
        selectedSkills?.map((skill) => (
          <SearchCandidateSkillRow key={skill.id} data={skill} />
        ))}
    </Stack>
  );
};

export default SearchCandidateSelectedSkills;
