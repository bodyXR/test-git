import { Box, IconButton, Typography } from "@mui/material";
import Close from "@mui/icons-material/Close";
import React from "react";
import { useDispatch } from "react-redux";
import { removeSelectedSkill } from "../../../../redux/slices/moderator/searchCandidate/searchCandidateSlice";

const SearchCandidateSkillRow = ({ data }) => {
  const dispatch = useDispatch();

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: "10px",
        backgroundColor: "darkGreenAccent",
        borderRadius: "100px",
        p: "2px 8px",
      }}
    >
      <Typography
        variant="h6"
        textTransform="none"
        color="white"
        fontWeight="500"
      >
        {data.name}
      </Typography>

      <IconButton
        onClick={() => dispatch(removeSelectedSkill(data.id))}
        sx={{ p: 0 }}
      >
        <Close sx={{ width: "13px", height: "13px", color: "white" }} />
      </IconButton>
    </Box>
  );
};

export default SearchCandidateSkillRow;
