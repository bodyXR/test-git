import { Stack, useMediaQuery } from "@mui/material";
import SearchSkillsModule from "./SearchSkillsModule";
import SearchCandidateActionsModule from "./SearchCandidateActionsModule";
import { useDispatch, useSelector } from "react-redux";
import SearchCandidateFiltersMobileModule from "./SearchCandidateFiltersMobileModule";
import { toggleSearchCandidatesFilters } from "../../../../redux/slices/moderator/searchCandidate/searchCandidateSlice";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import StyledFiltersStateButton from "../components/styled/StyledFiltersStateButton";
import filter from "../../../../assets/filter.svg";

const SearchCandidateToolbar = () => {
  const dispatch = useDispatch();
  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const mdMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("md", "lg")
  );
  const xsMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("xs", "md")
  );

  const { candidates, selectedCandidates } = useSelector(
    (state) => state.candidatesList
  );

  const { selectedSkills: skills, isFilterExtended } = useSelector(
    (state) => state.searchCandidate
  );

  return (
    <Stack
      sx={{
        gap: { xs: 2 },
        flexDirection: { lg: "row" },
        justifyContent: "space-between",
      }}
    >
      <Stack sx={{ flexDirection: "row", width: "100%", gap: 1 }}>
        {skills.length > 0 && lgMatches && (
          <StyledFiltersStateButton
            startIcon={<img src={filter} alt="filter icon" />}
            variant="outlined"
            onClick={() => dispatch(toggleSearchCandidatesFilters())}
          >
            {isFilterExtended ? "Hide filters" : "Show filters"}
          </StyledFiltersStateButton>
        )}
        <SearchSkillsModule />
      </Stack>
      {candidates && candidates?.length > 0 && (
        <>
          {lgMatches && selectedCandidates.length > 0 && (
            <SearchCandidateActionsModule />
          )}
          {mdMatches && (
            <Stack sx={{ gap: { xs: 2 }, flexDirection: { xs: "row" } }}>
              <SearchCandidateFiltersMobileModule />
              {selectedCandidates.length > 0 && (
                <SearchCandidateActionsModule />
              )}
            </Stack>
          )}
          {xsMatches && (
            <>
              <SearchCandidateFiltersMobileModule />
              {selectedCandidates.length > 0 && (
                <SearchCandidateActionsModule />
              )}{" "}
            </>
          )}
        </>
      )}
    </Stack>
  );
};

export default SearchCandidateToolbar;
