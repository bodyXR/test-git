import { clearSelectedCandidateDetails } from "../../../../redux/slices/moderator/searchCandidate/searchCandidateSlice";
import CandidateDetails from "./CandidateDetails";
import SearchCandidatesRow from "./SearchCandidatesRow";
import { useDispatch, useSelector } from "react-redux";

const SearchCandidatesRowsWrapper = () => {
  const dispatch = useDispatch();
  const { searchedCandidates } = useSelector((state) => state.candidatesList);
  const { selectedCandidateDetails } = useSelector(
    (state) => state.searchCandidate
  );

  const handleCandidateDetailsClose = () => {
    dispatch(clearSelectedCandidateDetails());
  };

  return (
    <>
      {searchedCandidates &&
        searchedCandidates.map((candidate, index) => (
          <SearchCandidatesRow
            key={candidate.id}
            isLast={index === searchedCandidates.length - 1}
            data={candidate}
          />
        ))}

      {selectedCandidateDetails && (
        <CandidateDetails
          data={selectedCandidateDetails}
          onClose={handleCandidateDetailsClose}
        />
      )}
    </>
  );
};

export default SearchCandidatesRowsWrapper;
