import { Stack, Typography } from "@mui/material";
import React, { useRef } from "react";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import SearchCandidatesHeaders from "./SearchCandidatesHeaders";
import SearchCandidatesRowsWrapper from "./SearchCandidatesRowsWrapper";
import { useDraggable } from "react-use-draggable-scroll";
import CandidatesListPagination from "../candidatesList/CandidatesListPagination";
import { useSelector } from "react-redux";
import StyledTable from "../components/StyledTable";

const SearchCandidatesTable = () => {
  const ref = useRef();
  const { events } = useDraggable(ref);
  const { paginationStatus } = useSelector((state) => state.candidatesList);

  return (
    <StyledTable
      ref={ref}
      {...events}
    >
      {paginationStatus?.total_candidates > 0 ? (
        <Stack
          className="searchCandidate__table"
          sx={{
            width: { xs: "1170px" },
            height: "100%",
            "& .candidate__row:last-child": {
              borderBottom: "none",
            },
          }}
        >
          <SearchCandidatesHeaders />
          <SearchCandidatesRowsWrapper />{" "}
          <Stack sx={{ p: 2, alignItems: "center" }}>
            <CandidatesListPagination />
          </Stack>
        </Stack>
      ) : (
        <Typography variant="h3" color="primary" pt={{ xs: 2, lg: "20px" }}>
          No results found
        </Typography>
      )}
    </StyledTable>
  );
};

export default SearchCandidatesTable;
