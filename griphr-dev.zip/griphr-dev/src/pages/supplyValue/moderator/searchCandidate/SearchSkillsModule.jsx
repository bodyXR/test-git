import {
  Autocomplete,
  Box,
  CircularProgress,
  InputAdornment,
  TextField,
} from "@mui/material";
import search from "../../../../assets/search.svg";
import { useDispatch, useSelector } from "react-redux";
import { useCallback, useEffect, useState } from "react";
import { useFormik } from "formik";
import axiosInstance from "../../../../helper/axiosInstance";
import { debounce } from "lodash";
import { addSelectedSkill } from "../../../../redux/slices/moderator/searchCandidate/searchCandidateSlice";

const SearchSkillsModule = () => {
  const [value, setValue] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const noSkillsMatch = "No skills match";

  const initialValues = {
    skill: null,
  };

  const formik = useFormik({
    initialValues,
    onSubmit: async (values, { setSubmitting }) => {
      if (values.skill === null || values.skill === noSkillsMatch) {
        // Handle "No skills match" validation
        formik.setFieldError("skill", "Please select a valid skill");
        setSubmitting(false);
        return;
      }
      console.log("object", values);
      dispatch(addSelectedSkill(values.skill));
      formik.setFieldValue("skill", null);
      setInputValue("");
    },
  });

  const searchSkills = useCallback(
    async (token, value) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `search`,
          {
            key: "skill",
            value: value,
          },
          config
        );
        console.log(response.data);
        setOptions(response.data.payload);
      } catch (error) {
        console.log(error?.response?.data?.message);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const debouncedSearchSkills = useCallback(
    debounce((token, inputValue) => {
      if (inputValue !== "") {
        searchSkills(token, inputValue);
      } else {
        setOptions([]);
      }
    }, 1000),
    []
  );

  useEffect(() => {
    debouncedSearchSkills(token, inputValue);
  }, [debouncedSearchSkills, token, inputValue]);

  const selectValue = useCallback(
    (e, optionName) => {
      const selectedOption = options.find(
        (option) => option.name === optionName
      );

      if (selectedOption) {
        formik.setFieldValue("skill", selectedOption);
        formik.handleSubmit();
      } else {
        formik.setFieldValue("skill", null);
      }
    },
    [formik, options]
  );

  const handleInputChange = (event, newValue) => {
    setInputValue(newValue);
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: { xs: 3 },
        width: "100%",
      }}
      component={"form"}
      onSubmit={formik.handleSubmit}
    >
      <Autocomplete
        freeSolo
        // disableClearable --> to disable close icon (second icon)
        disableClearable
        id="skill"
        name="skill"
        fullWidth
        value={value}
        options={
          options.length < 1
            ? [noSkillsMatch].map((option) => option)
            : options.map((option) => option.name)
        }
        inputValue={inputValue}
        onInputChange={handleInputChange}
        onBlur={formik.handleBlur}
        onChange={(e, value) => selectValue(e, value)}
        renderInput={(params) => (
          <TextField
            error={formik.touched.skill && Boolean(formik.errors.skill)}
            helperText={formik.touched.skill ? formik.errors.skill : ""}
            name="skill"
            fullWidth
            size="small"
            label="Skills"
            placeholder="Skills"
            {...params}
            type="search"
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <InputAdornment position="end">
                  <div style={{ display: "flex", alignItems: "center" }}>
                    {params.InputProps.endAdornment}
                    {loading && <CircularProgress size={20} sx={{ mr: 1 }} />}
                    <img src={search} alt="search icon" />
                  </div>
                </InputAdornment>
              ),
            }}
            sx={{
              alignSelf: "stretch",
              background: "white",
              "& .MuiInputBase-root": {
                paddingBlock: "4.45px",
                pr: "14px",
              },
              "& .MuiFormLabel-root": {
                top: "-4px",
              },
            }}
          />
        )}
      />
    </Box>
  );
};

export default SearchSkillsModule;
