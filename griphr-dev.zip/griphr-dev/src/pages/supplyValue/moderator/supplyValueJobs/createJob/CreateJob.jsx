import { Box, Stack, Typography, useMediaQuery, useTheme } from "@mui/material";
import React, { useEffect } from "react";
import { MODERATOR_JOBS_ROUTE } from "../../../../../routes/paths";
import { Link, useNavigate } from "react-router-dom";
import StyledDarkBtn from "../../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../../components/styled/StyledDarkOutlinedBtn";
import { addJobValidationSchema } from "./addJobValidationSchema";
import { useFormik } from "formik";
import { useDispatch } from "react-redux";
import { unwrapResult } from "@reduxjs/toolkit";
import {
  createJob,
  getRecommendationSkills,
} from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import JobDetailsCreationSection from "./JobDetailsCreationSection";
import JobDescriptionCreationSection from "./JobDescriptionCreationSection";
import JobSkillsCreationSection from "./JobSkillsCreationSection";
import DOMPurify from "dompurify";
import { deleteAllSelectedSkills } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const CreateJob = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const theme = useTheme();
  const mdMatches = useMediaQuery(theme.breakpoints.up("md"));

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const initialValues = {
    job_profile_id: "",
    company_name: "",
    start_date: "",
    end_date: "",
    vacancy_number: +"",
    hours: "",
    salary: "",
    description: "",
    skills: [],
  };

  const formik = useFormik({
    initialValues,
    validationSchema: addJobValidationSchema,
    onSubmit: async (values, { resetForm }) => {
      const sanitizedDescription = DOMPurify.sanitize(values.description, {
        USE_PROFILES: { html: true },
      });
      formik.setFieldValue("description", sanitizedDescription);
      // filter values to remove empty key-value pairs
      // and return only the ones that have values into new object
      const filteredValues = Object.fromEntries(
        Object.entries(values).filter(([key, value]) => value)
      );

      try {
        const res = await dispatch(createJob(filteredValues));

        await unwrapResult(res);

        handleClickSnackbar("Candidate added successfully", "success");
        dispatch(deleteAllSelectedSkills());
        resetForm();
        navigate(MODERATOR_JOBS_ROUTE);
      } catch (error) {
        handleClickSnackbar(error, "error");
      }
    },
  });

  useEffect(() => {
    return () => {
      dispatch(deleteAllSelectedSkills());
    };
  }, [dispatch]);

  useEffect(() => {
    if (formik.values.job_profile_id) {
      dispatch(getRecommendationSkills(formik.values.job_profile_id));
    }
  }, [formik.values.job_profile_id]);

  return (
    <Box component="form" onSubmit={formik.handleSubmit}>
      <Stack>
        <Typography variant={mdMatches ? "h2" : "h1"} color="darkGreen">
          New Job
        </Typography>

        <JobDetailsCreationSection formik={formik} />
        <JobDescriptionCreationSection formik={formik} />
        <JobSkillsCreationSection formik={formik} />

        <Stack
          sx={{
            gap: mdMatches ? 3 : 1,
            mt: 3,
            alignSelf: mdMatches ? "flex-start" : "stretch",
            display: "flex",
            flexDirection: mdMatches ? "row" : "column",
          }}
        >
          <StyledDarkBtn
            disabled={formik.isSubmitting}
            sx={{ flex: { xs: 1 }, px: 10 }}
            type="submit"
          >
            Submit
          </StyledDarkBtn>

          <Link to={MODERATOR_JOBS_ROUTE}>
            <StyledDarkOutlinedBtn
              onClick={() => {}}
              sx={{ flex: { xs: 1 }, px: 10 }}
              fullWidth
            >
              Cancel
            </StyledDarkOutlinedBtn>
          </Link>
        </Stack>
      </Stack>
    </Box>
  );
};

export default CreateJob;
