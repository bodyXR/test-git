import { Box, Typography } from "@mui/material";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { setSelectedSkill } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";

const GreySkillItem = ({
  formik,
  data,
  editMode = false,
  selectValueInEditMode,
}) => {
  const { selectedSkills } = useSelector((state) => state.jobVacancy);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleAddSkill = (skill) => {
    // check with skill_ref if the skill is already selected
    if (
      formik.values?.skills &&
      formik.values?.skills.length > 0 &&
      selectedSkills.some((item) => item.skill_ref === skill?.id)
    ) {
      handleClickSnackbar("Skill is already selected", "error");
      return;
    }
    if (editMode) {
      selectValueInEditMode({ ...skill, name: skill?.title });
      return;
    }

    dispatch(
      setSelectedSkill({
        skill_ref: skill?.id,
        title: skill?.title,
        level: 1,
      })
    );
  };

  return (
    <Box
      onClick={() => handleAddSkill(data)}
      sx={{
        background: "rgba(23, 52, 51, 0.40)",
        borderRadius: "100px",
        py: "4px",
        px: "12px",
        cursor: "pointer",
      }}
    >
      <Typography
        variant="h6"
        textTransform="none"
        color="#FFFFFF"
        fontWeight="500"
      >
        {data?.title}
      </Typography>
    </Box>
  );
};

export default GreySkillItem;
