import { Typography } from "@mui/material";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import Editor from "../../../../../components/createSupplyValueJob/Editor";

const JobDescriptionCreationSection = ({ formik }) => {
  return (
    <StyledWrapper sx={{ mt: 3, gap: 3 }}>
      <Typography variant="h3" color={"darkGreenAccent"}>
        Description
      </Typography>

      <Editor
        name="description"
        value={formik.values.description}
        onChange={(data) => {
          formik.setFieldValue("description", data);
        }}
        editorLoaded={true}
      />
    </StyledWrapper>
  );
};

export default JobDescriptionCreationSection;
