import { Stack, Typography } from "@mui/material";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import StyledTextField from "../../../../../components/styled/StyledTextField";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import JobSearchRole from "./JobSearchRole";

const JobDetailsCreationSection = ({ formik, editMode = false }) => {
  return (
    <StyledWrapper sx={{ mt: 3, gap: 3 }}>
      <Typography variant="h3" color={"darkGreen"}>
        Details
      </Typography>
      <Grid2 container spacing={2.5}>
        <Grid2 xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <JobSearchRole formik={formik} editMode={editMode} />
          </Stack>
        </Grid2>
        <Grid2 xs={12} lg={6}>
          <Stack sx={{ alignItems: { xs: "stretch" } }}>
            <StyledTextField
              name="company_name"
              fullWidth
              label="Company name"
              placeholder="company_name"
              type="text"
              value={formik.values.company_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              helperText={
                formik.touched.company_name ? formik.errors.company_name : ""
              }
              error={
                formik.touched.company_name &&
                Boolean(formik.errors.company_name)
              }
            />
          </Stack>
        </Grid2>
        <Grid2 xs={12} lg={6}>
          <StyledTextField
            name="start_date"
            fullWidth
            label="Start date"
            type="date"
            InputLabelProps={{
              shrink: true,
            }}
            required
            value={formik.values.start_date}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            helperText={
              formik.touched.start_date ? formik.errors.start_date : ""
            }
            error={
              formik.touched.start_date && Boolean(formik.errors.start_date)
            }
          />
        </Grid2>
        <Grid2 xs={12} lg={6}>
          <StyledTextField
            name="end_date"
            fullWidth
            label="End date"
            type="date"
            InputLabelProps={{
              shrink: true,
            }}
            value={formik.values.end_date}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            helperText={formik.touched.end_date ? formik.errors.end_date : ""}
            error={formik.touched.end_date && Boolean(formik.errors.end_date)}
          />
        </Grid2>
        <Grid2 xs={12} lg={6}>
          <StyledTextField
            name="vacancy_number"
            fullWidth
            label="Open position"
            placeholder="Open position"
            type="number"
            value={formik.values.vacancy_number}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            helperText={
              formik.touched.vacancy_number ? formik.errors.vacancy_number : ""
            }
            error={
              formik.touched.vacancy_number &&
              Boolean(formik.errors.vacancy_number)
            }
          />
        </Grid2>
        <Grid2 xs={12} lg={6}>
          <StyledTextField
            name="hours"
            fullWidth
            label="Hours"
            placeholder="Hours"
            type="number"
            value={formik.values.hours}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            helperText={formik.touched.hours ? formik.errors.hours : ""}
            error={formik.touched.hours && Boolean(formik.errors.hours)}
          />
        </Grid2>
        <Grid2 xs={12} lg={6}>
          <StyledTextField
            name="salary"
            fullWidth
            label="Salary"
            placeholder="Salary"
            type="text"
            value={formik.values.salary}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            helperText={formik.touched.salary ? formik.errors.salary : ""}
            error={formik.touched.salary && Boolean(formik.errors.salary)}
          />
        </Grid2>
      </Grid2>
    </StyledWrapper>
  );
};

export default JobDetailsCreationSection;
