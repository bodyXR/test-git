import { Stack, Typography } from "@mui/material";
import React from "react";
import { useSelector } from "react-redux";
import GreySkillItem from "./GreySkillItem";

const JobRecommendationSkills = ({
  formik,
  editMode,
  selectValueInEditMode,
}) => {
  const { recommendationSkills } = useSelector((state) => state.jobVacancy);

  return (
    <>
      <Typography color={"darkGreenAccent"}>Suggested skills</Typography>

      <Stack
        sx={{
          flexDirection: "row",
          alignItems: "center",
          gap: "12px",
          flexWrap: "wrap",
        }}
      >
        {recommendationSkills &&
          recommendationSkills?.length > 0 &&
          recommendationSkills
            ?.slice(0, 10)
            ?.map((skill) => (
              <GreySkillItem
                key={skill?.id}
                formik={formik}
                data={skill}
                editMode={editMode}
                selectValueInEditMode={selectValueInEditMode}
              />
            ))}
        {(!recommendationSkills || recommendationSkills?.length === 0) && (
          <Typography variant="h6" color="darkGreen">
            No recommendation skills founded!
          </Typography>
        )}
      </Stack>
    </>
  );
};

export default JobRecommendationSkills;
