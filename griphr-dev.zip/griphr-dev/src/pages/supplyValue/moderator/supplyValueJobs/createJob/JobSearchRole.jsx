import {
  Autocomplete,
  CircularProgress,
  IconButton,
  InputAdornment,
} from "@mui/material";
import { useCallback, useEffect, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../../../helper/axiosInstance";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import StyledTextField from "../../../../../components/styled/StyledTextField";
import { debounce } from "lodash";

// Move this component to components Folder inside moderator folder
const JobSearchRole = ({ formik, editMode = false }) => {
  const { selectedJob } = useSelector((state) => state.jobVacancy);
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [inputJobRoleValue, setInputJobRoleValue] = useState(
    editMode ? selectedJob?.role?.title : ""
  );
  const [jobRoleOptions, setJobRoleOptions] = useState([]);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleInputChange = (event, newValue) => {
    setInputJobRoleValue(newValue);
  };

  const searchJobs = useCallback(
    async (value) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `search`,
          {
            key: "job_profile",
            value: value,
          },
          config
        );

        setJobRoleOptions(response?.data?.payload);

        return response?.data?.payload;
      } catch (error) {
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch roles!!",
          "error"
        );
        console.log(error?.response?.data?.message);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const addRole = useCallback(
    async (title) => {
      // Remove double quotes from the title
      const roleTitle = title.replace(/"/g, "");

      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        const response = await axiosInstance.post(
          `job_profile`,
          {
            title: roleTitle,
          },
          config
        );
        console.log(response.data);
        return response?.data?.payload?.id;
      } catch (error) {
        setInputJobRoleValue("");
        console.log(error?.response?.data?.message);
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to add a new role!!",
          "error"
        );
      }
    },
    [token]
  );

  const debouncedSearchJobs = useCallback(
    debounce((inputJobRoleValue) => {
      if (inputJobRoleValue !== "") {
        searchJobs(inputJobRoleValue);
      } else {
        setJobRoleOptions([]);
      }
    }, 1000),
    []
  );

  useEffect(() => {
    debouncedSearchJobs(inputJobRoleValue);
    return () => {
      debouncedSearchJobs.cancel();
    };
  }, [debouncedSearchJobs, inputJobRoleValue]);

  return (
    <Autocomplete
      freeSolo
      id="job_profile_id"
      name="job_profile_id"
      value={inputJobRoleValue}
      options={[
        ...jobRoleOptions.map((option) => option.title),
        // Add "Add 'string that user typed'" option conditionally
        inputJobRoleValue &&
        !jobRoleOptions.some((option) => option.title === inputJobRoleValue)
          ? `Add "${inputJobRoleValue}"`
          : null,
      ].filter(Boolean)}
      inputValue={inputJobRoleValue}
      onInputChange={(event, newValue) => {
        handleInputChange(event, newValue, "role");
      }}
      onBlur={formik.handleBlur}
      onChange={async (e, value) => {
        try {
          if (value && value.startsWith("Add ")) {
            // Handle adding the role here
            const newRole = value.substring(4);
            // Call the addRole function to add the new role
            const newRoleId = await addRole(newRole);
            if (newRoleId) {
              // Update your formik field with the newly added role ID
              formik.setFieldValue("job_profile_id", newRoleId);
            }
          } else {
            // Check if a valid option is selected
            const selectedOption = jobRoleOptions.find(
              (option) => option.title === value
            );

            if (selectedOption) {
              // Update your formik field with the selected option
              formik.setFieldValue("job_profile_id", selectedOption.id);
            } else {
              // If the selected option is not in the current options, it may be a newly added role
              // In this case, you may handle it based on your requirements
            }
          }
        } catch (error) {
          handleClickSnackbar(
            error?.response?.data?.message || "Fail to add a new role!!",
            "error"
          );
        }
      }}
      renderInput={(params) => (
        <StyledTextField
          error={
            formik.touched.job_profile_id &&
            Boolean(formik.errors.job_profile_id)
          }
          helperText={
            formik.touched.job_profile_id ? formik.errors.job_profile_id : ""
          }
          name="job_profile_id"
          fullWidth
          label="Search or add new role"
          placeholder="Search or add new Role"
          {...params}
          required
          type="search"
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <InputAdornment position="end">
                <div style={{ display: "flex", alignItems: "center" }}>
                  {params.InputProps.endAdornment}
                  {loading && <CircularProgress size={20} />}
                </div>

                <IconButton>
                  <SearchIcon />
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
      )}
    />
  );
};

export default JobSearchRole;
