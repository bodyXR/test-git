import {
  Autocomplete,
  CircularProgress,
  IconButton,
  InputAdornment,
  TextField,
  Typography,
} from "@mui/material";
import React, { useCallback, useEffect, useState } from "react";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import SearchIcon from "@mui/icons-material/Search";
import JobSkillsSelected from "./JobSkillsSelected";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import axiosInstance from "../../../../../helper/axiosInstance";
import { debounce } from "lodash";
import {
  setSelectedSkill,
  setSelectedSkills,
} from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import {
  addVacancySkill,
  getJobById,
} from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";
import JobRecommendationSkills from "./JobRecommendationSkills";
import { useParams } from "react-router-dom";

const JobSkillsCreationSection = ({ formik, editMode = false }) => {
  const [value, setValue] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const { jobId } = useParams();
  const { token } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const noSkillsMatch = "No skills match";
  const { selectedJob, selectedSkills } = useSelector(
    (state) => state.jobVacancy
  );

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    const skills = selectedJob?.role?.skills;
    if (editMode && skills) {
      const skillsArray = skills.map((skill) => ({
        skill_ref: skill?.skill_ref,
        title: skill?.title,
        level: 1,
        id: skill?.id,
      }));
      dispatch(setSelectedSkills(skillsArray));
    }
  }, [editMode, selectedJob?.role?.skills]);

  const searchSkills = useCallback(
    async (token, value) => {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      };

      try {
        setLoading(true);
        const response = await axiosInstance.post(
          `search`,
          {
            key: "skill",
            value,
          },
          config
        );
        console.log(response.data);
        setOptions(response.data.payload);
      } catch (error) {
        console.log(error?.response?.data?.message);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  const debouncedSearchSkills = useCallback(
    debounce((token, inputValue) => {
      if (inputValue !== "") {
        searchSkills(token, inputValue);
      } else {
        setOptions([]);
      }
    }, 1000),
    []
  );

  useEffect(() => {
    debouncedSearchSkills(token, inputValue);
    return () => {
      debouncedSearchSkills.cancel();
    };
  }, [debouncedSearchSkills, token, inputValue]);

  const selectValueInEditMode = async (selectedOption) => {
    try {
      const res = await dispatch(
        addVacancySkill({
          vacancy_role_id: selectedJob?.role?.id,
          skill_ref: selectedOption?.id,
          level: 1,
        })
      );
      await unwrapResult(res);
      dispatch(getJobById(jobId));
      handleClickSnackbar("Skill added successfully", "success");
      setInputValue("");
    } catch (error) {
      handleClickSnackbar(error || "Fail to add skill!", "error");
    }
  };
  const selectValue = useCallback(
    (e, optionName) => {
      const selectedOption = options.find(
        (option) => option.name === optionName
      );

      if (selectedOption) {
        console.log("selected option", selectedOption);
        // check with skill_ref if the skill is already selected
        if (
          formik.values?.skills &&
          formik.values?.skills.length > 0 &&
          selectedSkills.some((skill) => skill.skill_ref === selectedOption?.id)
        ) {
          handleClickSnackbar("Skill is already selected", "error");
          return;
        }
        if (editMode) {
          selectValueInEditMode(selectedOption);
          return;
        }

        dispatch(
          setSelectedSkill({
            skill_ref: selectedOption?.id,
            title: selectedOption?.name,
            level: 1,
          })
        );
        setInputValue("");
      } else {
        formik.setFieldValue("skills", "");
      }
    },
    [formik, options]
  );

  const handleInputChange = (event, newValue) => {
    setInputValue(newValue);
  };

  useEffect(() => {
    formik.setFieldValue("skills", selectedSkills);
  }, [selectedSkills]);

  return (
    <StyledWrapper sx={{ mt: 3, gap: 3 }}>
      <Typography variant="h3" color={"darkGreenAccent"}>
        Skills
      </Typography>
      <Autocomplete
        freeSolo
        id="skills"
        name="skills"
        value={value}
        options={
          options.length < 1
            ? [noSkillsMatch].map((option) => option)
            : options.map((option) => option.name)
        }
        inputValue={inputValue}
        onInputChange={handleInputChange}
        onBlur={formik.handleBlur}
        onChange={(e, value) => selectValue(e, value)}
        label="Search input"
        sx={{ mt: "16px" }}
        renderInput={(params) => (
          <TextField
            error={formik.touched.skills && Boolean(formik.errors.skills)}
            helperText={formik.touched.skills ? formik.errors.skills : ""}
            name="skills"
            fullWidth
            placeholder="Search skill"
            {...params}
            type="search"
            InputProps={{
              ...params.InputProps,
              startAdornment: (
                <InputAdornment position="start">
                  <IconButton>
                    <SearchIcon />
                  </IconButton>
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end">
                  <div style={{ display: "flex", alignItems: "center" }}>
                    {params.InputProps.endAdornment}
                    {loading && <CircularProgress size={20} />}
                  </div>
                </InputAdornment>
              ),
            }}
          />
        )}
      />

      <JobRecommendationSkills
        formik={formik}
        editMode={editMode}
        selectValueInEditMode={selectValueInEditMode}
      />
      <JobSkillsSelected editMode={editMode} />
    </StyledWrapper>
  );
};

export default JobSkillsCreationSection;
