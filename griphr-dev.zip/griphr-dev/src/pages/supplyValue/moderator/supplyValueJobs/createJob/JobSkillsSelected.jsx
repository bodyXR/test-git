import { Stack, Typography } from "@mui/material";
import React from "react";
import { useSelector } from "react-redux";
import RemovableSkillItem from "../../components/RemovableSkillItem";

const JobSkillsSelected = ({ editMode }) => {
  const { selectedSkills } = useSelector((state) => state.jobVacancy);

  return (
    <>
      <Typography color={"darkGreenAccent"}>Selected skills</Typography>

      <Stack
        sx={{
          flexDirection: "row",
          alignItems: "center",
          gap: "12px",
          flexWrap: "wrap",
        }}
      >
        {selectedSkills &&
          selectedSkills?.length > 0 &&
          selectedSkills?.map((skill, i) => (
            <RemovableSkillItem
              key={skill?.skill_ref}
              data={skill}
              editMode={editMode}
            />
          ))}
        {(!selectedSkills || selectedSkills?.length === 0) && (
          <Typography variant="h6" color="darkGreen">
            No skills selected yet!
          </Typography>
        )}
      </Stack>
    </>
  );
};

export default JobSkillsSelected;
