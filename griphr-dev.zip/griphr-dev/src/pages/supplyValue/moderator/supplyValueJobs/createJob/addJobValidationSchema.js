import * as yup from "yup";

export const addJobValidationSchema = yup.object().shape({
  job_profile_id: yup.string().required("job profile is required"),
  company_name: yup.string().optional(),
  start_date: yup.string().required("start date is required"),
  end_date: yup.string().optional(),
  vacancy_number: yup.number().optional(),
  hours: yup.string().optional(),
  salary: yup.string().optional(),
  description: yup
    .string()
    .optional()
    .max(20000, "Description must be within 20000 characters"),
  skills: yup
    .array()
    .of(
      yup.object().shape({
        skill_ref: yup.string().required("Skill is required"),
        level: yup.number().required("Experience is required"),
      })
    )
    .min(1, "At least one skill is required"),
});
