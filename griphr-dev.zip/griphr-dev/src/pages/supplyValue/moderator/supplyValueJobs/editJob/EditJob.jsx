import { Box, Stack, Typography, useMediaQuery, useTheme } from "@mui/material";
import React, { useEffect } from "react";
import {
  MODERATOR_JOBS_ROUTE,
  MODERATOR_PAGE_ROUTE,
} from "../../../../../routes/paths";
import { Link, useNavigate, useParams } from "react-router-dom";
import StyledDarkBtn from "../../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../../components/styled/StyledDarkOutlinedBtn";
import { useFormik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { unwrapResult } from "@reduxjs/toolkit";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import JobDetailsCreationSection from "../createJob/JobDetailsCreationSection";
import JobDescriptionCreationSection from "../createJob/JobDescriptionCreationSection";
import JobSkillsCreationSection from "../createJob/JobSkillsCreationSection";
import DOMPurify from "dompurify";
import { deleteAllSelectedSkills } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import {
  editJobVacancy,
  editVacancyRole,
  getJobById,
  getRecommendationSkills,
} from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { addJobValidationSchema } from "../createJob/addJobValidationSchema";

const EditJob = () => {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const theme = useTheme();
  const mdMatches = useMediaQuery(theme.breakpoints.up("md"));
  const {
    selectedJob,
    isLoadingGettingJob,
    isErrorGettingJob,
    isSuccessGettingJob,
  } = useSelector((state) => state.jobVacancy);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    const fetchJob = async () => {
      try {
        const res = await dispatch(getJobById(jobId));
        await unwrapResult(res);
        handleClickSnackbar("fetched Job successfully", "success");
      } catch (error) {
        console.log(error);
        handleClickSnackbar(error || "Fail to fetch Job", "error");
      }
    };

    fetchJob();
  }, []);

  useEffect(() => {
    if (isSuccessGettingJob) {
      formik.setValues({
        job_profile_id: selectedJob?.role?.job_profile_id || "",
        company_name: selectedJob?.company_name || "",
        start_date: selectedJob?.role?.start_date || "",
        end_date: selectedJob?.role?.end_date || "",
        vacancy_number: selectedJob?.vacancy_number || +"",
        hours: selectedJob?.role?.hours || "",
        salary: selectedJob?.role?.salary || "",
        description: selectedJob?.role?.description || "",
        skills: selectedJob?.role?.skills || [],
      });
    }
  }, [selectedJob, isSuccessGettingJob]);

  const formik = useFormik({
    initialValues: {
      job_profile_id: "",
      company_name: "",
      start_date: "",
      end_date: "",
      vacancy_number: +"",
      hours: "",
      salary: "",
      description: "",
      skills: [],
    },
    validationSchema: addJobValidationSchema,
    onSubmit: async (values, { resetForm }) => {
      const sanitizedDescription = DOMPurify.sanitize(values.description, {
        USE_PROFILES: { html: true },
      });
      formik.setFieldValue("description", sanitizedDescription);
      // filter values to remove empty key-value pairs
      // and return only the ones that have values into new object
      const filteredValues = Object.fromEntries(
        Object.entries(values).filter(([key, value]) => value)
      );

      try {
        // check if there are company_name or or vacancy_number in the filteredValues
        if (filteredValues?.company_name || filteredValues?.vacancy_number) {
          const { company_name, vacancy_number } = filteredValues;
          const res = await dispatch(
            editJobVacancy({
              company_name,
              vacancy_number,
              id: selectedJob?.id,
            })
          );

          await unwrapResult(res);
        }
        const res = await dispatch(
          editVacancyRole({ ...filteredValues, id: selectedJob?.role?.id })
        );
        await unwrapResult(res);
        handleClickSnackbar("Candidate added successfully", "success");
        dispatch(deleteAllSelectedSkills());
        resetForm();
        navigate(`${MODERATOR_PAGE_ROUTE}/jobs/${selectedJob?.id}/details`);
      } catch (error) {
        handleClickSnackbar(error, "error");
      }
    },
  });

  useEffect(() => {
    console.log(formik.values);
  }, [formik.values]);

  useEffect(() => {
    return () => {
      dispatch(deleteAllSelectedSkills());
    };
  }, [dispatch]);

  useEffect(() => {
    if (formik.values.job_profile_id) {
      dispatch(getRecommendationSkills(formik.values.job_profile_id));
    }
  }, [formik.values.job_profile_id]);

  return (
    <>
      {isErrorGettingJob && (
        <Typography variant="h2" sx={{ textAlign: "center" }}>
          Error fetching job
        </Typography>
      )}
      {isSuccessGettingJob && selectedJob && (
        <Box component="form" onSubmit={formik.handleSubmit}>
          <Stack>
            <Typography variant={mdMatches ? "h2" : "h1"} color="darkGreen">
              {`Edit ${selectedJob?.role?.title}`}
            </Typography>
            <JobDetailsCreationSection formik={formik} editMode />
            <JobDescriptionCreationSection formik={formik} />
            <JobSkillsCreationSection formik={formik} editMode />

            <Stack
              sx={{
                gap: mdMatches ? 3 : 1,
                mt: 3,
                alignSelf: mdMatches ? "flex-start" : "stretch",
                display: "flex",
                flexDirection: mdMatches ? "row" : "column",
              }}
            >
              <StyledDarkBtn
                disabled={formik.isSubmitting}
                sx={{ flex: { xs: 1 }, px: 10 }}
                type="submit"
              >
                Edit
              </StyledDarkBtn>

              <Link to={MODERATOR_JOBS_ROUTE}>
                <StyledDarkOutlinedBtn
                  onClick={() => {}}
                  sx={{ flex: { xs: 1 }, px: 10 }}
                  fullWidth
                >
                  Cancel
                </StyledDarkOutlinedBtn>
              </Link>
            </Stack>
          </Stack>
        </Box>
      )}
      {isSuccessGettingJob && !selectedJob && (
        <Typography variant="h2" sx={{ textAlign: "center" }}>
          Job Doesn't Exist!
        </Typography>
      )}
    </>
  );
};

export default EditJob;
