import { Avatar, Menu, MenuItem, Stack, Typography } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import StyledFilterCheckbox from "../../../../../components/styled/StyledFilterCheckbox";
import {
  addSelectedJobCandidate,
  removeSelectedJobCandidate,
  setSelectedJobCandidateDetails,
} from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import { Link, useParams } from "react-router-dom";
import StyledCandidatesRowBody1 from "../../../../../components/styled/StyledCandidatesRowBody1";
import StyledSingleActionsBtn from "../../../../../components/styled/StyledSingleActionsBtn";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import { deleteJobCandidateAndGetAll } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";
import useMenu from "../../../../../hooks/useMenu";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import StatusButton from "./StatusButton";
import Grid from "@mui/material/Unstable_Grid2";
import { getCandidateById } from "../../../../../redux/slices/moderator/candidatesList/candidatesListActions";
import useDialog from "../../../../../hooks/useDialog";
import DeleteModule from "../../components/DeleteModule";

const CandidateRow = ({ data }) => {
  const { jobId } = useParams();
  const { handleClose, handleOpen, menuAnchorEl, open } = useMenu();
  const dispatch = useDispatch();
  const { selectedJobCandidates, selectedJob } = useSelector(
    (state) => state.jobVacancy
  );
  const { openDialog, handleOpenDialog, handleCloseDialog } = useDialog();
  const [isDeletingCandidate, setIsDeletingCandidate] = useState(false);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleCandidateDetailsOpen = async () => {
    try {
      const fetchCandidateById = await dispatch(
        getCandidateById(data?.user.id)
      );
      const candidateData = await unwrapResult(fetchCandidateById);
      dispatch(setSelectedJobCandidateDetails(candidateData));
    } catch (error) {
      console.log("Error feaching data!");
    }
  };

  const handleDeleteUser = async () => {
    try {
      setIsDeletingCandidate(true);
      const deleteCandidateAndGetAllResult = await dispatch(
        deleteJobCandidateAndGetAll({ id: data?.id, job_vacancy_id: jobId })
      );
      await unwrapResult(deleteCandidateAndGetAllResult);
      setIsDeletingCandidate(false);
      handleClickSnackbar("Candidate deleted successfully", "success");
    } catch (error) {
      handleClickSnackbar(
        error?.response?.data?.message || "Fail to delete candidate",
        "error"
      );
    }
  };

  return (
    <>
      <DeleteModule
        openDialog={openDialog}
        handleDelete={handleDeleteUser}
        handleCloseDialog={handleCloseDialog}
        title="candidate"
        isDeleting={isDeletingCandidate}
      />
      <Grid
        className="candidate__row"
        container
        sx={{
          alignItems: "center",
          borderBottom: "2px solid #EEE",
          p: 2,
        }}
      >
        <Grid item xs={0.5}>
          <StyledFilterCheckbox
            checked={selectedJobCandidates.includes(data.user.id)}
            onChange={() => {
              selectedJobCandidates.includes(data.user.id)
                ? dispatch(removeSelectedJobCandidate(data.user.id))
                : dispatch(addSelectedJobCandidate(data.user.id));
            }}
          />
        </Grid>

        <Grid item xs={2.5}>
          <Stack
            sx={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Stack
              sx={{
                flexDirection: "row",
                alignItems: "center",
                gap: 1.25,
              }}
            >
              <Avatar
                src={data?.user?.profile_pic}
                alt={"profile picture"}
                sx={{ width: "40px", height: "40px" }}
              />

              <Stack sx={{ gap: 0.25 }}>
                <Typography
                  variant="h5"
                  sx={{
                    "&:hover": {
                      color: "#66C1FF",
                      textDecoration: "underline",
                    },
                    textTransform: "capitalize",
                    color: "inactive.main",
                    fontWeight: 600,
                    textOverflow: "ellipsis",
                    overflow: "hidden",
                    cursor: "pointer",
                  }}
                  onClick={() => handleCandidateDetailsOpen()}
                >
                  {data?.user?.first_name + " " + data?.user?.last_name}
                </Typography>
                <StyledCandidatesRowBody1
                  sx={{ textAlign: "left" }}
                  variant="body1"
                >
                  {data?.user?.title || "N/A"}
                </StyledCandidatesRowBody1>
              </Stack>
            </Stack>
          </Stack>
        </Grid>

        {/* Availability Col */}
        <Grid item xs={1.5}>
          <StyledCandidatesRowBody1
            variant="body1"
            sx={{ textTransform: "none" }}
          >
            {data?.user?.availability
              ? `${data?.user?.availability}hr/w`
              : "N/A"}
          </StyledCandidatesRowBody1>
        </Grid>

        {/* Hourly-Rate Col */}
        <Grid item xs={1.5}>
          <StyledCandidatesRowBody1
            variant="body1"
            sx={{ textTransform: "none" }}
          >
            {data?.user?.hourly_rate ? `€${data?.user?.hourly_rate}` : "N/A"}
          </StyledCandidatesRowBody1>
        </Grid>

        {/* Skills Col */}
        <Grid item xs={1.5}>
          <StyledCandidatesRowBody1
            variant="body1"
            sx={{ textTransform: "none" }}
          >
            {data?.skills}
          </StyledCandidatesRowBody1>
        </Grid>

        {/* Status Col */}
        <Grid
          item
          xs={2}
          sx={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
          }}
        >
          <StatusButton data={data} />
        </Grid>

        {/* Actions Col */}
        <Grid item xs={1.5} sx={{ textAlign: "right" }}>
          <StyledSingleActionsBtn
            expand={!!open}
            onClick={handleOpen}
            endIcon={<ExpandMoreIcon />}
          >
            Actions
          </StyledSingleActionsBtn>
          <Menu
            anchorEl={menuAnchorEl}
            open={Boolean(menuAnchorEl)}
            onClose={handleClose}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "right",
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "right",
            }}
            PaperProps={{
              style: {
                width: "fit-content",
              },
            }}
          >
            <MenuItem
              onClick={handleOpenDialog}
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                color: "#788894",
                gap: 1,
              }}
            >
              <DeleteOutlinedIcon />
              <Typography>Delete candidate</Typography>
            </MenuItem>
          </Menu>
        </Grid>
      </Grid>
    </>
  );
};

export default CandidateRow;
