import { useCallback, useEffect, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { fetchJobCandidates } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import {
  CircularProgress,
  Stack,
  Typography,
  useMediaQuery,
} from "@mui/material";
import JobCandidatesToolbar from "./JobCandidatesToolbar";
import JobCandidatesStatusTable from "./JobCandidatesStatusTable";
import JobCandidatesFilter from "./JobCandidatesFilter";
import JobCandidatesTable from "./JobCandidatesTable";
import { debounce } from "lodash";
import JobCandidatesDesktopFilter from "./JobCandidatesDesktopFilter";
import { useTheme } from "@emotion/react";
import { clearSelectedJobCandidateDetails } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import CandidateDetails from "../../searchCandidate/CandidateDetails";

const JobCandidates = () => {
  const theme = useTheme();
  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const { jobId } = useParams();
  const dispatch = useDispatch();
  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const {
    isErrorGettingCandidates,
    searchedJobCandidates,
    candidatesSelectedRoles: roles,
    candidatesSelectedAvailabilityHours: hourly_availabilities,
    candidatesMinHourlyRate: min_hourly_rate,
    candidatesMaxHourlyRate: max_hourly_rate,
    candidatesSelectedStatus: statuses,
  } = useSelector((state) => state.jobVacancy);

  const filters = {
    roles,
    hourly_availabilities,
    statuses,
  };

  const filteredFilters = useMemo(() => {
    const result = Object.keys(filters).reduce((acc, key) => {
      if (filters[key] && filters[key].length > 0) {
        acc[key] = filters[key];
      }
      return acc;
    }, {});

    if (min_hourly_rate !== 0 || max_hourly_rate !== 0) {
      result.min_hourly_rate = min_hourly_rate;
      result.max_hourly_rate = max_hourly_rate;
    }

    return result;
  }, [filters, min_hourly_rate, max_hourly_rate]);

  const handleFetchCandidates = useCallback(
    debounce(async (filtersData) => {
      try {
        console.log("reach here");
        const jId = jobId;
        const res = await dispatch(
          fetchJobCandidates({ job_vacancy_id: jId, filters: filtersData })
        );
        const data = await unwrapResult(res);
        console.log("data from Candidates", data);
        handleClickSnackbar("fetched Candidates successfully", "success");
      } catch (error) {
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch Candidates",
          "error"
        );
      }
    }, 1000),
    [dispatch]
  );

  useEffect(() => {
    console.log("fetch");
    handleFetchCandidates(filteredFilters);

    return () => {
      handleFetchCandidates.cancel();
    };
  }, [
    roles,
    hourly_availabilities,
    statuses,
    min_hourly_rate,
    max_hourly_rate,
  ]);

  const { selectedJobCandidateDetails,isJobCandidatesFilterExtended } = useSelector(
    (state) => state.jobVacancy
  );

  const handleCandidateDetailsClose = () => {
    dispatch(clearSelectedJobCandidateDetails());
  };
  return (
    <>
      <Stack className="jobCandidates" sx={{ height: "100%" }} gap={3}>
        <>
          <JobCandidatesToolbar />
          <JobCandidatesStatusTable />
          <Stack sx={{ flexDirection: "row", gap: 2 }}>
            {lgMatches && isJobCandidatesFilterExtended && <JobCandidatesDesktopFilter />}
            <JobCandidatesTable />
          </Stack>
          {selectedJobCandidateDetails && (
            <CandidateDetails
              data={selectedJobCandidateDetails}
              onClose={handleCandidateDetailsClose}
            />
          )}
        </>
        {isErrorGettingCandidates && (
          <Stack className="jobCandidates">
            <Typography variant="h2" sx={{ textAlign: "center" }}>
              Error fetch candidates!
            </Typography>
          </Stack>
        )}
      </Stack>
    </>
  );
};

export default JobCandidates;
