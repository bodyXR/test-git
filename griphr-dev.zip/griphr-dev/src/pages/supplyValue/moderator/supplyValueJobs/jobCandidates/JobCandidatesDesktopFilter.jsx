import React from "react";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import { Typography } from "@mui/material";
import JobCandidatesFilter from "./JobCandidatesFilter";

const JobCandidatesDesktopFilter = () => {
  return (
    <StyledWrapper
      sx={{
        minWidth: "292px",
        maxWidth: "292px",
        gap: 2,
        height: "62vh",
        overflowY: "auto",
      }}
    >
      <Typography variant="h6">Filters</Typography>
      <JobCandidatesFilter />
    </StyledWrapper>
  );
};

export default JobCandidatesDesktopFilter;
