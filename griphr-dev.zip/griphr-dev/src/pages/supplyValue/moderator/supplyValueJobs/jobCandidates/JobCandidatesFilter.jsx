import JobCandidatesHourlyRateFilter from "./JobCandidatesHourlyRateFilter";
import JobCandidatesAvailabilityFilter from "./JobCandidatesAvailabilityFilter";
import JobCandidatesRoleFilter from "./JobCandidatesRoleFilter";
import JobCandidatesStatusFilter from "./JobCandidatesStatusFilter";

const JobCandidatesFilter = () => {
  return (
    <>
        <JobCandidatesRoleFilter />
        <JobCandidatesHourlyRateFilter />
        <JobCandidatesAvailabilityFilter />
        <JobCandidatesStatusFilter />
    </>
  );
};

export default JobCandidatesFilter;
