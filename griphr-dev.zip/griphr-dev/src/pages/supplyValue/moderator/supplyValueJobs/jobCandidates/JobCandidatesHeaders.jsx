import { Typography } from "@mui/material";
import React from "react";
import Grid from "@mui/material/Unstable_Grid2";
import StyledFilterCheckbox from "../../../../../components/styled/StyledFilterCheckbox";
import { useDispatch, useSelector } from "react-redux";
import { removeAllSelectedJobCandidates, selectAllJobCandidates } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const JobCandidatesHeaders = () => {
  const dispatch = useDispatch();
  const { selectedJobCandidates, jobCandidates } = useSelector(
    (state) => state.jobVacancy
  );

  const jobCandidatesHeaders = [
    { title: "Name", space: 2.5 },
    { title: "Availability", space: 1.5 },
    { title: "Hourly rate", space: 1.5 },
    { title: "Skill matching", space: 1.5 },
    { title: "Status", space: 2 },
  ];

  return (
    <Grid
      container
      sx={{
        alignItems: "center",
        px: 2,
        pt: { xs: 2, lg: 3.5 },
        pb: 2,
        position: "sticky",
        top: 0,
        bgcolor: "background.white",
        zIndex: 99,
      }}
    >
      <Grid xs={0.5}>
        <StyledFilterCheckbox
          checked={jobCandidates?.length > 0 && jobCandidates?.length === selectedJobCandidates?.length}
          onChange={() => {
            if (jobCandidates?.length === selectedJobCandidates?.length) {
              dispatch(removeAllSelectedJobCandidates());
              return;
            }
            dispatch(selectAllJobCandidates());
          }}
        />
      </Grid>
      {jobCandidatesHeaders.map((header, index) => (
        <Grid item xs={header.space} key={header.title}>
          <Typography
            variant="h5"
            sx={{
              color: "darkGreen",
              fontWeight: "500",
              textAlign: index === 0 ? "left" : "center",
              paddingLeft: index === 0 ? "8px" : "0",
            }}
          >
            {header.title}
          </Typography>
        </Grid>
      ))}
    </Grid>
  );
};

export default JobCandidatesHeaders;
