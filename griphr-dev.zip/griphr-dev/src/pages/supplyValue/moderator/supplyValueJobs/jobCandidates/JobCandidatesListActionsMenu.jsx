import {
  Box,
  ListItemIcon,
  ListItemText,
  Menu,
  useMediaQuery,
} from "@mui/material";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import { deleteBulkJobCandidatesAndGetAll } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { removeAllSelectedJobCandidates } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import StyledMenuItem from "../../../../../components/styled/StyledMenuItem";
import delete_inactive from "../../../../../assets/delete_inactive.svg";
import { useParams } from "react-router-dom";
import useDialog from "../../../../../hooks/useDialog";
import DeleteModule from "../../components/DeleteModule";

const JobCandidatesListActionsMenu = ({
  userId,
  width = "",
  anchor,
  open,
  onClose,
}) => {
  const { jobId } = useParams();
  const { selectedJobCandidates } = useSelector((state) => state.jobVacancy);
  const dispatch = useDispatch();
  const smStyles = useMediaQuery((theme) => theme.breakpoints.up("sm"));
  const { openDialog, handleOpenDialog, handleCloseDialog } = useDialog();
  const [isDeletingCandidate, setIsDeletingCandidate] = useState(false);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleDeleteBulkUsers = async () => {
    try {
      setIsDeletingCandidate(true);
      const deleteBulkCandidatesAndGetAllResult = await dispatch(
        deleteBulkJobCandidatesAndGetAll({
          user_ids: selectedJobCandidates,
          job_vacancy_id: jobId,
        })
      );
      await unwrapResult(deleteBulkCandidatesAndGetAllResult);
      setIsDeletingCandidate(false);
      handleClickSnackbar("Candidates deleted successfully", "success");
      dispatch(removeAllSelectedJobCandidates());
      onClose();
    } catch (error) {
      handleClickSnackbar(
        error?.response?.data?.message || "Fail to delete candidates",
        "error"
      );
    }
  };

  return (
    <>
      <DeleteModule
        openDialog={openDialog}
        handleDelete={handleDeleteBulkUsers}
        handleCloseDialog={handleCloseDialog}
        title="candidates"
        isDeleting={isDeletingCandidate}
      />
      <Menu
        anchorEl={anchor}
        open={open}
        onClose={onClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
        sx={{
          ".MuiMenu-paper": smStyles
            ? {}
            : {
                width: width,
                maxWidth: { sm: "600px" },
              },
        }}
      >
        <StyledMenuItem onClick={handleOpenDialog}>
          <ListItemIcon>
            <Box component={"img"} src={delete_inactive} />
          </ListItemIcon>
          <ListItemText>
            {selectedJobCandidates.length > 0
              ? "Delete candidates"
              : "Delete candidate"}
          </ListItemText>
        </StyledMenuItem>
      </Menu>
    </>
  );
};

export default JobCandidatesListActionsMenu;
