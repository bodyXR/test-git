import React, { useEffect, useRef, useState } from "react";
import StyledGreenActionsBtn from "../../../../../components/styled/StyledGreenActionsBtn";
import JobCandidatesListActionsMenu from "./JobCandidatesListActionsMenu";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import useMenu from "../../../../../hooks/useMenu";

const JobCandidatesListActionsModule = () => {
  const { handleClose, handleOpen, menuAnchorEl, open } = useMenu();
  const [width, setWidth] = useState(0);
  const buttonRef = useRef(null);

  useEffect(() => {
    if (buttonRef.current) {
      setWidth(buttonRef.current.offsetWidth);
    }
  }, []);
  return (
    <>
      <StyledGreenActionsBtn
        disableElevation
        disableRipple
        expand={!!open}
        endIcon={<ExpandMoreIcon />}
        variant="outlined"
        onClick={handleOpen}
        ref={buttonRef}
        sx={{ flex: { md: 1 }, minWidth: { lg: "120px" } }}
      >
        actions
      </StyledGreenActionsBtn>
      <JobCandidatesListActionsMenu
        width={width}
        anchor={menuAnchorEl}
        open={open}
        onClose={handleClose}
      />
    </>
  );
};

export default JobCandidatesListActionsModule;
