import { useSelector } from "react-redux";
import CandidateRow from "./CandidateRow";
import { Typography } from "@mui/material";

const JobCandidatesRowsWrapper = () => {
  const { searchedJobCandidates, jobCandidates } = useSelector(
    (state) => state.jobVacancy
  );
  return (
    <>
      {searchedJobCandidates.length > 0 && (
        searchedJobCandidates?.map((candidateData) => (
          <CandidateRow data={candidateData} key={candidateData.id} />
        ))
      ) }
    </>
  );
};

export default JobCandidatesRowsWrapper;
