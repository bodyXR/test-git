import React from "react";
import FilterSection from "../../components/FilterSection";
import StyledFilterLabel from "../../../../../components/styled/StyledFilterLabel";
import { FormGroup } from "@mui/material";
import StyledFilterCheckbox from "../../../../../components/styled/StyledFilterCheckbox";
import { useDispatch, useSelector } from "react-redux";
import {
  candidatesAddSelectedStatus,
  candidatesRemoveSelectedStatus,
} from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const Status = ["new", "screening", "interview", "offer", "hired", "rejected"]; // "inactive"

const JobCandidatesStatusFilter = () => {
  const dispatch = useDispatch();

  const { candidatesSelectedStatus } = useSelector((state) => state.jobVacancy);

  return (
    <FilterSection title="Status">
      <FormGroup>
        {Status?.length > 0 &&
          Status.map((item) => {
            const isSelected = candidatesSelectedStatus.some(
              (selected) => selected === item
            );
            return (
              <StyledFilterLabel
                key={item}
                control={
                  <StyledFilterCheckbox
                    checked={isSelected}
                    onChange={() => {
                      if (isSelected) {
                        return dispatch(candidatesRemoveSelectedStatus(item));
                      }
                      dispatch(candidatesAddSelectedStatus(item));
                    }}
                    name={item}
                  />
                }
                label={`${item}`}
                sx={{ textTransform: "capitalize" }}
              />
            );
          })}
      </FormGroup>
    </FilterSection>
  );
};

export default JobCandidatesStatusFilter;
