import { useTheme } from "@emotion/react";
import { Divider, Stack, Typography, useMediaQuery } from "@mui/material";
import React from "react";
import { useSelector } from "react-redux";

const statusColors = {
  new: "#E1DFFA",
  screening: "#FCECCB",
  interview: "#E5F3FC",
  offer: "#F0CEFF",
  hired: "#DBF0DE",
  rejected: "#EACBC7",
  //   inactive:  "#EEEEEE" ,
};

const JobCandidatesStatusTable = () => {
  const theme = useTheme();
  const mdMatches = useMediaQuery((theme) => theme.breakpoints.up("md"));
  const { jobCandidates } = useSelector((state) => state.jobVacancy);

  const GetMatchedCandidates = (value) => {
    let res = "";
    let counter = 0;
    jobCandidates?.map((candidate) => {
      if (candidate?.status === value) {
        res = `${++counter}/${jobCandidates?.length}`;
      }
    });
    return res || `0/${jobCandidates?.length}`;
  };

  return (
    <Stack
      sx={{
        border: "1.5px #C0C0C0 solid",
        borderRadius: "4px",
        flexDirection: mdMatches ? "row" : "column",
        borderBottom: "none",
      }}
    >
      {Object.entries(statusColors).map(([status, color], i) => (
        <Stack
          key={i}
          sx={{
            borderBottom: `4px ${color} solid`,
            flex: 1,
            flexDirection: "row",
            py: 1.5,
          }}
        >
          {i !== 0 && <Divider orientation="vertical" />}
          <Stack sx={{ flex: 1, gap: mdMatches ?  0.5  :1.5 , flexDirection: !mdMatches ? "row" : "column" , justifyContent : "center"}}>
            <Typography
              variant="h3"
              sx={{ color: "#788894", textAlign: "center" }}
            >
              {GetMatchedCandidates(status)}
            </Typography>
            <Typography
              variant="h3"
              sx={{
                color: "#788894",
                textAlign: "center",
                textTransform: "capitalize",
              }}
            >
              {status}
            </Typography>
          </Stack>
        </Stack>
      ))}
    </Stack>
  );
};

export default JobCandidatesStatusTable;
