import React, { useRef } from "react";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import { useDraggable } from "react-use-draggable-scroll";
import { Stack, Typography } from "@mui/material";
import { useSelector } from "react-redux";
import JobCandidatesHeaders from "./JobCandidatesHeaders";
import JobCandidatesRowsWrapper from "./JobCandidatesRowsWrapper";
import StyledTable from "../../components/StyledTable";

const JobCandidatesTable = () => {
  const ref = useRef();
  const { events } = useDraggable(ref);

  const {
    isSuccessGettingCandidates,
    isLoadingGettingCandidates,
    searchedJobCandidates,
  } = useSelector((state) => state.jobVacancy);

  return (
    <StyledTable ref={ref} {...events}>
      <Stack
        sx={{
          width: {
            xs: "1170px",
            lg: "auto",
          },
          minWidth: "1170px",
          height: "100%",
        }}
      >
        <>
          <JobCandidatesHeaders />
          <JobCandidatesRowsWrapper />
        </>
      </Stack>
    </StyledTable>
  );
};

export default JobCandidatesTable;
