import { Stack, useMediaQuery } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import SearchJobCandidatesModule from "./SearchJobCandidatesModule";
import JobCandidatesListActionsModule from "./JobCandidatesListActionsModule";
import JobCandidatesFilterMobileModule from "./JobCandidatesFilterMobileModule";
import { toggleJobCandidatesFilter } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import StyledFiltersStateButton from "../../components/styled/StyledFiltersStateButton";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import filter from "../../../../../assets/filter.svg";

const JobCandidatesToolbar = () => {
  const dispatch = useDispatch();
  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const mdMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("md", "lg")
  );
  const xsMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("xs", "md")
  );
  
  const {
    jobCandidates,
    selectedJobCandidates,
    isJobCandidatesFilterExtended,
  } = useSelector((state) => state.jobVacancy);

  return (
    <Stack
      sx={{
        gap: { xs: 2 },
        flexDirection: { lg: "row" },
        justifyContent: "space-between",
      }}
    >
      <Stack sx={{ flexDirection: "row", width: "100%", gap: 1 }}>
        {lgMatches && (
          <Grid2>
            <StyledFiltersStateButton
              startIcon={<img src={filter} alt="filter icon" />}
              variant="outlined"
              onClick={() => dispatch(toggleJobCandidatesFilter())}
            >
              {isJobCandidatesFilterExtended ? "Hide filters" : "Show filters"}
            </StyledFiltersStateButton>
          </Grid2>
        )}
        <Grid2 sx={{ flex: 1 }}>
          <SearchJobCandidatesModule />
        </Grid2>
      </Stack>
      {jobCandidates && jobCandidates?.length > 0 && (
        <>
          {selectedJobCandidates.length > 0 && lgMatches && (
            <Stack sx={{ flexDirection: "row", gap: 2 }}>
              <JobCandidatesListActionsModule />
            </Stack>
          )}
          {mdMatches && (
            <Stack sx={{ gap: { xs: 2 }, flexDirection: { xs: "row" } }}>
              {selectedJobCandidates.length > 0 && (
                <JobCandidatesListActionsModule />
              )}
            </Stack>
          )}
          {xsMatches && (
            <>
              <Stack sx={{ gap: { xs: 2 }, flexDirection: { xs: "row" } }}>
                <JobCandidatesFilterMobileModule />
              </Stack>
              {selectedJobCandidates.length > 0 && (
                <JobCandidatesListActionsModule />
              )}{" "}
            </>
          )}
        </>
      )}
    </Stack>
  );
};

export default JobCandidatesToolbar;
