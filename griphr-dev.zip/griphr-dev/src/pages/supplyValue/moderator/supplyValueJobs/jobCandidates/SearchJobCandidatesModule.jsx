import StyledSearchBar from "../../../../../components/styled/StyledSearchBar";
import { useDispatch, useSelector } from "react-redux";
import { InputAdornment } from "@mui/material";
import search from "../../../../../assets/search.svg";
import useSearch from "../../../../../hooks/useSearch";
import { searchJobCandidates } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const SearchJobCandidatesModule = () => {
  const dispatch = useDispatch();
  const { jobCandidates } = useSelector((state) => state.jobVacancy);

  const { searchQuery, setSearchQuery, filteredData } = useSearch(
    jobCandidates,
    [(item) => item.user.first_name + " " + item.user.last_name]
  );

  return (
    <StyledSearchBar
      name="search_candidate"
      fullWidth
      size="small"
      type="search"
      variant="outlined"
      value={searchQuery}
      onChange={(e) => {
        setSearchQuery(e.target.value);
        if (e.target.value === "") {
          return dispatch(searchJobCandidates(jobCandidates));
        }
        dispatch(searchJobCandidates(filteredData));
      }}
      placeholder="Search candidate"
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <img src={search} alt="search icon" />
          </InputAdornment>
        ),
      }}
      sx={{
        alignSelf: "stretch",
        "& .MuiInputBase-root": {
          height: "44.5px",
        },
      }}
    />
  );
};

export default SearchJobCandidatesModule;
