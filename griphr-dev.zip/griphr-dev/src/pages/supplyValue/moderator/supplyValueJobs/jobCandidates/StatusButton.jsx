import React, { useEffect, useRef, useState } from "react";
import useMenu from "../../../../../hooks/useMenu";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Menu, MenuItem, Typography } from "@mui/material";
import { updateJobCandidateStatusAndGetAll } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import StyledGreenActionsBtn from "../../../../../components/styled/StyledGreenActionsBtn";

const statusColors = {
  new: "#E1DFFA",
  screening: "#FCECCB",
  interview: "#E5F3FC",
  offer: "#F0CEFF",
  hired: "#DBF0DE",
  rejected: "#EACBC7",
  inactive: "#EEEEEE",
};

const StatusButton = ({ data }) => {
  const dispatch = useDispatch();
  const { handleClose, handleOpen, menuAnchorEl, open } = useMenu();
  const { selectedJob } = useSelector((state) => state.jobVacancy);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleUpdateJobCandidateStatus = async (status) => {
    try {
      const updateJobCandidateStatusAndGetAllRequest = await dispatch(
        updateJobCandidateStatusAndGetAll({
          id: data?.id,
          job_vacancy_id: selectedJob.id,
          status: status,
        })
      );
      await unwrapResult(updateJobCandidateStatusAndGetAllRequest);
      handleClickSnackbar("updated Candidate successfully", "success");
    } catch (error) {
      console.log(error);
      handleClickSnackbar(error || "Fail to updated Candidate", "error");
    }
  };

  const getColor = (status) => statusColors?.[status] || "#EEEEEE";
  return (
    <>
      <StyledGreenActionsBtn
        disableElevation
        disableRipple
        expand={!!open}
        endIcon={<ExpandMoreIcon />}
        variant="outlined"
        onClick={handleOpen}
        sx={{
          flex: 0.5,
          height: "fit-content",
          px: 3,
          py: 0.5,
          textTransform: "capitalize",
          backgroundColor: getColor(data?.status),
          borderRadius: 50,
          "&:hover": {
            backgroundColor: getColor(data?.status),
          },
        }}
      >
        {data?.status}
      </StyledGreenActionsBtn>
      <Menu
        anchorEl={menuAnchorEl}
        open={Boolean(menuAnchorEl)}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        PaperProps={{
          style: {
            width: "fit-content",
          },
        }}
      >
        {Object.keys(statusColors).map((status, i) => (
          <MenuItem
            onClick={() => {
              handleUpdateJobCandidateStatus(status);
              handleClose();
            }}
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#788894",
              gap: 1,
              textTransform: "capitalize",
            }}
            key={i}
          >
            <Typography>{status}</Typography>
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

export default StatusButton;
