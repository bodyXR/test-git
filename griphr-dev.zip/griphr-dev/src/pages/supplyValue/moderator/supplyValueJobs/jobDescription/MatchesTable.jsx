import React, { useRef } from "react";
import { useDraggable } from "react-use-draggable-scroll";
import MatchingHeaders from "./MatchingHeaders";
import MatchingRow from "./MatchingRow";
import { Stack, Typography } from "@mui/material";
import { useSelector } from "react-redux";
import StyledTable from "../../components/StyledTable";

const MatchesTable = () => {
  const ref = useRef();
  const { events } = useDraggable(ref);

  const { searchedMatches, Matches } = useSelector((state) => state.jobVacancy);

  return (
    <StyledTable ref={ref} {...events} sx={{ flex: 1, height: "auto" }}>
      <Stack
        sx={{
          width: {
            xs: "970px",
            lg: "auto",
          },
          minWidth: "1170px",
          height: "100%",
          userSelect: "none",
          "& .match__row:last-child": {
            borderBottom: "none",
          },
        }}
      >
        <MatchingHeaders />

        {Matches.length > 0 &&
          Matches.slice(0, 2).map((matchData) => (
            <MatchingRow data={matchData} key={matchData.id} />
          ))}

        {/* {searchedMatches && searchedMatches.length > 0
          ? searchedMatches.map((matchData) => (
              <MatchingRow data={matchData} key={matchData.id} />
            ))
          : Matches.map((matchData) => (
              <MatchingRow data={matchData} key={matchData.id} />
            ))} */}

        {Matches.length < 1 && (
          <Typography
            variant="h3"
            color="primary"
            textAlign={"center"}
            pt={{ xs: 2, lg: "20px" }}
          >
            No results found!
          </Typography>
        )}
      </Stack>
    </StyledTable>
  );
};

export default MatchesTable;
