import {
  Avatar,
  Box,
  Divider,
  Menu,
  MenuItem,
  Stack,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import StyledFilterCheckbox from "../../../../../components/styled/StyledFilterCheckbox";
import BorderLinearProgress from "../../components/styled/BorderLinearProgress";
import SkillItem from "../../components/SkillItem";
import { useDispatch, useSelector } from "react-redux";
import {
  addSelectedMatch,
  removeSelectedMatch,
  setSelectedJobCandidateDetails,
} from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import useMenu from "../../../../../hooks/useMenu";
import menu from "../../../../../assets/menu_icon.svg";
import { unwrapResult } from "@reduxjs/toolkit";
import { addToCandidates } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import StyledSingleActionsBtn from "../../../../../components/styled/StyledSingleActionsBtn";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const MatchingCard = ({ data }) => {
  const theme = useTheme();
  const mdMatches = useMediaQuery(theme.breakpoints.up("md"));
  const dispatch = useDispatch();
  const [ShowMore, setShowMore] = useState(false);
  const { selectedMatches, selectedJob } = useSelector(
    (state) => state.jobVacancy
  );
  const { handleClose, handleOpen, menuAnchorEl, open } = useMenu();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleAddToCandidates = async () => {
    try {
      const addToJobListResult = await dispatch(
        addToCandidates({
          role_id: selectedJob.role.id,
          user_id: data?.id,
          job_vacancy_ids: [selectedJob.id],
        })
      );
      await unwrapResult(addToJobListResult);
      handleClickSnackbar("added Candidate successfully", "success");
    } catch (error) {
      console.log(error);
      handleClickSnackbar(error || "Fail to Add Candidate to Job", "error");
    }
  };

  const handleCandidateDetailsOpen = async () => {
    dispatch(setSelectedJobCandidateDetails(data));
  };

  return (
    <>
      <Grid2
        xs={12}
        md={5.87}
        lg={5.88}
        onMouseLeave={() => {
          setShowMore(false);
        }}
        onMouseEnter={() => {
          data?.skills?.length > 4 && setShowMore(true);
        }}
      >
        <Stack
          sx={{
            background: "#FAFAFA",
            border: "2px solid #EEEEEE",
            borderRadius: "10px",
            gap: { xs: 1, md: "20px" },
            p: { xs: "12px", lg: "20px" },
          }}
        >
          {!mdMatches && (
            <Box sx={{ display: "flex", justifyContent: "end" }}>
              <StyledFilterCheckbox
                onChange={() => {
                  selectedMatches.find((el) => el.id === data.id)
                    ? dispatch(removeSelectedMatch(data))
                    : dispatch(addSelectedMatch(data));
                }}
                sx={{ width: "auto" }}
              />
            </Box>
          )}
          <Stack
            sx={{
              flexDirection: { xs: "column", md: "row" },
              justifyContent: "space-between",
              gap: { xs: 2, md: 0 },
            }}
          >
            <Stack sx={{ flexDirection: "row", alignItems: "center", gap: 1 }}>
              <Avatar
                sx={{
                  width: 60,
                  height: 60,
                }}
                src={data?.profile_picture?.url}
              />
              <Stack>
                {/* <Link
                  to={`/moderator/candidates/profile/${data?.id}`}
                  title={data?.first_name}
                  onClick={() => {}}
                  style={{
                    fontSize: "14px",
                    textDecoration: "underline",
                    textTransform: "capitalize",
                    color: "#173433",
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    width: "14ch",
                  }}
                > */}
                <Typography
                  onClick={handleCandidateDetailsOpen}
                  variant="h3"
                  title={`${data?.first_name} ${data?.last_name}`}
                  sx={{
                    textTransform: "capitalize",
                    textDecoration: "underline",
                    color: "darkGreenAccent",
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    width: { xs: "17ch", sm: "22ch", md: "11ch", xl: "22ch" },
                    cursor: "pointer",
                  }}
                >
                  {data?.first_name + " " + data?.last_name}
                </Typography>
                {/* </Link> */}
                <Typography sx={{ color: "darkGrey", fontSize: "14px" }}>
                  {data?.role?.title}
                </Typography>
              </Stack>
            </Stack>
            <Stack sx={{ flexDirection: "row", alignItems: "center" }}>
              <StyledSingleActionsBtn
                expand={!!open}
                onClick={handleOpen}
                endIcon={<ExpandMoreIcon />}
                sx={{ width: mdMatches ? "auto" : "100%" }}
              >
                Actions
              </StyledSingleActionsBtn>
              <Menu
                anchorEl={menuAnchorEl}
                open={Boolean(menuAnchorEl)}
                onClose={handleClose}
                anchorOrigin={{
                  vertical: "bottom",
                  horizontal: "center",
                }}
                transformOrigin={{
                  vertical: "top",
                  horizontal: "center",
                }}
                PaperProps={{
                  style: {
                    width: "fit-content",
                  },
                }}
              >
                <MenuItem
                  onClick={() => {
                    handleAddToCandidates();
                  }}
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    color: "#788894",
                    gap: 1,
                  }}
                >
                  <Box component={"img"} src={menu} />
                  <Typography>Add to candidates</Typography>
                </MenuItem>
              </Menu>
              {mdMatches && (
                <StyledFilterCheckbox
                  onChange={() => {
                    selectedMatches.find((el) => el.id === data.id)
                      ? dispatch(removeSelectedMatch(data))
                      : dispatch(addSelectedMatch(data));
                  }}
                />
              )}
            </Stack>
          </Stack>
          <Divider />
          <Stack sx={{ gap: 2 }}>
            <Stack
              sx={{
                width: "100%",
                flexDirection: { sx: "column", md: "row" },
                alignItems: { sx: "start", md: "center" },
                gap: 1,
                justifyContent: "space-between",
              }}
            >
              <Typography
                variant="h3"
                sx={{
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                Matching skills
              </Typography>
              <Stack
                sx={{ flexDirection: "row", alignItems: "center", gap: 1 }}
              >
                <BorderLinearProgress
                  sx={{ width: { xs: 150, md: 128, lg: 132 } }}
                  variant="determinate"
                  value={
                    (data?.skills?.length / selectedJob?.role?.skills?.length) *
                    100
                  }
                />
                <Typography sx={{ color: "darkGrey" }}>
                  {data?.skills?.length} / {selectedJob?.role?.skills?.length}
                </Typography>
              </Stack>
            </Stack>
            <Stack
              sx={{
                flexDirection: "row",
                flexWrap: "wrap",
                gap: 1,
                alignItems: "center",
              }}
            >
              {data?.skills &&
                data?.skills.map((skill, i) => (
                  <Stack key={i}>
                    {i <= 4 && !ShowMore && <SkillItem data={skill} />}
                  </Stack>
                ))}
              {data?.skills && (
                <Typography
                  sx={{ textDecoration: "underline", color: "#66C1FF" }}
                  variant="h5"
                  onClick={() => {
                    setShowMore((prev) => !prev);
                  }}
                >
                  {data?.skills?.length > 4 ? (ShowMore ? "-" : "+") : ""}{" "}
                  {data?.skills?.length > 4 && data?.skills?.length - 4}
                </Typography>
              )}
            </Stack>
          </Stack>
        </Stack>
      </Grid2>
    </>
  );
};

export default MatchingCard;
