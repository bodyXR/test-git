import { Typography } from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import React from "react";
import StyledFilterCheckbox from "../../../../../components/styled/StyledFilterCheckbox";
import { useDispatch, useSelector } from "react-redux";
import {
  removeAllSelectedMatches,
  selectAllMatches,
} from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const MatchingHeaders = () => {
  const dispatch = useDispatch();
  const { selectedMatches, Matches } = useSelector((state) => state.jobVacancy);

  const MatchesHeaders = [
    { title: "Name", space: 2.5 },
    { title: "Skill matching", space: 1.5 },
    { title: "Hourly rate", space: 1.5 },
    { title: "Availability", space: 1.5 },
    { title: "Skills", space: 2 },
  ];
  return (
    <Grid
      container
      sx={{
        alignItems: "center",
        px: 2,
        pt: { xs: 2, lg: 3.5 },
        pb: 2,
        position: "sticky",
        top: 0,
        bgcolor: "background.white",
        zIndex: 99,
      }}
    >
      <Grid xs={0.5}>
        <StyledFilterCheckbox
          checked={Matches?.length === selectedMatches?.length}
          onChange={() => {
            if (Matches?.length === selectedMatches?.length) {
              dispatch(removeAllSelectedMatches());
              return;
            }
            dispatch(selectAllMatches());
          }}
        />
      </Grid>
      {MatchesHeaders.map((header, index) => (
        <Grid xs={header.space} key={header.title}>
          <Typography
            variant="h5"
            sx={{
              color: "darkGreen",
              fontWeight: "500",
              textAlign: index === 0 ? "left" : "center",
              paddingLeft: index === 0 ? "8px" : "0",
            }}
          >
            {header.title}
          </Typography>
        </Grid>
      ))}
    </Grid>
  );
};

export default MatchingHeaders;
