import { Avatar, Box, Menu, MenuItem, Stack, Typography } from "@mui/material";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import StyledFilterCheckbox from "../../../../../components/styled/StyledFilterCheckbox";
import {
  addSelectedMatch,
  removeSelectedMatch,
  setSelectedJobCandidateDetails,
} from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import { Link } from "react-router-dom";
import StyledCandidatesRowBody1 from "../../../../../components/styled/StyledCandidatesRowBody1";
import StyledSingleActionsBtn from "../../../../../components/styled/StyledSingleActionsBtn";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import SkillItem from "../../components/SkillItem";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import { addToCandidates } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";
import menu from "../../../../../assets/menu_icon.svg";
import useMenu from "../../../../../hooks/useMenu";
import Grid from "@mui/material/Unstable_Grid2";
import { getCandidateById } from "../../../../../redux/slices/moderator/candidatesList/candidatesListActions";

const MatchingRow = ({ data }) => {
  console.log("data match row", data);
  const { handleClose, handleOpen, menuAnchorEl, open } = useMenu();
  const dispatch = useDispatch();
  const { selectedMatches, selectedJob } = useSelector(
    (state) => state.jobVacancy
  );
  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleAddToCandidates = async () => {
    try {
      const addToJobListResult = await dispatch(
        addToCandidates({
          role_id: selectedJob.role.id,
          user_id: data?.id,
          job_vacancy_ids: [selectedJob.id],
        })
      );
      await unwrapResult(addToJobListResult);
      handleClickSnackbar("added Candidate successfully", "success");
    } catch (error) {
      console.log(error);
      handleClickSnackbar(error || "Fail to Add Candidate to Job", "error");
    }
  };
  const handleCandidateDetailsOpen = async () => {
    dispatch(setSelectedJobCandidateDetails(data));
  };

  return (
    <Grid
      className="match__row"
      container
      sx={{
        alignItems: "center",
        borderBottom: "2px solid #EEE",
        p: 2,
      }}
    >
      <Grid xs={0.5}>
        <StyledFilterCheckbox
          checked={selectedMatches.includes(data?.id)}
          onChange={() => {
            if (selectedMatches.includes(data?.id)) {
              dispatch(removeSelectedMatch(data?.id));
              return;
            }
            dispatch(addSelectedMatch(data?.id));
          }}
        />
      </Grid>

      <Grid xs={2.5}>
        <Stack
          sx={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Stack
            sx={{
              flexDirection: "row",
              alignItems: "center",
              gap: 1.25,
            }}
          >
            <Avatar
              src={data?.profile_picture?.url}
              alt={data?.profile_picture?.name}
              sx={{ width: "40px", height: "40px" }}
            />

            <Stack sx={{ gap: 0.25 }}>
              {/* <Link to={`/moderator/candidates/profile/${data?.id}`}> */}
              <Typography
                variant="h5"
                sx={{
                  "&:hover": {
                    color: "#66C1FF",
                    textDecoration: "underline",
                  },
                  textTransform: "capitalize",
                  color: "inactive.main",
                  fontWeight: 600,
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  cursor: "pointer",
                }}
                onClick={() => {
                  handleCandidateDetailsOpen();
                }}
              >
                {data?.first_name + " " + data?.last_name}
              </Typography>
              {/* </Link> */}
              <StyledCandidatesRowBody1
                sx={{ textAlign: "left" }}
                variant="body1"
              >
                {data?.role?.title || "N/A"}
              </StyledCandidatesRowBody1>
            </Stack>
          </Stack>
        </Stack>
      </Grid>

      {/* Skills Col */}
      <Grid xs={1.5}>
        <StyledCandidatesRowBody1
          variant="body1"
          sx={{ textTransform: "none" }}
        >
          {`${data?.skills?.length} / ${selectedJob?.role?.skills?.length}`}
        </StyledCandidatesRowBody1>
      </Grid>

      {/* Hourly-Rate Col */}
      <Grid xs={1.5}>
        <StyledCandidatesRowBody1
          variant="body1"
          sx={{ textTransform: "none" }}
        >
          {data?.hourly_rate ? `€${data?.hourly_rate}` : "N/A"}
        </StyledCandidatesRowBody1>
      </Grid>

      {/* Availability Col */}
      <Grid xs={1.5}>
        <StyledCandidatesRowBody1
          variant="body1"
          sx={{ textTransform: "none" }}
        >
          {data?.availability ? `${data?.availability}hr/w` : "N/A"}
        </StyledCandidatesRowBody1>
      </Grid>

      <Grid xs={2}>
        <StyledCandidatesRowBody1
          variant="body1"
          sx={{ display: "flex", justifyContent: "center" }}
        >
          <Stack
            sx={{
              flexDirection: "row",
              flexWrap: "wrap",
              gap: 1,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {data?.skills &&
              data?.skills
                .slice(0, 2)
                .map((skill, i) => (
                  <SkillItem tableMode={true} data={skill} key={i} />
                ))}
            {data?.skills && data?.skills?.length > 2 && (
              <Typography
                onClick={handleCandidateDetailsOpen}
                sx={{
                  textDecoration: "underline",
                  color: "#66C1FF",
                  cursor: "pointer",
                }}
                variant="h5"
              >
                +{data?.skills?.length - 2}
              </Typography>
            )}
          </Stack>
        </StyledCandidatesRowBody1>
      </Grid>

      {/* Actions Col */}
      <Grid xs={1.5} sx={{ textAlign: "right" }}>
        <StyledSingleActionsBtn
          expand={!!open}
          onClick={handleOpen}
          endIcon={<ExpandMoreIcon />}
        >
          Actions
        </StyledSingleActionsBtn>
        <Menu
          anchorEl={menuAnchorEl}
          open={Boolean(menuAnchorEl)}
          onClose={handleClose}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "center",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "center",
          }}
          PaperProps={{
            style: {
              width: "fit-content",
            },
          }}
        >
          <MenuItem
            onClick={() => {
              handleAddToCandidates();
              handleClose();
            }}
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#788894",
              gap: 1,
            }}
          >
            <Box component={"img"} src={menu} />
            <Typography>Add to candidates</Typography>
          </MenuItem>
        </Menu>
      </Grid>
    </Grid>
  );
};

export default MatchingRow;
