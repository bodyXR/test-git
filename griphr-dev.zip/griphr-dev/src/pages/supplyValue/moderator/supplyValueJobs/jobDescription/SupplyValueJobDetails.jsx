import { Stack } from "@mui/material";
import React, { useEffect } from "react";

import SupplyValueJobDetailsData from "./SupplyValueJobDetailsData";
import SupplyValueJobDetailsDescription from "./SupplyValueJobDetailsDescription";
import SupplyValueJobDetailsSkills from "./SupplyValueJobDetailsSkills";
import SupplyValueJobDetailsMatches from "./SupplyValueJobDetailsMatches";
import { useDispatch } from "react-redux";
import { removeAllSelectedMatches } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const SupplyValueJobDetails = () => {
  const dispatch = useDispatch();
  // Reset selected matches on component unmount and mount
  useEffect(() => {
    dispatch(removeAllSelectedMatches());
  }, [dispatch]);

  return (
    <>
      <Stack gap={3}>
        <SupplyValueJobDetailsData />

        <SupplyValueJobDetailsDescription />

        <SupplyValueJobDetailsSkills />

        <SupplyValueJobDetailsMatches />
      </Stack>
    </>
  );
};
export default SupplyValueJobDetails;
