import React from "react";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import { Box, Typography } from "@mui/material";
import BagIcon from "../../../../../assets/bag_inactive_icon.svg";
import dateIcon from "../../../../../assets/date_inactive.svg";
import hoursIcon from "../../../../../assets/hours_icon.svg";
import dollarIcon from "../../../../../assets/dollar_icon.svg";
import fileIcon from "../../../../../assets/file_inactive_icon.svg";
import { useSelector } from "react-redux";
import Grid from "@mui/material/Unstable_Grid2";

const boxStyles = {
  display: "flex",
  alignItems: "center",
  gap: 2,
};

const SupplyValueJobDetailsData = () => {
  const { selectedJob } = useSelector((state) => state.jobVacancy);
  return (
    <StyledWrapper>
      <Typography variant="h3" color="#173433" mb={2}>
        Details
      </Typography>
      {/* <Stack
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
         <Box
          sx={{
            width: "113px",
            height: "35px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            background:
              selectedJob?.status === "declined"
                ? "#B95144"
                : selectedJob?.status === "pending"
                ? "#66C1FF"
                : "#6AE6A4",
            borderRadius: "40px",
            textTransform: "capitalize",
            opacity: 0.2,
          }}
        >
          <Typography variant="h6">{selectedJob?.status}</Typography>
        </Box> 
      </Stack> */}
      <Grid container spacing="20px" columns={12}>
        <Grid item xs={12} md={6}>
          <Box sx={boxStyles}>
            <img
              style={{ width: "24px", height: "24px" }}
              src={BagIcon}
              alt="Bag icon"
            />
            <Typography
              variant="body1"
              color="#788894"
              textTransform="capitalize"
            >
              {selectedJob?.company_name}
            </Typography>
          </Box>
        </Grid>
        <Grid item xs={12} md={6}>
          <Box sx={boxStyles}>
            <img
              style={{ width: "24px", height: "24px" }}
              src={fileIcon}
              alt="file icon"
            />
            <Typography
              variant="body1"
              color="#788894"
              textTransform="capitalize"
            >
              {selectedJob?.vacancy_number} vacancies
            </Typography>
          </Box>
        </Grid>
        <Grid item xs={12} md={6}>
          <Box sx={boxStyles}>
            <img
              style={{ width: "24px", height: "24px" }}
              src={dateIcon}
              alt="Date icon"
            />
            <Typography
              variant="body1"
              color="#788894"
              textTransform="capitalize"
            >
              Start Date: {selectedJob?.role?.start_date}
            </Typography>
          </Box>
        </Grid>
        <Grid item xs={12} md={6}>
          <Box sx={boxStyles}>
            <img
              style={{ width: "24px", height: "24px" }}
              src={dateIcon}
              alt="Date icon"
            />
            <Typography
              variant="body1"
              color="#788894"
              textTransform="capitalize"
            >
              End Date: {selectedJob?.role?.end_date}
            </Typography>
          </Box>
        </Grid>

        <Grid item xs={12} md={6}>
          <Box sx={boxStyles}>
            <img
              style={{ width: "24px", height: "24px" }}
              src={hoursIcon}
              alt="Hours icon"
            />
            <Typography
              variant="body1"
              color="#788894"
              textTransform="capitalize"
            >
              Hours: {selectedJob?.role?.hours}
            </Typography>
          </Box>
        </Grid>
        <Grid item xs={12} md={6}>
          <Box sx={boxStyles}>
            <img
              style={{ width: "24px", height: "24px" }}
              src={dollarIcon}
              alt="Dollar icon"
            />
            <Typography
              variant="body1"
              color="#788894"
              textTransform="capitalize"
            >
              Salary: {selectedJob?.role?.salary}
            </Typography>
          </Box>
        </Grid>
      </Grid>
    </StyledWrapper>
  );
};

export default SupplyValueJobDetailsData;
