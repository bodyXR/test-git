import React from "react";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import { Typography } from "@mui/material";
import DOMPurify from "dompurify";
import { useSelector } from "react-redux";

const SupplyValueJobDetailsDescription = () => {
  const { selectedJob } = useSelector((state) => state.jobVacancy);

  const sanitizedHtmlString = DOMPurify.sanitize(
    selectedJob?.role?.description,
    {
      USE_PROFILES: { html: true },
    }
  );
  return (
    <StyledWrapper>
      <Typography variant="h3" color="darkGreen" mb={2}>
        Description
      </Typography>
      {selectedJob?.role?.description && (
        <Typography
          dangerouslySetInnerHTML={{ __html: sanitizedHtmlString }}
          color="inactive.main"
          mb={2}
        />
      )}
      {!selectedJob?.role?.description && (
        <Typography color="inactive.main" mb={2}>
          No description found!
        </Typography>
      )}
    </StyledWrapper>
  );
};

export default SupplyValueJobDetailsDescription;
