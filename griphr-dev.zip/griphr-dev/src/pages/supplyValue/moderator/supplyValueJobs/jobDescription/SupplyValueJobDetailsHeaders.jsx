import { Button, Stack } from "@mui/material";
import { NavLink } from "react-router-dom";
import { MODERATOR_PAGE_ROUTE } from "../../../../../routes/paths";
import { useSelector } from "react-redux";

const SupplyValueJobDetailsHeaders = () => {
  const { selectedJob } = useSelector((state) => state.jobVacancy);
  const { id } = selectedJob;
  const headers = [
    {
      name: "Job description",
      path: `${MODERATOR_PAGE_ROUTE}/jobs/${id}/details`,
    },
    { name: "Matches", path: `${MODERATOR_PAGE_ROUTE}/jobs/${id}/matches` },
    {
      name: "Candidates",
      path: `${MODERATOR_PAGE_ROUTE}/jobs/${id}/candidates`,
    },
  ];
  return (
    <Stack
      sx={{
        display: "flex",
        flexDirection: { sm: "row" },
        alignItems: { xs: "center", sm: "auto" },
      }}
    >
      {headers.map((header, index) => (
        <NavLink to={header.path} key={index}>
          {({ isActive }) => (
            <Button
              variant="text"
              sx={{
                color: isActive ? "darkGreen" : "darkGrey",
                bgcolor: isActive && "softAccent",
                borderBottom: isActive && "2px solid",
                borderColor: "accent",
                borderRadius: 0,
                textTransform: "unset",
              }}
            >
              {header.name}
            </Button>
          )}
        </NavLink>
      ))}
    </Stack>
  );
};

export default SupplyValueJobDetailsHeaders;
