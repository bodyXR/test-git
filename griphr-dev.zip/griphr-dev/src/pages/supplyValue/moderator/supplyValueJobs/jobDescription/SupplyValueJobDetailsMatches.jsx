import React, { useEffect, useRef, useState } from "react";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import { CircularProgress, IconButton, Stack, Typography } from "@mui/material";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import ListInactiveIcon from "../../../../../assets/menu_icon.svg";
import ListIcon from "../../../../../assets/menu_active.svg";
import gridInactiveIcon from "../../../../../assets/fourSquare_inactive.svg";
import gridIcon from "../../../../../assets/fourSquare_icon.svg";
import { useDispatch, useSelector } from "react-redux";
import { unwrapResult } from "@reduxjs/toolkit";
import { fetchMatchesData } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import MatchingCard from "./MatchingCard";
import { Link } from "react-router-dom";
import MatchesTable from "./MatchesTable";
import { MODERATOR_PAGE_ROUTE } from "../../../../../routes/paths";
import JobMatchesActionsModule from "../jobMatches/JobMatchesActionsModule";
import {
  clearSelectedJobCandidateDetails,
  removeAllSelectedMatches,
} from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import CandidateDetails from "../../searchCandidate/CandidateDetails";

const SupplyValueJobDetailsMatches = () => {
  const dispatch = useDispatch();
  const [selectedGriding, setSelectedGriding] = useState("grid");

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const {
    Matches,
    isLoadingGettingMatches,
    isErrorGettingMatches,
    isSuccessGettingMatches,
    selectedMatches,
    selectedJob,
    selectedJobCandidateDetails,
  } = useSelector((state) => state.jobVacancy);

  const handleCandidateDetailsClose = () => {
    dispatch(clearSelectedJobCandidateDetails());
  };

  useEffect(() => {
    if (!Matches) {
      const fetchMatches = async () => {
        try {
          const res = await dispatch(fetchMatchesData(selectedJob?.id));
          const data = await unwrapResult(res);
          handleClickSnackbar("Matches loaded successfully", "success");
        } catch (error) {
          handleClickSnackbar(
            error?.response?.data?.message || "Fail to fetch Matches",
            "error"
          );
        }
      };

      fetchMatches();
    }
  }, []);

  useEffect(() => {
    dispatch(removeAllSelectedMatches());
  }, [selectedGriding]);

  return (
    <StyledWrapper sx={{ gap: 3 }}>
      <Stack
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
        }}
      >
        <Stack
          sx={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            mt: 1,
          }}
        >
          <Typography variant="h3" color="darkGreen" mb={2}>
            Matches -{" "}
            <span style={{ fontWeight: 400 }}>
              here are the possible matches for your job posted
            </span>
          </Typography>
        </Stack>
        <Stack
          sx={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            width: { xs: "100%", lg: "fit-content" },
          }}
        >
          <IconButton
            onClick={() => {
              setSelectedGriding("list");
            }}
          >
            <img
              style={{ width: "24px", height: "24px" }}
              src={selectedGriding === "list" ? ListIcon : ListInactiveIcon}
              alt="list icon"
            />
          </IconButton>

          <IconButton
            onClick={() => {
              setSelectedGriding("grid");
            }}
          >
            <img
              style={{ width: "24px", height: "24px" }}
              src={selectedGriding === "grid" ? gridIcon : gridInactiveIcon}
              alt="grid icon"
            />
          </IconButton>

          {selectedMatches.length > 0 && <JobMatchesActionsModule />}
        </Stack>
      </Stack>
      <Stack>
        {isLoadingGettingMatches && <CircularProgress size={20} />}
        {isErrorGettingMatches && (
          <Typography
            sx={{ textAlign: "center", textTransform: "capitalize" }}
            variant="h5"
          >
            Fail to fetch Matches!
          </Typography>
        )}
        {isSuccessGettingMatches && (
          <>
            {selectedGriding === "grid" ? (
              <Grid2 container xs={12} sx={{ gap: 2 }}>
                {Matches.slice(0, 2).map((matchData) => (
                  <MatchingCard
                    data={matchData}
                    selectedJob={selectedJob}
                    key={matchData.id}
                  />
                ))}
              </Grid2>
            ) : (
              <Grid2 container xs={12}>
                <MatchesTable />
              </Grid2>
            )}
            {Matches.length > 2 && (
              <Link
                to={`${MODERATOR_PAGE_ROUTE}/jobs/${selectedJob.id}/matches`}
                title={"show more.."}
                onClick={() => {}}
                style={{
                  fontSize: "12px",
                  textDecoration: "underline",
                  textTransform: "capitalize",
                  color: "#66C1FF",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                  }}
                >
                  Show more...
                </Typography>
              </Link>
            )}
            {selectedJobCandidateDetails && (
              <CandidateDetails
                data={selectedJobCandidateDetails}
                onClose={handleCandidateDetailsClose}
              />
            )}
          </>
        )}
      </Stack>
    </StyledWrapper>
  );
};

export default SupplyValueJobDetailsMatches;
