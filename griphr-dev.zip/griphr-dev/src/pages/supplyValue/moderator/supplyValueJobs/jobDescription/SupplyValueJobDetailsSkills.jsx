import React from "react";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import { Stack, Typography } from "@mui/material";
import { useSelector } from "react-redux";
import SkillItem from "../../components/SkillItem";

const SupplyValueJobDetailsSkills = () => {
  const { selectedJob } = useSelector((state) => state.jobVacancy);
  return (
    <StyledWrapper sx={{ gap: 2 }}>
      <Typography variant="h3" color="darkGreen" mb={2}>
        Skills required
      </Typography>

      <Stack sx={{ flexDirection: "row",flexWrap:"wrap", gap: 1.5 }}>
        {selectedJob?.role?.skills?.map((skill) => (
          <SkillItem data={skill} key={skill.id} />
        ))}
      </Stack>
    </StyledWrapper>
  );
};

export default SupplyValueJobDetailsSkills;
