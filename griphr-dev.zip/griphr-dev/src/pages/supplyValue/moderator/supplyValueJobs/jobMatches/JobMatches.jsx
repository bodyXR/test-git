import React, { useEffect } from "react";
import {
  bulkAddToCandidates,
  fetchMatchesData,
} from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";
import useMenu from "../../../../../hooks/useMenu";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import { Stack, useMediaQuery } from "@mui/material";
import JobMatchesToolBar from "./JobMatchesToolBar";
import {
  clearSelectedJobCandidateDetails,
  removeAllSelectedMatches,
} from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import JobMatchesDesktopFilters from "./JobMatchesDesktopFilters";
import MatchesTable from "./MatchesTable";
import CandidateDetails from "../../searchCandidate/CandidateDetails";

const JobMatches = () => {
  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const dispatch = useDispatch();
  const { handleClose, handleOpen, menuAnchorEl, open } = useMenu();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  // Reset selected matches on component unmount and mount
  useEffect(() => {
    dispatch(removeAllSelectedMatches());
  }, [dispatch]);

  const {
    Matches,
    isFilterExtended,
    selectedMatches,
    selectedJob,
    selectedJobCandidateDetails,
  } = useSelector((state) => state.jobVacancy);

  const handleCandidateDetailsClose = () => {
    dispatch(clearSelectedJobCandidateDetails());
  };

  const handleAddToCandidates = async () => {
    try {
      const ids = selectedMatches.map((match) => match.id);
      const addToJobListResult = await dispatch(
        bulkAddToCandidates({
          user_ids: ids,
          job_vacancy_ids: [selectedJob.id],
        })
      );
      await unwrapResult(addToJobListResult);
      handleClickSnackbar("added Candidate successfully", "success");
    } catch (error) {
      console.log(error);
      handleClickSnackbar(error || "Fail to Add Candidate to Job", "error");
    }
  };

  useEffect(() => {
    if (!Matches) {
      const fetchMatches = async () => {
        try {
          const res = await dispatch(fetchMatchesData(selectedJob?.id));
          const data = await unwrapResult(res);
          handleClickSnackbar("Matches loaded successfully", "success");
        } catch (error) {
          handleClickSnackbar(
            error?.response?.data?.message || "Fail to fetch Matches",
            "error"
          );
        }
      };

      fetchMatches();
    }
  }, [Matches]);

  return (
    <Stack sx={{ height: "100%" }} gap={3}>
      <JobMatchesToolBar />
      <Stack sx={{ flexDirection: "row", gap: 1.5, flex: 1 }}>
        {lgMatches && isFilterExtended && <JobMatchesDesktopFilters />}
        <MatchesTable />
      </Stack>
      {selectedJobCandidateDetails && (
        <CandidateDetails
          data={selectedJobCandidateDetails}
          onClose={handleCandidateDetailsClose}
        />
      )}
    </Stack>
  );
};

export default JobMatches;
