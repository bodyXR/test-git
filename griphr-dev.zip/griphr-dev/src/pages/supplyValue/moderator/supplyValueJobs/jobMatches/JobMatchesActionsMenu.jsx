import {
  Box,
  ListItemIcon,
  ListItemText,
  Menu,
  useMediaQuery,
} from "@mui/material";
import menu from "../../../../../assets/menu_icon.svg";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import StyledMenuItem from "../../../../../components/styled/StyledMenuItem";
import { unwrapResult } from "@reduxjs/toolkit";
import {
  bulkAddToCandidates,
} from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";

const JobMatchesActionsMenu = ({
  width = "",
  anchor,
  open,
  onClose,
}) => {
  const { selectedJob , selectedMatches} = useSelector((state) => state.jobVacancy);
  const dispatch = useDispatch();
  const smStyles = useMediaQuery((theme) => theme.breakpoints.up("sm"));

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleBulkAddToCandidates = async () => {
    try {
      const addToJobListResult = await dispatch(
        bulkAddToCandidates({
          user_ids: selectedMatches,
          job_vacancy_ids: [selectedJob.id],
        })
      );
      await unwrapResult(addToJobListResult);
      handleClickSnackbar("added Candidate successfully", "success");
    } catch (error) {
      console.log(error);
      handleClickSnackbar(error || "Fail to Add Candidate to Job", "error");
    }
  };

  return (
    <Menu
      anchorEl={anchor}
      open={open}
      onClose={onClose}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "center",
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "center",
      }}
      sx={{
        ".MuiMenu-paper": smStyles
          ? {}
          : {
              width: width,
              maxWidth: { sm: "600px" },
            },
      }}
    >
      <StyledMenuItem
        onClick={() => {
            handleBulkAddToCandidates();
            onClose();
        }}
      >
        <ListItemIcon>
          <Box component={"img"} src={menu} />
        </ListItemIcon>
        <ListItemText sx={{textTransform:"capitalize"}}>Add to candidates</ListItemText>
      </StyledMenuItem>
    </Menu>
  );
};

export default JobMatchesActionsMenu;
