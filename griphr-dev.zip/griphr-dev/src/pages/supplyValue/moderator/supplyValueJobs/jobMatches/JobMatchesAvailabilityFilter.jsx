import React from "react";
import FilterSection from "../../components/FilterSection";
import StyledFilterLabel from "../../../../../components/styled/StyledFilterLabel";
import { FormGroup } from "@mui/material";
import StyledFilterCheckbox from "../../../../../components/styled/StyledFilterCheckbox";
import { useDispatch, useSelector } from "react-redux";
import { addSelectedAvailabilityHours, removeSelectedAvailabilityHours } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const availabilityHours = ["8-16", "16-24", "24-36", "36+"];

const mapAvailabilityToTuple = (item) => {
  switch (item) {
    case "8-16":
      return "(8,16)";
    case "16-24":
      return "(16,24)";
    case "24-36":
      return "(24,36)";
    case "36+":
      return "(36,100)";
    default:
      return "";
  }
};

const JobMatchesAvailabilityFilter = () => {
  const dispatch = useDispatch();

  const { selectedAvailabilityHours } = useSelector(
    (state) => state.jobVacancy
  );

  return (
    <FilterSection title="Hourly availability">
      <FormGroup>
        {availabilityHours?.length > 0 &&
          availabilityHours.map((item) => {
            const value = mapAvailabilityToTuple(item);
            const isSelected = selectedAvailabilityHours.some(
              (selected) => selected === value
            );
            return (
              <StyledFilterLabel
                key={item}
                control={
                  <StyledFilterCheckbox
                    checked={isSelected}
                    onChange={() => {
                      if (isSelected) {
                        return dispatch(removeSelectedAvailabilityHours(value));
                      }
                      dispatch(addSelectedAvailabilityHours(value));
                    }}
                    name={item}
                  />
                }
                label={`${item} hr/week`}
              />
            );
          })}
      </FormGroup>
    </FilterSection>
  );
};

export default JobMatchesAvailabilityFilter;
