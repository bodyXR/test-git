import React from "react";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import JobMatchesFiltersContent from "./JobMatchesFiltersContent";
import { Typography } from "@mui/material";

const JobMatchesDesktopFilters = () => {
  return (
    <StyledWrapper
      sx={{
        minWidth: "292px",
        maxWidth: "292px",
        gap: 2,
        height: "62vh",
        // height:'400px',
        overflowY: "auto",
      }}
    >
      <Typography variant="h6">Filters</Typography>
      <JobMatchesFiltersContent />
    </StyledWrapper>
  );
};

export default JobMatchesDesktopFilters;
