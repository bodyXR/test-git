import React from "react";
import JobMatchesRoleFilter from "./JobMatchesRoleFilter";
import JobMatchesHourlyRateFilter from "./JobMatchesHourlyRateFilter";
import JobMatchesAvailabilityFilter from "./JobMatchesAvailabilityFilter";

const JobMatchesFiltersContent = () => {
  return (
    <>
      <JobMatchesRoleFilter />
      <JobMatchesHourlyRateFilter />
      <JobMatchesAvailabilityFilter />
    </>
  );
};

export default JobMatchesFiltersContent;
