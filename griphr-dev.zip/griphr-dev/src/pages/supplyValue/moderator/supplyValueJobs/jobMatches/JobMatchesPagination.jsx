import { Pagination } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchMatchesData } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { useParams } from "react-router-dom";

const JobMatchesPagination = () => {
  const dispatch = useDispatch();
//   const idParam = useParams();
//   const jobid = idParam.jobId;

  const { paginationStatus , selectedJob , currentMatchesFiltersParams} = useSelector(
    (state) => state.jobVacancy
  );

  const [pagination, setPagination] = useState(1);

  const handlePagination = (event, value) => {
    setPagination(value);
  };

  useEffect(() => {
    dispatch(fetchMatchesData({ page: pagination, jobId: selectedJob.id , filters : currentMatchesFiltersParams}));
  }, [pagination]);

  return (
    <Pagination
      page={pagination}
      count={Math.ceil(paginationStatus?.status?.total_candidates / 5)}
      shape="rounded"
      size="large"
      onChange={handlePagination}
    />
  );
};

export default JobMatchesPagination;
