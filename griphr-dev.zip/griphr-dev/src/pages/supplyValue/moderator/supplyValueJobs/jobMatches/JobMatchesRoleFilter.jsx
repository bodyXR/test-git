import { FormGroup, InputAdornment } from "@mui/material";
import StyledSearchBar from "../../../../../components/styled/StyledSearchBar";
import search from "../../../../../assets/search.svg";
import { useDispatch, useSelector } from "react-redux";
import FilterSection from "../../components/FilterSection";
import useSearch from "../../../../../hooks/useSearch";
import { useEffect } from "react";
import { getJobProfiles } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { addSelectedRole, removeSelectedRole } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import capitalizeFirstWord from "../../../../../helper/capitalizeFirstWord";
import StyledFilterLabel from "../../../../../components/styled/StyledFilterLabel";
import StyledFilterCheckbox from "../../../../../components/styled/StyledFilterCheckbox";

const JobMatchesRoleFilter = () => {
  const { selectedRoles, jobProfiles: roles } = useSelector(
    (state) => state.jobVacancy
  );
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getJobProfiles());
  }, []);

  const { filteredData, setSearchQuery, searchQuery } = useSearch(roles, [
    "title",
  ]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  return (
    <FilterSection title="Role">
      <StyledSearchBar
        name="roleSearch"
        fullWidth
        size="small"
        type="search"
        variant="outlined"
        value={searchQuery}
        onChange={(e) => handleSearchChange(e)}
        placeholder="Search"
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <img src={search} alt="search icon" />
            </InputAdornment>
          ),
        }}
      />
      <FormGroup>
        {filteredData?.length > 0 &&
          filteredData.map((role, index) => (
            <StyledFilterLabel
              key={role?.id}
              control={
                <StyledFilterCheckbox
                  checked={selectedRoles.includes(role?.id)}
                  onChange={() => {
                    if (selectedRoles.includes(role?.id)) {
                      dispatch(removeSelectedRole(role?.id));
                      return;
                    }
                    dispatch(addSelectedRole(role?.id));
                  }}
                  name={role?.title}
                />
              }
              label={capitalizeFirstWord(role?.title)}
            />
          ))}
      </FormGroup>
    </FilterSection>
  );
};

export default JobMatchesRoleFilter;
