import { Button, Stack, useMediaQuery } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import SearchMatchesModule from "./SearchMatchesModule";
import JobMatchesFilterMobileModule from "./JobMatchesFilterMobileModule";
import JobMatchesActionsModule from "./JobMatchesActionsModule";
import filter from "../../../../../assets/filter.svg";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import StyledFiltersStateButton from "../../components/styled/StyledFiltersStateButton";
import { toggleFilters } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const JobMatchesToolBar = () => {
  const dispatch = useDispatch();
  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const mdMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("md", "lg")
  );
  const xsMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("xs", "md")
  );
  const { Matches, selectedMatches, isFilterExtended } = useSelector(
    (state) => state.jobVacancy
  );

  return (
    <Stack
      sx={{
        gap: { xs: 2 },
        flexDirection: { lg: "row" },
        justifyContent: "space-between",
      }}
    >
      <Stack sx={{ flexDirection: "row", width: "100%", gap: 1 }}>
        {lgMatches && (
          <Grid2>
            <StyledFiltersStateButton
              startIcon={<img src={filter} alt="filter icon" />}
              variant="outlined"
              onClick={()=>dispatch(toggleFilters())}
            >
              {isFilterExtended ? "Hide filters" : "Show filters"}
            </StyledFiltersStateButton>
          </Grid2>
        )}
        <Grid2 sx={{ flex: 1 }}>
          <SearchMatchesModule />
        </Grid2>
      </Stack>
      {Matches && Matches?.length > 0 && (
        <>
          {selectedMatches.length > 0 && lgMatches && (
            <Stack sx={{ flexDirection: "row", gap: 2 }}>
              <JobMatchesActionsModule />
            </Stack>
          )}
          {mdMatches && (
            <Stack sx={{ gap: { xs: 2 }, flexDirection: { xs: "row" } }}>
              <JobMatchesFilterMobileModule />
              {selectedMatches.length > 0 && <JobMatchesActionsModule />}
            </Stack>
          )}
          {xsMatches && (
            <>
              <Stack sx={{ gap: { xs: 2 }, flexDirection: { xs: "row" } }}>
                <JobMatchesFilterMobileModule />
              </Stack>
              {selectedMatches.length > 0 && <JobMatchesActionsModule />}{" "}
            </>
          )}
        </>
      )}
    </Stack>
  );
};

export default JobMatchesToolBar;
