import React from "react";
import { useSelector } from "react-redux";
import MatchingRow from "../jobDescription/MatchingRow";

const MatchesRowWrapper = () => {
  const { searchedMatches } = useSelector((state) => state.jobVacancy);

  return (
    <>
      {searchedMatches.map((matchData) => (
        <MatchingRow data={matchData} key={matchData.id} />
      ))}
    </>
  );
};

export default MatchesRowWrapper;
