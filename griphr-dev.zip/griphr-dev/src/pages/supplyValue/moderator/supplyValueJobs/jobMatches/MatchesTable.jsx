import React, { useRef } from "react";
import { useDraggable } from "react-use-draggable-scroll";
import { Stack, Typography } from "@mui/material";
import MatchingHeaders from "../jobDescription/MatchingHeaders";
import MatchesRowWrapper from "./MatchesRowWrapper";
import JobMatchesPagination from "./JobMatchesPagination";
import { useSelector } from "react-redux";
import StyledTable from "../../components/StyledTable";

const MatchesTable = () => {
  const { paginationStatus } = useSelector((state) => state.jobVacancy);
  const ref = useRef();
  const { events } = useDraggable(ref);
  return (
    <StyledTable ref={ref} {...events} >
      {paginationStatus?.status?.total_candidates > 0 ? (
        <Stack
          sx={{
            width: {
              xs: "1170px",
              lg: "auto",
            },
            minWidth: "1170px",
            height: "100%",
            "& .match__row:last-child": {
              borderBottom: "none",
            },
          }}
        >
          <MatchingHeaders />
          <MatchesRowWrapper />
          <Stack sx={{ p: 2, alignItems: "center" }}>
            <JobMatchesPagination />
          </Stack>
        </Stack>
      ) : (
        <Typography variant="h3" color="primary" pt={{ xs: 2, lg: "20px" }}>
          No results found
        </Typography>
      )}
    </StyledTable>
  );
};

export default MatchesTable;
