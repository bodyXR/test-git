import { InputAdornment } from "@mui/material";
import search from "../../../../../assets/search.svg";
import StyledSearchBar from "../../../../../components/styled/StyledSearchBar";
import useSearch from "../../../../../hooks/useSearch";
import { useDispatch, useSelector } from "react-redux";
import { searchMatches } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const SearchMatchesModule = () => {
  const dispatch = useDispatch();
  const { Matches } = useSelector((state) => state.jobVacancy);

  const { searchQuery, setSearchQuery, filteredData } = useSearch(Matches, [
    "first_name",
    "last_name",
  ]);

  return (
    <StyledSearchBar
      name="search_matches"
      fullWidth
      size="small"
      type="search"
      variant="outlined"
      value={searchQuery}
      onChange={(e) => {
        setSearchQuery(e.target.value);
        if (e.target.value === "") {
          return dispatch(searchMatches(Matches));
        }
        dispatch(searchMatches(filteredData));
      }}
      placeholder="Search matches"
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <img src={search} alt="search icon" />
          </InputAdornment>
        ),
      }}
      sx={{
        alignSelf: "stretch",
        "& .MuiInputBase-root": {
          height: "44.5px",
        },
      }}
    />
  );
};

export default SearchMatchesModule;
