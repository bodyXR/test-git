import {
  Box,
  CircularProgress,
  IconButton,
  Stack,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import { useCallback, useEffect, useMemo } from "react";
import editIcon from "../../../../../assets/edit_icon.svg";
import { useDispatch, useSelector } from "react-redux";
import SupplyValueJobDetailsHeaders from "../jobDescription/SupplyValueJobDetailsHeaders";
import {
  fetchMatchesData,
  getJobById,
} from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import { Outlet, useNavigate, useParams } from "react-router-dom";
import { MODERATOR_PAGE_ROUTE } from "../../../../../routes/paths";
import { debounce } from "lodash";
import { setCurrentMatchesFiltersParams } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";

const JobPreview = () => {
  const navigate = useNavigate();
  const id = useParams();
  const dispatch = useDispatch();
  const theme = useTheme();
  const mdMatches = useMediaQuery(theme.breakpoints.up("md"));

  const {
    selectedJob,
    isLoadingGettingJob,
    isErrorGettingJob,
    isSuccessGettingJob,
    selectedRoles: roles,
    selectedAvailabilityHours: hourly_availabilities,
    minHourlyRate: min_hourly_rate,
    maxHourlyRate: max_hourly_rate,
  } = useSelector((state) => state.jobVacancy);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const filters = {
    roles,
    hourly_availabilities,
  };

  const filteredFilters = useMemo(() => {
    const result = Object.keys(filters).reduce((acc, key) => {
      if (filters[key] && filters[key].length > 0) {
        acc[key] = filters[key];
      }
      return acc;
    }, {});

    if (min_hourly_rate !== 0 || max_hourly_rate !== 0) {
      result.min_hourly_rate = min_hourly_rate;
      result.max_hourly_rate = max_hourly_rate;
    }

    return result;
  }, [filters, min_hourly_rate, max_hourly_rate]);

  const fetchAllMatches = useCallback(
    debounce(async (filters) => {
      try {
        const jobId = id.jobId;
        const res = await dispatch(fetchMatchesData({ jobId, filters }));
        const data = await unwrapResult(res);
        console.log("data from Matches", data);
        handleClickSnackbar("Matches loaded successfully", "success");
      } catch (error) {
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch Matches",
          "error"
        );
      }
    }, 1000),
    [dispatch]
  );

  useEffect(() => {
    dispatch(setCurrentMatchesFiltersParams(filteredFilters));
    fetchAllMatches(filteredFilters);

    return () => {
      fetchAllMatches.cancel();
    };
  }, [roles, hourly_availabilities, min_hourly_rate, max_hourly_rate]);

  useEffect(() => {
    const fetchJobById = async () => {
      try {
        const res = await dispatch(getJobById(id.jobId));
        await unwrapResult(res);
        handleClickSnackbar("fetched Job successfully", "success");
      } catch (error) {
        console.log(error);
        handleClickSnackbar(error || "Fail to fetch Job", "error");
      }
    };

    fetchJobById();
  }, []);
  return (
    <>
      {isErrorGettingJob && (
        <Typography variant="h2" color="#173433" textTransform="capitalize">
          Error fetching job
        </Typography>
      )}
      {isLoadingGettingJob && (
        <Stack sx={{ alignItems: "center" }}>
          <CircularProgress />
        </Stack>
      )}
      {isSuccessGettingJob && selectedJob && (
        <Stack gap={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: { xs: "center", sm: "initial" },
              gap: { xs: 1, sm: 2 },
              flexWrap: { xs: "wrap", sm: "nowrap" },
            }}
          >
            <Typography variant="h2" color="#173433" textTransform="capitalize">
              {selectedJob?.role?.title || "Unknown"}
            </Typography>

            <IconButton
              onClick={() => {
                navigate(`${MODERATOR_PAGE_ROUTE}/edit-job/${selectedJob?.id}`);
              }}
            >
              <Box
                component={"img"}
                sx={{
                  width: { xs: "16px", sm: "24px" },
                  height: { xs: "16px", sm: "24px" },
                }}
                src={editIcon}
                alt="Edit icon"
              />
            </IconButton>
          </Box>

          <SupplyValueJobDetailsHeaders />

          <Outlet />
        </Stack>
      )}
      {isSuccessGettingJob && !selectedJob && (
        <Typography variant="h2" sx={{ textAlign: "center" }}>
          Job Doesn't Exist!
        </Typography>
      )}
    </>
  );
};

export default JobPreview;
