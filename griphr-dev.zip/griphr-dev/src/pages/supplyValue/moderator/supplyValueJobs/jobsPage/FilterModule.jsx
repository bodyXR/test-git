import {
  Button,
  FormGroup,
  Menu,
  MenuItem,
  Stack,
  Typography,
  useMediaQuery,
} from "@mui/material";
import useMenu from "../../../../../hooks/useMenu";
import filter from "../../../../../assets/filter.svg";
import AddIcon from "@mui/icons-material/Add";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { setSelectedFilter } from "../../../../../redux/slices/moderator/jobs/jobVacancySlice";
import StyledFilterLabel from "../../../../../components/styled/StyledFilterLabel";
import StyledFilterCheckbox from "../../../../../components/styled/StyledFilterCheckbox";
import StyledDarkBtn from "../../../../../components/styled/StyledDarkBtn";
import { MODERATOR_CREATE_JOB_ROUTE } from "../../../../../routes/paths";

const FilterModule = () => {
  const lgMedia = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const selectedFilterState = useSelector(
    (state) => state.jobVacancy.selectedFilter
  );

  const { menuAnchorEl, open, handleOpen, handleClose } = useMenu();

  const handleFilterChange = (event) => {
    dispatch(setSelectedFilter(event.target.name));
    handleClose();
  };

  return (
    <>
      <Stack
        sx={{
          flexDirection: { sm: "row" },
          justifyContent: "space-between",
          alignItems: { sm: "center" },
          mb: 3,
          flexWrap: "wrap",
        }}
      >
        <Typography variant="h2">Jobs</Typography>

        <Stack sx={{ display: "flex", gap: 3, flexDirection: "row" }}>
          <Button
            onClick={handleOpen}
            sx={{
              alignSelf: "center",
              textTransform: "none",
              border: "2px solid #e9e9e9 ",
              borderRadius: "4px",
              color: "primary.main",
              fontWeight: "400",
              px: 3,
              "&: hover": {
                border: "2px solid #e9e9e9 ",
              },
            }}
            disableElevation
            disableRipple
            startIcon={<img src={filter} alt="Filter icon" />}
            variant="outlined"
            aria-controls="filter-menu"
            aria-haspopup="true"
          >
            {selectedFilterState === "allItems"
              ? "All items"
              : selectedFilterState}
          </Button>

          <StyledDarkBtn
            onClick={() => {
              navigate(MODERATOR_CREATE_JOB_ROUTE, { replace: true });
            }}
            min_width={lgMedia ? "190px" : "130px"}
            sx={{ flex: { xs: 1 }, py: 0.9, textTransform: "unset" }}
            endIcon={<AddIcon />}
          >
            Create job
          </StyledDarkBtn>
        </Stack>
      </Stack>

      <Menu
        id="filter-menu"
        anchorEl={menuAnchorEl}
        open={Boolean(menuAnchorEl)}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        PaperProps={{
          style: {
            width: "210px",
          },
        }}
        sx={{}}
      >
        <FormGroup>
          <MenuItem sx={{ fontSize: "16px", color: "#788894" }}>
            <StyledFilterLabel
              control={
                <StyledFilterCheckbox
                  checked={selectedFilterState === "allItems"}
                  onChange={handleFilterChange}
                  name="allItems"
                />
              }
              label="All items"
            />
          </MenuItem>
          <MenuItem sx={{ fontSize: "16px", color: "#788894" }}>
            <StyledFilterLabel
              control={
                <StyledFilterCheckbox
                  checked={selectedFilterState === "pending"}
                  onChange={handleFilterChange}
                  name="pending"
                />
              }
              label="Pending"
            />
          </MenuItem>
          <MenuItem sx={{ fontSize: "16px", color: "#788894" }}>
            <StyledFilterLabel
              control={
                <StyledFilterCheckbox
                  checked={selectedFilterState === "approved"}
                  onChange={handleFilterChange}
                  name="approved"
                />
              }
              label="Approved"
            />
          </MenuItem>
          <MenuItem sx={{ fontSize: "16px", color: "#788894" }}>
            <StyledFilterLabel
              control={
                <StyledFilterCheckbox
                  checked={selectedFilterState === "declined"}
                  onChange={handleFilterChange}
                  name="declined"
                />
              }
              label="Declined"
            />
          </MenuItem>
        </FormGroup>
      </Menu>
    </>
  );
};

export default FilterModule;
