import {
  IconButton,
  Menu,
  MenuItem,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";

import moreHoriz__icon from "../../../../../assets/moreHoriz__icon.svg";
import useDialog from "../../../../../hooks/useDialog";
import { deleteJobAndGetAll } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import { useDispatch } from "react-redux";
import { unwrapResult } from "@reduxjs/toolkit";
import { useNavigate } from "react-router-dom";
import { MODERATOR_PAGE_ROUTE } from "../../../../../routes/paths";
import DeleteModule from "../../components/DeleteModule";
import { useState } from "react";

const JobCardActionsModule = (props) => {
  const [isDeletingJob, setIsDeletingJob] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const theme = useTheme();
  const mdMatches = useMediaQuery(theme.breakpoints.up("md"));

  const { openDialog, handleOpenDialog, handleCloseDialog } = useDialog();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleDeleteJob = async () => {
    try {
      setIsDeletingJob(true);
      const res = await dispatch(deleteJobAndGetAll(props.id));
      await unwrapResult(res);
      setIsDeletingJob(false);
      handleClickSnackbar("Job deleted successfully", "success");
    } catch (error) {
      handleClickSnackbar(
        error?.response?.data?.message || "Fail to delete job",
        "error"
      );
    }
  };

  return (
    <>
      <DeleteModule
        openDialog={openDialog}
        handleDelete={handleDeleteJob}
        handleCloseDialog={handleCloseDialog}
        title={"job"}
        isDeleting={isDeletingJob}
      />

      <Menu
        anchorEl={props.menuAnchorEl}
        open={Boolean(props.menuAnchorEl)}
        onClose={props.handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        PaperProps={{
          style: {
            width: "120px",
          },
        }}
      >
        {/* TODO : add edit job page on onclick function */}
        <MenuItem
          onClick={() => {
            navigate(`${MODERATOR_PAGE_ROUTE}/edit-job/${props.id}`);
          }}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            color: "#788894",
          }}
        >
          <Typography>Edit</Typography>
        </MenuItem>

        <MenuItem
          onClick={handleOpenDialog}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            color: "#788894",
          }}
        >
          <Typography>Delete</Typography>
        </MenuItem>
      </Menu>
    </>
  );
};

export default JobCardActionsModule;
