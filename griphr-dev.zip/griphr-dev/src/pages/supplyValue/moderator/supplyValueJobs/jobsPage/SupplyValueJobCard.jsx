import React, { useState } from "react";
import {
  Box,
  Button,
  IconButton,
  Stack,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";

import { Link } from "react-router-dom";
import StyledWrapper from "../../../../../components/styled/StyledWrapper";
import JobCardActionsModule from "./JobCardActionsModule";
import moreHoriz__icon from "../../../../../assets/moreHoriz__icon.svg";
import useMenu from "../../../../../hooks/useMenu";
import { MODERATOR_JOBS_ROUTE } from "../../../../../routes/paths";

const SupplyValueJobCard = (jobs) => {
  const theme = useTheme();
  const mdMatches = useMediaQuery(theme.breakpoints.up("md"));

  const [showMore, setShowMore] = useState(false);
  const data = jobs?.job;

  const { menuAnchorEl, open, handleOpen, handleClose } = useMenu();

  const formattedDescription = data?.description ? data.description : "";

  return (
    <StyledWrapper>
      <Box
        sx={{
          position: "relative",
          height: showMore ? "auto" : { xs: "247px", md: "228px" },
        }}
      >
        <JobCardActionsModule
          menuAnchorEl={menuAnchorEl}
          handleOpen={handleOpen}
          handleClose={handleClose}
          id={data.id}
        />
        <Stack
          sx={{
            flexDirection: { xs: "row", justifyContent: "space-between" },
            alignItems: { md: "center" },
            gap: { xs: 1, md: 0 },
            mb: 1,
          }}
        >
          <Link
            to={`${MODERATOR_JOBS_ROUTE}/${data.id}/details`}
            title={data?.title}
            style={{
              fontSize: "14px",
              textDecoration: "underline",
              textTransform: "capitalize",
              color: "#173433",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            <Typography
              variant="h3"
              sx={{
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {data?.role?.title}
            </Typography>
          </Link>
          <IconButton onClick={handleOpen} sx={{ alignSelf: "center", p: 0 }}>
            <img src={moreHoriz__icon} alt="More horizontal icon" />
          </IconButton>
        </Stack>

        <Typography
          variant="h5"
          sx={{ color: "#788894", textTransform: "capitalize", mb: 1 }}
        >
          {`${data?.department ? ` ${data?.department} -` : ""} Start date: ${
            data?.role?.start_date
          } ${data?.role?.hours ? `- ${data?.role?.hours}` : ""} ${
            data?.role?.salary ? `- USD $${data?.role?.salary}` : ""
          }`}
        </Typography>

        <Stack
          sx={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Stack>
            <Box
              sx={{
                width: { xs: "149px", md: "200px" },
                height: showMore ? "auto" : "63px",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              <Typography
                variant="body1"
                sx={{ color: "#788894", width: "100%" }}
              >
                {formattedDescription}
              </Typography>
            </Box>

            {formattedDescription?.length >= 87 && (
              <Button
                disableRipple={true}
                variant="text"
                sx={{
                  color: "#66C1FF",
                  alignSelf: "flex-start",
                  textTransform: "capitalize",
                  fontWeight: "400",
                  lineHeight: "1.5",
                  "&: hover": {
                    backgroundColor: "transparent",
                  },
                  fontSize: { xs: "12px", md: "16px" },
                  mt: { xs: -1 },
                }}
                onClick={() => setShowMore(!showMore)}
              >
                {showMore ? "... show less" : "... show more"}
              </Button>
            )}
          </Stack>
        </Stack>
      </Box>
    </StyledWrapper>
  );
};

export default SupplyValueJobCard;
