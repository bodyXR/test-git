import { CircularProgress, Stack, Typography } from "@mui/material";
import { useLocation } from "react-router-dom";
import useTitle from "../../../../../hooks/useTitle";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import SupplyValueJobCard from "./SupplyValueJobCard";
import FilterModule from "./FilterModule";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../../redux/slices/snackbar/snackbarSlice";
import { useEffect } from "react";
import { getAllJobs } from "../../../../../redux/slices/moderator/jobs/jobVacancyActions";
import { unwrapResult } from "@reduxjs/toolkit";

const SupplyValueJobs = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  useTitle(location);

  const {
    jobs,
    isLoadingGettingJobs,
    isErrorGettingJobs,
    isSuccessGettingJobs,
    selectedFilter,
    matchesFound,
  } = useSelector((state) => state.jobVacancy);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    const fetchAllJobs = async () => {
      try {
        const res = await dispatch(
          getAllJobs(
            selectedFilter === "allItems" ? "all" : selectedFilter.toLowerCase()
          )
        );
        const data = await unwrapResult(res);
        console.log("data from Jobs", data);
        console.log("Jobs", jobs);
        handleClickSnackbar("Jobs list loaded successfully", "success");
      } catch (error) {
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch Jobs",
          "error"
        );
      }
    };

    fetchAllJobs();
  }, [selectedFilter]);

  return (
    <>
      {isLoadingGettingJobs && (
        <CircularProgress sx={{ alignSelf: "center" }} />
      )}
      {isErrorGettingJobs && (
        <Typography
          sx={{
            textTransform: "capitalize",
            textAlign: "center",
            fontSize: 23,
          }}
        >
          Failed to Load Jobs!
        </Typography>
      )}
      {isSuccessGettingJobs && (
        <>
          <Stack
            sx={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              pb: "25px",
              borderBottom: "2px solid #e9e9e9",
              mb: 3,
            }}
          >
            <Stack sx={{ flexDirection: "row", gap: "12px" }}>
              <Typography variant="h3" color="darkGreen">
                {jobs.length}
              </Typography>

              <Typography variant="h4" color="darkGreen">
                Total Jobs
              </Typography>
            </Stack>
          </Stack>

          <FilterModule />

          <Grid2
            container
            rowSpacing={"28px"}
            columnSpacing={"20px"}
            columns={{ xs: 4, md: 8, xl: 12 }}
          >
            {jobs && jobs.length > 0 ? (
              jobs.map(
                (jobdata) =>
                  (jobdata.status === selectedFilter ||
                    selectedFilter === "allItems") && (
                    <Grid2 xs={4} key={jobdata.id}>
                      <SupplyValueJobCard job={jobdata} />
                    </Grid2>
                  )
              )
            ) : (
              <Grid2 xs={12}>
                <Typography
                  variant="h2"
                  sx={{ textTransform: "capitalize", textAlign: "center" }}
                >
                  No Jobs Found!
                </Typography>
              </Grid2>
            )}
            {!matchesFound && (
              <Grid2 xs={12}>
                <Typography
                  variant="h2"
                  sx={{ textTransform: "capitalize", textAlign: "center" }}
                >
                  No Jobs Found!
                </Typography>
              </Grid2>
            )}
          </Grid2>
        </>
      )}
    </>
  );
};

export default SupplyValueJobs;
