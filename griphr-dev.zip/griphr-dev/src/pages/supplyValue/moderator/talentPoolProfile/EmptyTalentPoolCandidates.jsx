import { Box, Stack, Typography } from "@mui/material";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import pluspaperIcon from "../../../../assets/plus_paper.svg";
import { useNavigate } from "react-router-dom";
import { MODERATOR_SEARCH_CANDIDATE_ROUTE } from "../../../../routes/paths";

const EmptyTalentPoolCandidates = () => {
  const navigate = useNavigate();

  return (
    <StyledWrapper
      sx={{
        justifyContent: "center",
        alignItems: "center",
        textAlign: "center",
        gap: "12px",
        py: { xs: 5, lg: "20px" },
        flex: 1,
      }}
    >
      <Box
        sx={{ width: "40px", height: "50px" }}
        component={"img"}
        src={pluspaperIcon}
      />

      <Typography variant="h4" color="inactive.main">
        The list is empty, choose an option to start fill it{" "}
      </Typography>

      <Stack
        sx={{
          flexDirection: { lg: "row" },
          justifyContent: "center",
          alignItems: "center",
          gap: { xs: "12px", lg: 3 },
          width: { xs: "100%", md: "150px" },
        }}
      >
        <StyledDarkBtn
          onClick={() => navigate(MODERATOR_SEARCH_CANDIDATE_ROUTE)}
          min_width="190px"
          sx={{ width: "100%", textTransform: "unset" }}
        >
          Add candidate
        </StyledDarkBtn>
      </Stack>
    </StyledWrapper>
  );
};

export default EmptyTalentPoolCandidates;
