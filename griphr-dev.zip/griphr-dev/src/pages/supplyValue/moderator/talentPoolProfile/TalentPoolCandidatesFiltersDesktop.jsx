import { Stack, Typography } from "@mui/material";
import TalentPoolProfileFiltersContent from "./TalentPoolProfileFiltersContent";
import StyledWrapper from "../../../../components/styled/StyledWrapper";

const TalentPoolCandidatesFiltersDesktop = () => {
  return (
    <StyledWrapper
      sx={{
        minWidth: "292px",
        maxWidth: "292px",
        gap: 2,
        height: "62vh",
        // height:'400px',
        overflowY: "auto",
      }}
    >
      <Typography variant="h6">Filters</Typography>
      <TalentPoolProfileFiltersContent />
    </StyledWrapper>
  );
};

export default TalentPoolCandidatesFiltersDesktop;
