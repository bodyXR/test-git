import Grid from "@mui/material/Unstable_Grid2";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";
import { useDispatch, useSelector } from "react-redux";
import {
  removeAllSelectedTalentPoolCandidates,
  selectAllSelectedTalentPoolCandidates,
} from "../../../../redux/slices/moderator/talentPoolProfile/talentPoolProfileSlice";
import { Typography } from "@mui/material";
import { talentPoolCandidatesHeaders } from "../../../../data/talentPoolCandidatesData";

const TalentPoolCandidatesHeaders = () => {
  const dispatch = useDispatch();
  const { talentPoolCandidates, selectedTalentPoolCandidates } = useSelector(
    (state) => state.talentPoolProfile
  );
  console.log(
    "selectAllSelectedTalentPoolCandidates",
    selectedTalentPoolCandidates
  );

  return (
    <Grid
      container
      sx={{
        alignItems: "center",
        px: 2,
        pt: { xs: 2, lg: 3.5 },
        pb: 2,
        position: "sticky",
        top: 0,
        bgcolor: "background.white",
        zIndex: 99,
      }}
    >
      <Grid xs={1}>
        <StyledFilterCheckbox
          checked={
            talentPoolCandidates.length === selectedTalentPoolCandidates.length
          }
          onChange={() => {
            if (
              talentPoolCandidates.length ===
              selectedTalentPoolCandidates.length
            ) {
              dispatch(removeAllSelectedTalentPoolCandidates());
              return;
            }
            dispatch(selectAllSelectedTalentPoolCandidates());
          }}
        />
      </Grid>

      {talentPoolCandidatesHeaders.map((header, index) => (
        <Grid item xs={header.space} key={header.title}>
          <Typography
            variant="h5"
            sx={{
              color: "darkGreen",
              fontWeight: "500",
              textAlign: index === 0 ? "left" : "center",
              paddingLeft: index === 0 ? "8px" : "0",
            }}
          >
            {header.title}
          </Typography>
        </Grid>
      ))}
    </Grid>
  );
};

export default TalentPoolCandidatesHeaders;
