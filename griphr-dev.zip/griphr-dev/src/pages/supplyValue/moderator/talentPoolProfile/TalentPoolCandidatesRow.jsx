import Grid from "@mui/material/Unstable_Grid2";
import StyledFilterCheckbox from "../../../../components/styled/StyledFilterCheckbox";
import { useDispatch, useSelector } from "react-redux";
import {
  addSelectedTalentPoolCandidate,
  removeSelectedTalentPoolCandidate,
  setSelectedTalentPoolProfileCandidateDetails,
} from "../../../../redux/slices/moderator/talentPoolProfile/talentPoolProfileSlice";
import { Avatar, Stack, Typography } from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import useMenu from "../../../../hooks/useMenu";
import StyledSingleActionsBtn from "../../../../components/styled/StyledSingleActionsBtn";
import TalentPoolProfileActionsMenu from "./TalentPoolProfileActionsMenu";
import StyledCandidatesRowBody1 from "../../../../components/styled/StyledCandidatesRowBody1";
import { getCandidateById } from "../../../../redux/slices/moderator/candidatesList/candidatesListActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { getSkills } from "../../../../redux/slices/moderator/candidate/candidateActions";

const TalentPoolCandidatesRow = ({ data }) => {
  const { handleClose, handleOpen, menuAnchorEl, open } = useMenu();
  const dispatch = useDispatch();
  const { selectedTalentPoolCandidates } = useSelector(
    (state) => state.talentPoolProfile
  );

  const handleCandidateDetailsOpen = async () => {
    try {
      const fetchCandidateById = await dispatch(
        getCandidateById(data?.user?.id)
      );
      const candidateData = await unwrapResult(fetchCandidateById);
      const fetchSkills = await dispatch(getSkills(data?.user?.id));
      const candidateSkillsData = await unwrapResult(fetchSkills);
      dispatch(
        setSelectedTalentPoolProfileCandidateDetails({
          ...candidateData,
          skills: candidateSkillsData,
        })
      );
    } catch (error) {
      console.log("Error fetching data!", error);
    }
  };

  return (
    <Grid
      className="candidate__row"
      container
      sx={{
        alignItems: "center",
        borderBottom: "2px solid #EEE",
        p: 2,
      }}
    >
      <Grid xs={1}>
        <StyledFilterCheckbox
          checked={selectedTalentPoolCandidates.includes(data?.user?.id)}
          onChange={() => {
            if (selectedTalentPoolCandidates.includes(data?.user?.id)) {
              dispatch(removeSelectedTalentPoolCandidate(data?.user?.id));
              return;
            }
            dispatch(addSelectedTalentPoolCandidate(data?.user?.id));
          }}
        />
      </Grid>

      {/* Candidate Col */}
      <Grid xs={5.5}>
        <Stack
          sx={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Stack
            sx={{
              flexDirection: "row",
              alignItems: "center",
              gap: 1.25,
            }}
          >
            <Avatar
              src={data?.user?.profile_pic}
              alt={data?.user?.first_name + " " + data?.user?.last_name}
              sx={{ width: "30px", height: "30px" }}
            />

            <Stack sx={{ gap: 1.25 }}>
              <Typography
                onClick={handleCandidateDetailsOpen}
                variant="h5"
                title={data?.user?.first_name + " " + data?.user?.last_name}
                sx={{
                  "&:hover": {
                    color: "#66C1FF",
                    textDecoration: "underline",
                  },
                  textTransform: "capitalize",
                  color: "inactive.main",
                  fontWeight: 600,
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  cursor: "pointer",
                }}
              >
                {data?.user?.first_name + " " + data?.user?.last_name}
              </Typography>
              <StyledCandidatesRowBody1
                sx={{ textAlign: "left" }}
                variant="body1"
              >
                {data?.user?.title || "N/A"}
              </StyledCandidatesRowBody1>
            </Stack>
          </Stack>
        </Stack>
      </Grid>

      {/* Hourly-Rate Col */}
      <Grid xs={2}>
        <StyledCandidatesRowBody1
          variant="body1"
          sx={{ textTransform: "none" }}
        >
          {data?.user?.hourly_rate ? `€${data?.user?.hourly_rate}` : "N/A"}
        </StyledCandidatesRowBody1>
      </Grid>

      {/* Availability Col */}
      <Grid xs={2}>
        <StyledCandidatesRowBody1
          variant="body1"
          sx={{ textTransform: "none" }}
        >
          {data?.user?.availability ? `${data?.user?.availability}h/w` : "N/A"}
        </StyledCandidatesRowBody1>
      </Grid>

      {/* Actions Col */}
      <Grid xs={1.5} sx={{ textAlign: "right" }}>
        <StyledSingleActionsBtn
          expand={!!open}
          onClick={handleOpen}
          endIcon={<ExpandMoreIcon />}
        >
          Actions
        </StyledSingleActionsBtn>
        <TalentPoolProfileActionsMenu
          userId={data?.user?.id}
          anchor={menuAnchorEl}
          open={open}
          onClose={handleClose}
        />
      </Grid>
    </Grid>
  );
};

export default TalentPoolCandidatesRow;
