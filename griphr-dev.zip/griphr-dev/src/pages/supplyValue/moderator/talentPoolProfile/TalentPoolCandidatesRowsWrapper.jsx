import { clearSelectedTalentPoolProfileCandidateDetails } from "../../../../redux/slices/moderator/talentPoolProfile/talentPoolProfileSlice";
import CandidateDetails from "../searchCandidate/CandidateDetails";
import TalentPoolCandidatesRow from "./TalentPoolCandidatesRow";
import { useDispatch, useSelector } from "react-redux";

const TalentPoolCandidatesRowsWrapper = () => {
  const dispatch = useDispatch();
  const { searchedTalentPoolCandidates } = useSelector(
    (state) => state.talentPoolProfile
  );
  const { selectedTalentPoolProfileCandidateDetails } = useSelector(
    (state) => state.talentPoolProfile
  );

  const handleCandidateDetailsClose = () => {
    dispatch(clearSelectedTalentPoolProfileCandidateDetails());
  };

  return (
    <>
      {searchedTalentPoolCandidates &&
        searchedTalentPoolCandidates?.map((candidate, index) => (
          <TalentPoolCandidatesRow
            key={candidate?.id}
            isLast={index === candidate?.length - 1}
            data={candidate}
          />
        ))}

      {selectedTalentPoolProfileCandidateDetails && (
        <CandidateDetails
          data={selectedTalentPoolProfileCandidateDetails}
          onClose={handleCandidateDetailsClose}
        />
      )}
    </>
  );
};

export default TalentPoolCandidatesRowsWrapper;
