import { Stack, Typography } from "@mui/material";
import React, { useRef } from "react";
import TalentPoolCandidatesHeaders from "./TalentPoolCandidatesHeaders";
import TalentPoolCandidatesRowsWrapper from "./TalentPoolCandidatesRowsWrapper";
import { useSelector } from "react-redux";
import StyledTable from "../components/StyledTable";
import { useDraggable } from "react-use-draggable-scroll";

const TalentPoolCandidatesTable = () => {
  const ref = useRef();
  const { events } = useDraggable(ref);
  const { talentPoolCandidates } = useSelector(
    (state) => state.talentPoolProfile
  );

  return (
    <StyledTable
      ref={ref}
      {...events}
    >
      {talentPoolCandidates?.length > 0 ? (
        <Stack
          className="candidatesList__table"
          sx={{
            width: { xs: "1170px", lg: "initial" },
            height: "100%",
            "& .candidate__row:last-child": {
              borderBottom: "none",
            },
          }}
        >
          <TalentPoolCandidatesHeaders />
          <TalentPoolCandidatesRowsWrapper />
        </Stack>
      ) : (
        <Typography variant="h3" color="primary" pt={{ xs: 2, lg: "20px" }}>
          No results found
        </Typography>
      )}
    </StyledTable>
  );
};

export default TalentPoolCandidatesTable;
