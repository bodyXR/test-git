import React, { useCallback, useEffect, useMemo } from "react";
import { useLocation, useOutletContext, useParams } from "react-router-dom";
import useTitle from "../../../../hooks/useTitle";
import { Stack, useMediaQuery } from "@mui/material";
import TalentPoolProfileToolbar from "./TalentPoolProfileToolbar";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { debounce } from "lodash";
import { unwrapResult } from "@reduxjs/toolkit";
import { getTalentPool } from "../../../../redux/slices/moderator/talentPoolProfile/talentPoolProfileActions";
import EmptyTalentPoolCandidates from "./EmptyTalentPoolCandidates";
import TalentPoolCandidatesFiltersDesktop from "./TalentPoolCandidatesFiltersDesktop";
import TalentPoolCandidatesTable from "./TalentPoolCandidatesTable";

const TalentPoolProfile = () => {
  const location = useLocation();
  const [, setTitle] = useOutletContext();
  setTitle(location?.state?.name);

  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const { talentPoolId } = useParams();
  const dispatch = useDispatch();

  const { isFilterExtended, has_candidates } = useSelector(
    (state) => state.talentPoolProfile
  );

  const {
    selectedRoles: roles,
    selectedAvailabilityHours: hourly_availabilities,
    minHourlyRate: min_hourly_rate,
    maxHourlyRate: max_hourly_rate,
  } = useSelector((state) => state.candidatesList);

  const filters = {
    roles,
    hourly_availabilities,
  };
  // Filter out empty or undefined values & Memoize the filtered filters to avoid unnecessary re-renders
  const filteredFilters = useMemo(() => {
    const result = Object.keys(filters).reduce((acc, key) => {
      if (filters[key] && filters[key].length > 0) {
        acc[key] = filters[key];
      }
      return acc;
    }, {});

    if (min_hourly_rate !== 0 || max_hourly_rate !== 0) {
      result.min_hourly_rate = min_hourly_rate;
      result.max_hourly_rate = max_hourly_rate;
    }

    return result;
  }, [filters, min_hourly_rate, max_hourly_rate]);
  console.log("filters", filters);

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const fetchTalentPool = useCallback(
    debounce(async (filters) => {
      try {
        const res = await dispatch(
          getTalentPool({ pool_id: talentPoolId, filters })
        );
        const data = await unwrapResult(res);
        console.log("data from talent pool", data);
        handleClickSnackbar("Talent pool list loaded successfully", "success");
      } catch (error) {
        handleClickSnackbar(
          error?.response?.data?.message || "Fail to fetch talent pool",
          "error"
        );
      }
    }, 1000),
    [dispatch]
  );

  useEffect(() => {
    // dispatch(setCurrentFilterParams(filteredFilters));
    fetchTalentPool(filteredFilters);

    // Cleanup function to cancel debounce on unmount
    return () => {
      fetchTalentPool.cancel();
    };
  }, [roles, hourly_availabilities, min_hourly_rate, max_hourly_rate]);

  return (
    <Stack className="talentPoolProfile" sx={{ height: "100%" }} gap={3}>
      <TalentPoolProfileToolbar />

      {has_candidates ? (
        <Stack sx={{ flexDirection: "row", gap: 1.5, flex: 1 }}>
          {lgMatches && isFilterExtended && (
            <TalentPoolCandidatesFiltersDesktop />
          )}
          <TalentPoolCandidatesTable />
        </Stack>
      ) : (
        <EmptyTalentPoolCandidates />
      )}
    </Stack>
  );
};

export default TalentPoolProfile;
