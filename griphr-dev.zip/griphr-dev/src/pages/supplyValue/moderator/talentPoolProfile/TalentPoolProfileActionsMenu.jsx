import {
  Box,
  ListItemIcon,
  ListItemText,
  Menu,
  useMediaQuery,
} from "@mui/material";
import move_grey from "../../../../assets/move_grey.svg";
import copy_grey from "../../../../assets/copy_grey.svg";
import delete_inactive from "../../../../assets/delete_inactive.svg";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import StyledMenuItem from "../../../../components/styled/StyledMenuItem";
import { unwrapResult } from "@reduxjs/toolkit";
import { removeAllSelectedTalentPoolCandidates } from "../../../../redux/slices/moderator/talentPoolProfile/talentPoolProfileSlice";
import {
  bulkDeleteFromTalentPoolAndGetAll,
  deleteFromTalentPoolAndGetAll,
} from "../../../../redux/slices/moderator/talentPoolProfile/talentPoolProfileActions";
import useModal from "../../../../hooks/useModal";
import CustomModal from "../../../../ui/CustomModal";
import AddCandidateToTalentModal from "./AddCandidateToTalentModal";
import { useState } from "react";
import { useParams } from "react-router-dom";
import useDialog from "../../../../hooks/useDialog";
import DeleteModule from "../components/DeleteModule";

const TalentPoolProfileActionsMenu = ({
  userId,
  width = "",
  anchor,
  open,
  onClose,
}) => {
  const { openDialog, handleOpenDialog, handleCloseDialog } = useDialog();
  const [isDeletingTalentPool, setIsDeletingTalentPool] = useState(false)
  const [currentMode, setCurrentMode] = useState("");
  const { talentPoolId } = useParams();
  const { selectedTalentPoolCandidates } = useSelector(
    (state) => state.talentPoolProfile
  );
  const dispatch = useDispatch();
  const smStyles = useMediaQuery((theme) => theme.breakpoints.up("sm"));

  const {
    handleClose: handleAddToTalentClose,
    handleOpen: handleAddToTalentOpen,
    open: addToTalentOpen,
  } = useModal();

  const handleMoveToTalentPool = () => {
    handleAddToTalentOpen();
    setCurrentMode("move");
  };

  const handleCopyToTalentPool = () => {
    handleAddToTalentOpen();
    setCurrentMode("copy");
  };

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleDeleteFromTalentPool = async (data) => {
    try {
      setIsDeletingTalentPool(true);
      const deleteFromTalentPoolAndGetAllResult = await dispatch(
        deleteFromTalentPoolAndGetAll(data)
      );
      await unwrapResult(deleteFromTalentPoolAndGetAllResult);
      setIsDeletingTalentPool(false);
      handleClickSnackbar("Candidate deleted successfully", "success");
      onClose();
    } catch (error) {
      handleClickSnackbar(
        error?.response?.data?.message || "Fail to delete candidate",
        "error"
      );
    }
  };

  const handleBulkDeleteFromTalentPool = async (data) => {
    try {
      setIsDeletingTalentPool(true);
      const bulkDeleteFromTalentPoolAndGetAllResult = await dispatch(
        bulkDeleteFromTalentPoolAndGetAll(data)
      );
      await unwrapResult(bulkDeleteFromTalentPoolAndGetAllResult);
      setIsDeletingTalentPool(false);
      handleClickSnackbar("Candidates deleted successfully", "success");
      dispatch(removeAllSelectedTalentPoolCandidates());
      onClose();
    } catch (error) {
      handleClickSnackbar(
        error?.response?.data?.message || "Fail to delete candidates",
        "error"
      );
    }
  };

  return (
    <>
      <DeleteModule
        openDialog={openDialog}
        handleDelete={() => {
          !userId
            ? handleBulkDeleteFromTalentPool({
                user_ids: selectedTalentPoolCandidates,
                pool_ids: [talentPoolId],
              })
            : handleDeleteFromTalentPool({
                user_id: userId,
                pool_ids: [talentPoolId],
              });
        }}
        handleCloseDialog={handleCloseDialog}
        title={selectedTalentPoolCandidates.length > 0 ? "candidates" : "candidate"}
        isDeleting={isDeletingTalentPool}
      />

      <CustomModal
        onClose={handleAddToTalentClose}
        open={addToTalentOpen}
        title="Add to talent pool"
      >
        <AddCandidateToTalentModal
          onClose={handleAddToTalentClose}
          candidateId={userId}
          poolId={talentPoolId}
          bulkActionMode={userId ? false : true}
          moveMode={currentMode === "move" ? true : false}
          copyMode={currentMode === "copy" ? true : false}
        />
      </CustomModal>

      <Menu
        anchorEl={anchor}
        open={open}
        onClose={onClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
        sx={{
          ".MuiMenu-paper": smStyles
            ? {}
            : {
                width: width || "auto",
                maxWidth: { sm: "600px" },
              },
        }}
      >
        <StyledMenuItem onClick={handleMoveToTalentPool}>
          <ListItemIcon>
            <Box component={"img"} src={move_grey} />
          </ListItemIcon>
          <ListItemText>Move ta a talent pool</ListItemText>
        </StyledMenuItem>
        <StyledMenuItem onClick={handleCopyToTalentPool}>
          <ListItemIcon>
            <Box component={"img"} src={copy_grey} />
          </ListItemIcon>
          <ListItemText>Copy ta a talent pool</ListItemText>
        </StyledMenuItem>
        <StyledMenuItem onClick={handleOpenDialog}>
          <ListItemIcon>
            <Box component={"img"} src={delete_inactive} />
          </ListItemIcon>
          <ListItemText>
            {selectedTalentPoolCandidates.length > 0
              ? "Delete candidates"
              : "Delete candidate"}
          </ListItemText>
        </StyledMenuItem>
      </Menu>
    </>
  );
};

export default TalentPoolProfileActionsMenu;
