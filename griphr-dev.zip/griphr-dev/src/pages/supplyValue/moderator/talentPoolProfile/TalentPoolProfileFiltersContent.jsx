import React from "react";
import CandidatesListRoleFilter from "../candidatesList/CandidatesListRoleFilter";
import CandidatesHourlyRateFilter from "../candidatesList/CandidatesListHourlyRateFilter";
import CandidatesListAvailabilityFilter from "../candidatesList/CandidatesListAvailabilityFilter";

const TalentPoolProfileFiltersContent = () => {
  return (
    <>
      <CandidatesListRoleFilter />
      <CandidatesHourlyRateFilter />
      <CandidatesListAvailabilityFilter />
    </>
  );
};

export default TalentPoolProfileFiltersContent;
