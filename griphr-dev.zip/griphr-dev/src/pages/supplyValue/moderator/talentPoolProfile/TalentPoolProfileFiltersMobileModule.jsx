import { Box, Stack } from "@mui/material";
import React from "react";
import filter from "../../../../assets/filter.svg";
import StyledGreenIconBtn from "../../../../components/styled/StyledGreenIconBtn";
import CustomModal from "../../../../ui/CustomModal";
import useModal from "../../../../hooks/useModal";
import TalentPoolProfileFiltersContent from "./TalentPoolProfileFiltersContent";

const TalentPoolProfileFiltersMobileModule = () => {
  const {
    handleClose: handleCloseFilters,
    handleOpen: handleOpenFilters,
    open: openFilters,
  } = useModal();
  return (
    <>
      <CustomModal
        open={openFilters}
        onClose={handleCloseFilters}
        title={"Filters"}
      >
        <Stack sx={{ p: 2, pt: 0, mt: -4, gap: 3 }}>
          <TalentPoolProfileFiltersContent />
        </Stack>
      </CustomModal>
      <StyledGreenIconBtn onClick={handleOpenFilters} isclicked={+openFilters}>
        <Box
          sx={{ width: "24px", height: "24px" }}
          component={"img"}
          src={filter}
        />
      </StyledGreenIconBtn>
    </>
  );
};

export default TalentPoolProfileFiltersMobileModule;
