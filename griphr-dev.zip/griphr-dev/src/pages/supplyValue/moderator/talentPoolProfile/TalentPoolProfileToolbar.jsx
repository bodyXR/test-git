import { Stack, useMediaQuery } from "@mui/material";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import AddIcon from "@mui/icons-material/Add";
import TalentPoolSearchCandidateModule from "./TalentPoolSearchCandidateModule";
import TalentPoolProfileActionsModule from "./TalentPoolProfileActionsModule";
import { useDispatch, useSelector } from "react-redux";
import TalentPoolProfileFiltersMobileModule from "./TalentPoolProfileFiltersMobileModule";
import { MODERATOR_SEARCH_CANDIDATE_ROUTE } from "../../../../routes/paths";
import { useNavigate } from "react-router-dom";
import { toggleTalentPoolFilters } from "../../../../redux/slices/moderator/talentPoolProfile/talentPoolProfileSlice";
import StyledFiltersStateButton from "../components/styled/StyledFiltersStateButton";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import filter from "../../../../assets/filter.svg";

const TalentPoolProfileToolbar = ({}) => {
  const dispatch = useDispatch();
  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const mdMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("md", "lg")
  );
  const xsMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("xs", "md")
  );
  const navigate = useNavigate();

  const {
    talentPoolCandidates,
    selectedTalentPoolCandidates,
    isFilterExtended,
  } = useSelector((state) => state.talentPoolProfile);

  return (
    <Stack
      sx={{
        gap: { xs: 2 },
        flexDirection: { lg: "row" },
        justifyContent: "space-between",
      }}
    >
      <Stack sx={{ flexDirection: "row", width: "100%", gap: 1 }}>
        {lgMatches && (
          <StyledFiltersStateButton
            startIcon={<img src={filter} alt="filter icon" />}
            variant="outlined"
            onClick={() => dispatch(toggleTalentPoolFilters())}
          >
            {isFilterExtended ? "Hide filters" : "Show filters"}
          </StyledFiltersStateButton>
        )}
        <TalentPoolSearchCandidateModule />
      </Stack>
      {selectedTalentPoolCandidates.length > 0 &&
        talentPoolCandidates &&
        talentPoolCandidates?.length > 0 && <TalentPoolProfileActionsModule />}
      <StyledDarkBtn
        onClick={() => navigate(MODERATOR_SEARCH_CANDIDATE_ROUTE)}
        min_width={lgMatches ? "190px" : "120px"}
        sx={{ flex: { xs: 1 }, textTransform: "unset" }}
        endIcon={<AddIcon />}
      >
        Add candidate
      </StyledDarkBtn>
    </Stack>
  );
};

export default TalentPoolProfileToolbar;
