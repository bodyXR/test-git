import { InputAdornment } from "@mui/material";
import search from "../../../../assets/search.svg";
import StyledSearchBar from "../../../../components/styled/StyledSearchBar";
import useSearch from "../../../../hooks/useSearch";
import { useDispatch, useSelector } from "react-redux";
import { searchTalentPoolCandidates } from "../../../../redux/slices/moderator/talentPoolProfile/talentPoolProfileSlice";

const TalentPoolSearchCandidateModule = () => {
  const dispatch = useDispatch();
  const { talentPoolCandidates } = useSelector(
    (state) => state.talentPoolProfile
  );
  console.log("talentPoolCandidates", talentPoolCandidates);

  const { searchQuery, setSearchQuery, filteredData } = useSearch(
    talentPoolCandidates,
    ["user.first_name", "user.last_name"]
  );

  return (
    <StyledSearchBar
      name="search_candidate"
      fullWidth
      size="small"
      type="search"
      variant="outlined"
      value={searchQuery}
      onChange={(e) => {
        setSearchQuery(e.target.value);
        if (e.target.value === "") {
          return dispatch(searchTalentPoolCandidates(talentPoolCandidates));
        }
        dispatch(searchTalentPoolCandidates(filteredData));
      }}
      placeholder="Search candidate"
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <img src={search} alt="search icon" />
          </InputAdornment>
        ),
      }}
      sx={{
        alignSelf: "stretch",
        "& .MuiInputBase-root": {
          height: "44.5px",
          height: "100%",
        },
      }}
    />
  );
};

export default TalentPoolSearchCandidateModule;
