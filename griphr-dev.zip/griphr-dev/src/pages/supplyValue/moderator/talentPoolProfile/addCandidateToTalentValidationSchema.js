import * as yup from "yup";

export const addCandidateToTalentValidationSchema = yup.object().shape({
  pool_ids: yup.array().min(1, "At least one pool must be selected"),
});
