import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { useFormik } from "formik";
import {
  createTalentPoolAndGetAll,
  editTalentPoolAndGetAll,
} from "../../../../redux/slices/moderator/talentPools/talentPoolsActions";
import { unwrapResult } from "@reduxjs/toolkit";
import { Box, Stack, Typography } from "@mui/material";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import StyledDarkOutlinedBtn from "../../../../components/styled/StyledDarkOutlinedBtn";
import StyledTextField from "../../../../components/styled/StyledTextField";
import { addTalentPoolValidationSchema } from "./addTalentPoolValidationSchema";

const AddTalentPoolModal = ({ onClose, editMode, data }) => {
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  useEffect(() => {
    formik.setValues({
      name: data?.name || "",
    });
  }, [data]);

  const initialValues = {
    name: "",
  };

  const formik = useFormik({
    initialValues,
    validationSchema: addTalentPoolValidationSchema,
    onSubmit: async (values) => {
      try {
        if (editMode) {
          const editTalentPoolAndGetAllResult = await dispatch(
            editTalentPoolAndGetAll({ name: values.name, id: data.id })
          );
          await unwrapResult(editTalentPoolAndGetAllResult);
          handleClickSnackbar("Talent pool updated successfully", "success");
        } else {
          const createTalentPoolAndGetAllResult = await dispatch(
            createTalentPoolAndGetAll({ name: values.name })
          );
          await unwrapResult(createTalentPoolAndGetAllResult);
          handleClickSnackbar("Talent pool added successfully", "success");
        }
        onClose();
      } catch (error) {
        console.log(error);
        handleClickSnackbar(error, "error");
      }
    },
  });

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        p: { xs: 2, lg: 0 },
        pb: { lg: 2 },
        pt: { xs: 0 },
        mt: { xs: -3, lg: 0 },
        gap: { xs: "20px" },
      }}
      component={"form"}
      onSubmit={formik.handleSubmit}
    >
      <Typography
        variant="h4"
        sx={{ color: "darkGreenAccent", fontWeight: 600 }}
      >
        Information
      </Typography>

      <StyledTextField
        id="name"
        name="name"
        variant="outlined"
        placeholder="Talent pool name"
        label="Talent pool name"
        type="text"
        required
        value={formik.values.name}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        helperText={formik.touched.name ? formik.errors.name : ""}
        error={formik.touched.name && Boolean(formik.errors.name)}
        sx={{ background: "white" }}
      />

      <Stack sx={{ flexDirection: { lg: "row" } }} gap={1}>
        <StyledDarkBtn min_width={172} type="submit">
          {editMode ? "Edit" : "Create"}
        </StyledDarkBtn>
        <StyledDarkOutlinedBtn min_width={172} onClick={onClose}>
          Cancel
        </StyledDarkOutlinedBtn>
      </Stack>
    </Box>
  );
};

export default AddTalentPoolModal;
