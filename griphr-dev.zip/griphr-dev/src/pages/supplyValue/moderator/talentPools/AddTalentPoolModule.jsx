import React from "react";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import AddIcon from "@mui/icons-material/Add";
import CustomModal from "../../../../ui/CustomModal";
import useModal from "../../../../hooks/useModal";
import AddTalentPoolModal from "./AddTalentPoolModal";
import { useMediaQuery } from "@mui/material";

const AddTalentModuleModule = () => {
  const lgMedia = useMediaQuery((theme) => theme.breakpoints.up("lg"));

  const {
    handleClose: handleCloseAddTalentPool,
    handleOpen: handleOpenAddTalentPool,
    open: openAddTalentPool,
  } = useModal();
  return (
    <>
      <CustomModal
        open={openAddTalentPool}
        onClose={handleCloseAddTalentPool}
        title={"New talent pool"}
      >
        <AddTalentPoolModal onClose={handleCloseAddTalentPool} />
      </CustomModal>
      <StyledDarkBtn
        onClick={handleOpenAddTalentPool}
        min_width={lgMedia ? "190px" : "120px"}
        sx={{ flex: { xs: 1 }, textTransform: "unset" }}
        endIcon={<AddIcon />}
      >
        Create talent pool
      </StyledDarkBtn>
    </>
  );
};

export default AddTalentModuleModule;
