import { Box, Stack, Typography } from "@mui/material";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import StyledDarkBtn from "../../../../components/styled/StyledDarkBtn";
import pluspaperIcon from "../../../../assets/plus_paper.svg";
import useModal from "../../../../hooks/useModal";
import CustomModal from "../../../../ui/CustomModal";
import AddTalentPoolModal from "./AddTalentPoolModal";
import AddIcon from "@mui/icons-material/Add";

const EmptyTalentPools = () => {
  const {
    handleClose: handleCloseAddTalentPool,
    handleOpen: handleOpenAddTalentPool,
    open: openAddTalentPool,
  } = useModal();

  return (
    <>
      <CustomModal
        open={openAddTalentPool}
        onClose={handleCloseAddTalentPool}
        title={"New talent pool"}
      >
        <AddTalentPoolModal />
      </CustomModal>
      <StyledWrapper
        sx={{
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center",
          gap: "12px",
          py: { xs: 5, lg: "20px" },
          flex: 1,
        }}
      >
        <Box
          sx={{ width: "40px", height: "50px" }}
          component={"img"}
          src={pluspaperIcon}
        />

        <Typography variant="h4" color="inactive.main">
          The list is empty, Click on the button below to create a new talent
          pool
        </Typography>

        <Stack
          sx={{
            flexDirection: { lg: "row" },
            justifyContent: "center",
            alignItems: "center",
            gap: { xs: "12px", lg: 3 },
            width: { xs: "100%", md: "auto" },
          }}
        >
          <StyledDarkBtn
            onClick={handleOpenAddTalentPool}
            min_width="190px"
            sx={{ width: "100%", textTransform: "unset" }}
            endIcon={<AddIcon />}
          >
            Create talent pool
          </StyledDarkBtn>
        </Stack>
      </StyledWrapper>
    </>
  );
};

export default EmptyTalentPools;
