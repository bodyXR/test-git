import { InputAdornment } from "@mui/material";
import search from "../../../../assets/search.svg";
import StyledSearchBar from "../../../../components/styled/StyledSearchBar";
import useSearch from "../../../../hooks/useSearch";
import { useDispatch, useSelector } from "react-redux";
import { searchTalentPools } from "../../../../redux/slices/moderator/talentPools/talentPoolsSlice";

const SearchPoolModule = () => {
  const dispatch = useDispatch();
  const { talentPools } = useSelector((state) => state.talentPools);

  const { searchQuery, setSearchQuery, filteredData } = useSearch(talentPools, [
    "name",
  ]);

  return (
    <StyledSearchBar
      name="search_talent_pool"
      fullWidth
      size="small"
      type="search"
      variant="outlined"
      value={searchQuery}
      onChange={(e) => {
        setSearchQuery(e.target.value);
        if (e.target.value === "") {
          return dispatch(searchTalentPools(talentPools));
        }
        dispatch(searchTalentPools(filteredData));
      }}
      placeholder="Search talent pool"
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <img src={search} alt="search icon" />
          </InputAdornment>
        ),
      }}
      sx={{
        alignSelf: "stretch",
        "& .MuiInputBase-root": {
          minHeight: "44.5px",
          height: "100%",
        },
      }}
    />
  );
};

export default SearchPoolModule;
