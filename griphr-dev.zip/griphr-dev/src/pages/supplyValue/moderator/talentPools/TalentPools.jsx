import React, { useCallback, useEffect } from "react";
import TalentPoolsToolbar from "./TalentPoolsToolbar";
import { Stack } from "@mui/material";
import { getAllTalentPools } from "../../../../redux/slices/moderator/talentPools/talentPoolsActions";
import { useDispatch, useSelector } from "react-redux";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { unwrapResult } from "@reduxjs/toolkit";
import EmptyTalentPools from "./EmptyTalentPools";
import { useLocation } from "react-router-dom";
import useTitle from "../../../../hooks/useTitle";
import TalentPoolsTable from "./TalentPoolsTable";

const TalentPools = () => {
  const location = useLocation();
  useTitle(location);
  const { talentPools } = useSelector((state) => state.talentPools);
  const dispatch = useDispatch();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const fetchAllTalentPools = useCallback(async () => {
    try {
      const res = await dispatch(getAllTalentPools());
      const data = await unwrapResult(res);
      console.log("data from talent pools", data);
      handleClickSnackbar("Talent pools loaded successfully", "success");
    } catch (error) {
      handleClickSnackbar(
        error?.response?.data?.message || "Fail to fetch talent pools",
        "error"
      );
    }
  }, [dispatch]);

  useEffect(() => {
    fetchAllTalentPools();
  }, []);

  return (
    <Stack className="talentPools" sx={{ height: "100%" }} gap={3}>
      <TalentPoolsToolbar />

      {talentPools?.length > 0 ? (
        <Stack sx={{ flexDirection: "row", gap: 1.5, flex: 1 }}>
          <TalentPoolsTable />
        </Stack>
      ) : (
        <EmptyTalentPools />
      )}
    </Stack>
  );
};

export default TalentPools;
