import Grid from "@mui/material/Unstable_Grid2";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { Box, IconButton, Typography } from "@mui/material";
import edit_inactive from "../../../../assets/edit_inactive.svg";
import delete_inactive from "../../../../assets/delete_inactive.svg";
import CustomModal from "../../../../ui/CustomModal";
import AddTalentPoolModal from "./AddTalentPoolModal";
import useModal from "../../../../hooks/useModal";
import { openSnackbar } from "../../../../redux/slices/snackbar/snackbarSlice";
import { unwrapResult } from "@reduxjs/toolkit";
import { deleteTalentPoolAndGetAll } from "../../../../redux/slices/moderator/talentPools/talentPoolsActions";
import DeleteModule from "../components/DeleteModule";
import useDialog from "../../../../hooks/useDialog";
import { useState } from "react";

const TalentPoolsRow = ({ data }) => {
  const dispatch = useDispatch();
  const { openDialog, handleOpenDialog, handleCloseDialog } = useDialog();
  const [isDeletingTalentPool, setIsDeletingTalentPool] = useState(false);
  const {
    handleClose: handleCloseEditTalentPool,
    handleOpen: handleOpenEditTalentPool,
    open: openEditTalentPool,
  } = useModal();

  const handleClickSnackbar = (msg, severity) => {
    dispatch(openSnackbar({ msg, severity }));
  };

  const handleDeleteTalentPool = async (talentPoolId) => {
    try {
      setIsDeletingTalentPool(true);
      const deleteTalentPoolAndGetAllResult = await dispatch(
        deleteTalentPoolAndGetAll(talentPoolId)
      );
      await unwrapResult(deleteTalentPoolAndGetAllResult);
      setIsDeletingTalentPool(false);
      handleClickSnackbar("Talent pool deleted successfully", "success");
    } catch (error) {
      handleClickSnackbar(
        error?.response?.data?.message || "Fail to delete talent pool",
        "error"
      );
    }
  };

  return (
    <>
      <CustomModal
        open={openEditTalentPool}
        onClose={handleCloseEditTalentPool}
        title={"Edit talent pool"}
      >
        <AddTalentPoolModal
          onClose={handleCloseEditTalentPool}
          editMode
          data={data}
        />
      </CustomModal>

      <DeleteModule
        openDialog={openDialog}
        handleDelete={() => {
          handleDeleteTalentPool(data.id);
        }}
        handleCloseDialog={handleCloseDialog}
        title={`Talent pool`}
        isDeleting={isDeletingTalentPool}
      />

      <Grid
        className="candidate__row"
        container
        sx={{
          alignItems: "center",
          borderBottom: "2px solid #EEE",
          p: 2,
        }}
      >
        <Grid xs={9} lg={11}>
          <Link
            to={`/moderator/candidates/talent-pools/profile/${data?.id}`}
            state={{ name: data?.name }}
          >
            <Typography
              variant="h5"
              sx={{
                "&:hover": {
                  color: "#66C1FF",
                  textDecoration: "underline",
                },
                textTransform: "capitalize",
                color: "inactive.main",
                fontWeight: 600,
                textOverflow: "ellipsis",
                overflow: "hidden",
              }}
            >
              {data?.name}
            </Typography>
          </Link>
        </Grid>

        <Grid xs={1.5} lg={0.5}>
          <IconButton onClick={handleOpenEditTalentPool}>
            <Box component="img" src={edit_inactive} alt="edit_icon" />
          </IconButton>
        </Grid>

        <Grid xs={1.5} lg={0.5}>
          <IconButton onClick={handleOpenDialog}>
            <Box component="img" src={delete_inactive} alt="delete_icon" />
          </IconButton>
        </Grid>
      </Grid>
    </>
  );
};

export default TalentPoolsRow;
