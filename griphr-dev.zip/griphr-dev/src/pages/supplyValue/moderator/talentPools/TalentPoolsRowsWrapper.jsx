import TalentPoolsRow from "./TalentPoolsRow";
import { useSelector } from "react-redux";

const TalentPoolsRowsWrapper = () => {
  const { searchedTalentPools } = useSelector((state) => state.talentPools);

  return (
    <>
      {searchedTalentPools &&
        searchedTalentPools?.map((pool, index) => (
          <TalentPoolsRow
            key={pool?.id}
            isLast={index === pool?.length - 1}
            data={pool}
          />
        ))}
    </>
  );
};

export default TalentPoolsRowsWrapper;
