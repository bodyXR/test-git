import { Stack, Typography } from "@mui/material";
import React, { useRef } from "react";
import StyledWrapper from "../../../../components/styled/StyledWrapper";
import TalentPoolsRowsWrapper from "./TalentPoolsRowsWrapper";
import { useDraggable } from "react-use-draggable-scroll";
import { useSelector } from "react-redux";

const TalentPoolsTable = () => {
  const ref = useRef();
  const { events } = useDraggable(ref);
  const { talentPools } = useSelector((state) => state.talentPools);

  return (
    <StyledWrapper
      ref={ref}
      {...events}
      sx={{
        overflowX: "auto",
        flex: 1,
        width: "57vw",
        userSelect: "none",
        "& .candidate__row:last-child": {
          borderBottom: "none",
        },
        height: "62vh",
        overflowY: "auto",
        pt: { xs: 0 },
      }}
    >
      {talentPools?.length > 0 ? (
        <Stack
          className="talentPools__table"
          sx={{
            // width: { xs: "1170px" },
            width: { xs: "100%" },
            height: "100%",
          }}
        >
          <TalentPoolsRowsWrapper />
        </Stack>
      ) : (
        <Typography variant="h3" color="primary" pt={{ xs: 2, lg: "20px" }}>
          No results found
        </Typography>
      )}
    </StyledWrapper>
  );
};

export default TalentPoolsTable;
