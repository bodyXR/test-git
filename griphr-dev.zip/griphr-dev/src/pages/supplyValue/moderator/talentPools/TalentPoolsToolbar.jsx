import { Stack, useMediaQuery } from "@mui/material";
import SearchPoolModule from "./SearchPoolModule";
import AddTalentPoolModule from "./AddTalentPoolModule";
import { useSelector } from "react-redux";

const TalentPoolsToolbar = () => {
  const lgMatches = useMediaQuery((theme) => theme.breakpoints.up("lg"));
  const mdMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("md", "lg")
  );
  const xsMatches = useMediaQuery((theme) =>
    theme.breakpoints.between("xs", "md")
  );

  const { talentPools } = useSelector((state) => state.talentPools);

  return (
    <Stack
      sx={{
        gap: { xs: 2 },
        flexDirection: { lg: "row" },
        justifyContent: "space-between",
      }}
    >
      <SearchPoolModule />
      {talentPools && talentPools?.length > 0 && (
        <>
          {lgMatches && (
            <Stack sx={{ flexDirection: "row", gap: 2 }}>
              <AddTalentPoolModule />
            </Stack>
          )}
          {mdMatches && (
            <Stack sx={{ gap: { xs: 2 }, flexDirection: { xs: "row" } }}>
              <AddTalentPoolModule />
            </Stack>
          )}
          {xsMatches && (
            <Stack sx={{ gap: { xs: 2 }, flexDirection: { xs: "row" } }}>
              <AddTalentPoolModule />
            </Stack>
          )}
        </>
      )}
    </Stack>
  );
};

export default TalentPoolsToolbar;
