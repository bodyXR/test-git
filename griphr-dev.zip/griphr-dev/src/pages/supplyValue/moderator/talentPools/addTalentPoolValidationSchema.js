import * as yup from "yup";

export const addTalentPoolValidationSchema = yup.object().shape({
  name: yup.string().required("Talent pool name is required"),
});
