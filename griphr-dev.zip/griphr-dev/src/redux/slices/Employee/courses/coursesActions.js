import { createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../../../helper/axiosInstance";

export const fetchMyCourses = createAsyncThunk(
  "courses/fetchMyCourses",
  async (_, { rejectWithValue, getState }) => {
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };

    try {
      const { data } = await axiosInstance.get(
        `learning_matching/courses`,
        config
      );
      return data?.payload;
    } catch (error) {
      if (error?.response && error?.response?.data?.message) {
        return rejectWithValue(error?.response?.data?.message);
      } else {
        return rejectWithValue(error?.message);
      }
    } finally {
    }
  }
);

export const fetchMyCourse = createAsyncThunk(
  "courses/fetchMyCourse",
  async (course_id, { rejectWithValue, getState }) => {
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      params: {
        course_id,
      },
    };

    try {
      const { data } = await axiosInstance.get(
        `learning_matching/courses`,
        config
      );
      return data?.payload;
    } catch (error) {
      if (error?.response && error?.response?.data?.message) {
        return rejectWithValue(error?.response?.data?.message);
      } else {
        return rejectWithValue(error?.message);
      }
    } finally {
    }
  }
);

export const fetchMatchedCourses = createAsyncThunk(
  "courses/fetchMatchedCourses",
  async (
    { skill_id, level = 1, page = 1, price = "free" },
    { rejectWithValue, getState }
  ) => {
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      params: {
        skill_id,
        level: level === "Beginner" ? 1 : level === "Intermediate" ? 2 : 3,
        price: `price-${price}`,
        page,
      },
    };

    try {
      const { data } = await axiosInstance.get(
        `learning_matching/matches`,
        config
      );
      return data?.payload;
    } catch (error) {
      if (error?.response && error?.response?.data?.message) {
        return rejectWithValue(error?.response?.data?.message);
      } else {
        return rejectWithValue(error?.message);
      }
    } finally {
    }
  }
);

export const fetchMatchedCourseById = createAsyncThunk(
  "courses/fetchMatchedCourseById",
  async ({ skill_id, level, course_id }, { rejectWithValue, getState }) => {
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      params: {
        skill_id,
        level: level === "Beginner" ? 1 : level === "Intermediate" ? 2 : 3,
        course_id,
        provider: "udemy",
      },
    };

    try {
      const { data } = await axiosInstance.get(
        `learning_matching/matches`,
        config
      );
      return data?.payload;
    } catch (error) {
      if (error?.response && error?.response?.data?.message) {
        return rejectWithValue(error?.response?.data?.message);
      } else {
        return rejectWithValue(error?.message);
      }
    } finally {
    }
  }
);

export const startCourse = createAsyncThunk(
  "courses/startCourse",
  async ({ course_id }, { rejectWithValue, getState }) => {
    const { token } = getState().auth;
    const { courseSkillId: skill, courseLevel: level } = getState().courses;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };
    try {
      const { data } = await axiosInstance.post(
        `learning_matching/courses`,
        {
          course_id,
          level: level === "Beginner" ? 1 : level === "Intermediate" ? 2 : 3,
          skill,
          provider: "udemy",
        },
        config
      );
      return data?.payload;
    } catch (error) {
      if (error?.response && error?.response?.data?.message) {
        return rejectWithValue(error?.response?.data?.message);
      } else {
        return rejectWithValue(error?.message);
      }
    }
  }
);

export const completeCourse = createAsyncThunk(
  "courses/completeCourse",
  async (id, { rejectWithValue, getState }) => {
    const { token } = getState().auth;
    const { courseLevel: level } = getState().courses;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };
    try {
      const { data } = await axiosInstance.put(
        `learning_matching/courses`,
        {
          id,
          level: level === "Beginner" ? 1 : level === "Intermediate" ? 2 : 3,
        },
        config
      );
    } catch (error) {
      if (error?.response && error?.response?.data?.message) {
        return rejectWithValue(error?.response?.data?.message);
      } else {
        return rejectWithValue(error?.message);
      }
    }
  }
);

export const deleteCourse = createAsyncThunk(
  "courses/deleteCourse",
  async (id, { rejectWithValue, getState }) => {
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      params: {
        id,
      },
    };

    try {
      const { data } = await axiosInstance.delete(
        `learning_matching/courses`,
        config
      );
      return data;
    } catch (error) {
      if (error?.response && error?.response?.data?.message) {
        return rejectWithValue(error?.response?.data?.message);
      } else {
        return rejectWithValue(error?.message);
      }
    }
  }
);

export const startCourseAndFetchDetails = createAsyncThunk(
  "courses/startCourseAndFetchDetails",
  async ({ course_id }, { dispatch, getState }) => {
    try {
      // Dispatch startCourse and wait for it to complete
      const resultAction = await dispatch(startCourse({ course_id }));
      // Check if the action was fulfilled
      if (startCourse.fulfilled.match(resultAction)) {
        // Extract the course ID from the payload
        const courseId = resultAction.payload?.id;
        // Dispatch fetchMyCourse with the extracted ID
        await dispatch(fetchMyCourses());
        await dispatch(fetchMyCourse(courseId));
      }
    } catch (error) {
      console.error("Failed to start course and fetch details:", error);
    }
  }
);

export const deleteCourseAndfetchMyCourses = createAsyncThunk(
  "courses/deleteCourseAndfetchMyCourses",
  async (id, { dispatch }) => {
    try {
      // Dispatch deleteCourse and wait for it to complete
      const resultAction = await dispatch(deleteCourse(id));
      // Check if the action was fulfilled
      if (deleteCourse.fulfilled.match(resultAction)) {
        // Dispatch fetchMyCourses
        await dispatch(fetchMyCourses());
      }
    } catch (error) {
      console.error("Failed to delete course and fetch my courses:", error);
    }
  }
);

export const completeCourseAndFetchMyCourses = createAsyncThunk(
  "courses/completeCourseAndFetchMyCourse",
  async (id, { dispatch }) => {
    try {
      // Dispatch completeCourse and wait for it to complete
      const resultAction = await dispatch(completeCourse(id));
      // Check if the action was fulfilled
      if (completeCourse.fulfilled.match(resultAction)) {
        // Dispatch fetchMyCourse with the extracted ID
        await dispatch(fetchMyCourses());
      }
    } catch (error) {
      console.error("Failed to complete course and fetch my courses:", error);
    }
  }
);
