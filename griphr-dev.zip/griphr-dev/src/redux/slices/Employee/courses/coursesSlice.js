import { createSlice } from "@reduxjs/toolkit";
import {
  completeCourse,
  deleteCourse,
  fetchMatchedCourseById,
  fetchMatchedCourses,
  fetchMyCourse,
  fetchMyCourses,
  startCourse,
  startCourseAndFetchDetails,
} from "./coursesActions";
import { logout } from "../../auth/authSlice";

const initialCoursesState = {
  isLoadingMatchedCourses: false,
  isErrorMatchedCourses: false,
  isSuccessMatchedCourses: false,
  isLoadingMyCourses: false,
  isErrorMyCourses: false,
  isSuccessMyCourses: false,
  isLoadingAction: false,
  isErrorAction: false,
  isSuccessAction: false,
  myCourses: [],
  myCourse: {},
  matchedCourses: [],
  matchedCourse: {},
  coursesCount: null,
  courseSkillId: null,
  courseLevel: "Beginner",
  courseState: "not started",
  coursePrice: "free",
  sortedUserSkills: [],
};

const coursesSlice = createSlice({
  name: "courses",
  initialState: initialCoursesState,
  reducers: {
    setCourseSkillId: (state, action) => {
      state.courseSkillId = action.payload;
    },
    setCourseLevel: (state, action) => {
      state.courseLevel = action.payload;
    },
    setCoursePrice: (state, action) => {
      state.coursePrice = action.payload;
    },
    setCourseState: (state, action) => {
      state.courseState = action.payload;
    },
    setSortedUserSkills: (state, action) => {
      state.sortedUserSkills = action.payload;
    },
    setMyCourse: (state, action) => {
      state.myCourse = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(logout, (state) => {
      return initialCoursesState;
    });
    builder
      .addCase(fetchMatchedCourses.pending, (state) => {
        state.isLoadingMatchedCourses = true;
        state.isErrorMatchedCourses = false;
        state.isSuccessMatchedCourses = false;
      })
      .addCase(fetchMatchedCourses.fulfilled, (state, action) => {
        state.isLoadingMatchedCourses = false;
        state.isSuccessMatchedCourses = true;
        state.coursesCount = action.payload.pop()?.count;
        state.matchedCourses = action.payload;
      })
      .addCase(fetchMatchedCourses.rejected, (state) => {
        state.isLoadingMatchedCourses = false;
        state.isErrorMatchedCourses = true;
      });
    builder
      .addCase(fetchMyCourses.pending, (state) => {
        state.isLoadingMyCourses = true;
        state.isErrorMyCourses = false;
        state.isSuccessMyCourses = false;
      })
      .addCase(fetchMyCourses.fulfilled, (state, action) => {
        state.isLoadingMyCourses = false;
        state.isSuccessMyCourses = true;
        state.myCourses = action.payload;
      })
      .addCase(fetchMyCourses.rejected, (state) => {
        state.isLoadingMyCourses = false;
        state.isErrorMyCourses = true;
      });
    builder
      .addCase(fetchMatchedCourseById.pending, (state) => {
        state.isLoadingMatchedCourses = true;
        state.isErrorMatchedCourses = false;
        state.isSuccessMatchedCourses = false;
      })
      .addCase(fetchMatchedCourseById.fulfilled, (state, action) => {
        state.isLoadingMatchedCourses = false;
        state.isSuccessMatchedCourses = true;
        state.matchedCourse = action.payload;
        state.courseState = "not started";
      })
      .addCase(fetchMatchedCourseById.rejected, (state) => {
        state.isLoadingMatchedCourses = false;
        state.isErrorMatchedCourses = true;
      });
    builder
      .addCase(fetchMyCourse.pending, (state) => {
        state.isLoadingMyCourses = true;
        state.isErrorMyCourses = false;
        state.isSuccessMyCourses = false;
      })
      .addCase(fetchMyCourse.fulfilled, (state, action) => {
        console.log("fetchMyCourse", action.payload);
        state.isLoadingMyCourses = false;
        state.isSuccessMyCourses = true;
        state.myCourse = action.payload;
        // state.courseState = state?.myCourse?.status || "not started";
      })
      .addCase(fetchMyCourse.rejected, (state) => {
        state.isLoadingMyCourses = false;
        state.isErrorMyCourses = true;
      });
    builder
      .addCase(startCourse.pending, (state) => {
        state.isLoadingAction = true;
        state.isErrorAction = false;
        state.isSuccessAction = false;
      })
      .addCase(startCourse.fulfilled, (state, action) => {
        state.isLoadingAction = false;
        state.isSuccessAction = true;
        state.courseState = action?.payload?.status;
        state.courseState = "started";
      })
      .addCase(startCourse.rejected, (state) => {
        state.isLoadingAction = false;
        state.isErrorAction = true;
      });
    builder
      .addCase(completeCourse.pending, (state) => {
        state.isLoadingAction = true;
        state.isErrorAction = false;
        state.isSuccessAction = false;
      })
      .addCase(completeCourse.fulfilled, (state) => {
        state.isLoadingAction = false;
        state.isSuccessAction = true;
        state.courseState = "completed";
        state.myCourse = {};
      })
      .addCase(completeCourse.rejected, (state) => {
        state.isLoadingAction = false;
        state.isErrorAction = true;
      });
    builder
      .addCase(deleteCourse.pending, (state) => {
        state.isLoadingAction = true;
        state.isErrorAction = false;
        state.isSuccessAction = false;
      })
      .addCase(deleteCourse.fulfilled, (state) => {
        state.isLoadingAction = false;
        state.isSuccessAction = true;
        state.courseState = "not started";
        state.myCourse = {};
      })
      .addCase(deleteCourse.rejected, (state) => {
        state.isLoadingAction = false;
        state.isErrorAction = true;
      });
    builder
      .addCase(startCourseAndFetchDetails.pending, (state) => {
        state.isLoadingAction = true;
        state.isErrorAction = false;
        state.isSuccessAction = false;
      })
      .addCase(startCourseAndFetchDetails.fulfilled, (state, action) => {
        state.isLoadingAction = false;
        state.isSuccessAction = true;
        state.courseState = "started";
      })
      .addCase(startCourseAndFetchDetails.rejected, (state) => {
        state.isLoadingAction = false;
        state.isErrorAction = true;
      });
  },
});

export const {
  setCourseSkillId,
  setCourseLevel,
  setCourseState,
  setSortedUserSkills,
  setCoursePrice,
  setMyCourse,
} = coursesSlice.actions;

export default coursesSlice.reducer;
