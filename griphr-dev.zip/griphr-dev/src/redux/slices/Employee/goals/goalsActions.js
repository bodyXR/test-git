import { createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../../../helper/axiosInstance";

export const fetchGoalsData = createAsyncThunk(
  "goals/fetchGoalsData",
  async (group_by = "goals", { getState }) => {
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        group_by,
      },
    };
    const response = await axiosInstance.get(`goals/`, config);
    return response.data.payload;
  }
);

export const fetchGoalsDataById = createAsyncThunk(
  "goals/fetchGoalsDataById",
  async (id, { getState }) => {
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        id,
      },
    };
    const response = await axiosInstance.get(`goals/`, config);
    return response.data.payload;
  }
);

export const fetchActionsDataByGoalId = createAsyncThunk(
  "goals/fetchActionsDataByGoalId",
  async (goal_id, { getState }) => {
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        goal_id,
      },
    };
    const response = await axiosInstance.get(`goals/actions`, config);
    return response.data.payload;
  }
);

export const fetchProjectsMatches = createAsyncThunk(
  "goals/fetchProjectsMatches",
  async (skills, { getState }) => {
    console.log(skills);
    const skillsString = JSON.stringify(skills);
    let skillsStringBase64 = btoa(skillsString);
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      params: {
        type: "goal_projects",
        value: skillsStringBase64,
      },
    };
    try {
      console.log("fetch projects matches");
      const response = await axiosInstance.get(`recommendations`, config);
      return response.data.payload;
    } catch (error) {
      console.log(error);
    }
  }
);

export const fetchMatchedCourses = createAsyncThunk(
  "goals/fetchMatchedCourses",
  async (
    { skill_id, level = 1, page = 1, price = "free" },
    { rejectWithValue, getState }
  ) => {
    const { token } = getState().auth;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      params: {
        skill_id,
        level: level === "Beginner" ? 1 : level === "Intermediate" ? 2 : 3,
        page,
        price: `price-${price}`,
      },
    };

    try {
      const { data } = await axiosInstance.get(
        `learning_matching/matches`,
        config
      );
      return data?.payload;
    } catch (error) {
      if (error?.response && error?.response?.data?.message) {
        return rejectWithValue(error?.response?.data?.message);
      } else {
        return rejectWithValue(error?.message);
      }
    } finally {
    }
  }
);
