import { createSlice } from "@reduxjs/toolkit";
import {
  fetchActionsDataByGoalId,
  fetchGoalsData,
  fetchGoalsDataById,
  fetchMatchedCourses,
  fetchProjectsMatches,
} from "./goalsActions";
const initialGoalsState = {
  loading: false,
  data: [],
  actions: { courses: [], projects: [], activities: [] },
  goal: null,
  projects: [],
  isLoadingProjects: false,
  isSuccessProjects: false,
  isErrorProjects: false,
  courseSkillId: null,
  courseLevel: "Beginner",
  coursePrice: "free",
  matchedCourses: [],
  coursesCount: null,
  isLoadingMatchedCourses: false,
  isSuccessMatchedCourses: false,
  isErrorMatchedCourses: false,
  selectedCourses: [],
  selectedProjects: [],
  selectedActivities: [],
  selectedSkills: [],
};
const goalsSlice = createSlice({
  name: "goals",
  initialState: initialGoalsState,
  reducers: {
    resetGoalsSlice: () => initialGoalsState,
    setCourseSkillId: (state, action) => {
      state.courseSkillId = action.payload;
    },
    setCourseLevel: (state, action) => {
      state.courseLevel = action.payload;
    },
    setCoursePrice: (state, action) => {
      state.coursePrice = action.payload;
    },
    setSelectedCourses: (state, action) => {
      state.selectedCourses = action.payload;
    },
    setSelectedProjects: (state, action) => {
      state.selectedProjects = action.payload;
    },
    setSelectedActivities: (state, action) => {
      state.selectedActivities = action.payload;
    },
    setSelectedSkills: (state, action) => {
      state.selectedSkills = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchGoalsData.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchGoalsData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(fetchGoalsData.rejected, (state) => {
        state.loading = false;
      });

    builder
      .addCase(fetchGoalsDataById.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchGoalsDataById.fulfilled, (state, action) => {
        state.loading = false;
        state.goal = action.payload;
      })
      .addCase(fetchGoalsDataById.rejected, (state) => {
        state.loading = false;
      });

    builder.addCase(fetchActionsDataByGoalId.fulfilled, (state, action) => {
      state.actions = action.payload;
    });

    builder
      .addCase(fetchProjectsMatches.pending, (state) => {
        state.isLoadingProjects = true;
      })
      .addCase(fetchProjectsMatches.fulfilled, (state, action) => {
        state.isLoadingProjects = false;
        state.projects = action.payload;
        state.isSuccessProjects = true;
      })
      .addCase(fetchProjectsMatches.rejected, (state) => {
        state.isLoadingProjects = false;
        state.isSuccessProjects = false;
      });

    builder
      .addCase(fetchMatchedCourses.pending, (state) => {
        state.isLoadingMatchedCourses = true;
        state.isSuccessMatchedCourses = false;
        state.isErrorMatchedCourses = false;
      })
      .addCase(fetchMatchedCourses.fulfilled, (state, action) => {
        state.isLoadingMatchedCourses = false;
        state.isSuccessMatchedCourses = true;
        state.coursesCount = action.payload.pop()?.count;
        state.matchedCourses = action.payload;
      })
      .addCase(fetchMatchedCourses.rejected, (state) => {
        state.isLoadingMatchedCourses = false;
        state.isErrorMatchedCourses = true;
        state.isSuccessMatchedCourses = false;
      });
  },
});
export const {
  // setGoalSkills,
  setCourseSkillId,
  setCourseLevel,
  setSelectedCourses,
  setSelectedProjects,
  setSelectedActivities,
  setSelectedSkills,
  resetGoalsSlice,
  setCoursePrice,
} = goalsSlice.actions;

export default goalsSlice.reducer;
